#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

import os

#---------------------------------------------------------------------------

class Struct:
    def __init__(self, **kw):
        self.__dict__.update(kw)
    def __repr__(self):
        fieldNameValueList = ['%s:%s'%(x,y) for x,y in self.__dict__.items()]
        return "<struct|"+(",".join(fieldNameValueList))+">"

#---------------------------------------------------------------------------

def readFile(fileName):
    f = open(fileName)
    result = f.read()
    f.close()
    return result

def readCommandOutput(command):
    f = os.popen(command)
    result = f.read()
    f.close()
    return result

def writeFile(fileName, data):
    f = open(fileName, "w")
    f.write(data)
    f.close()

def hexDump(data):
    content=data
    s=16
    for i in range(len(content)):
        if i%s==0: print "%08x:"%i,
        print "%02x"%ord(content[i]),
        if i%s==s-1: print
    print

#---------------------------------------------------------------------------

class ReturnFromExecExcept(Exception):
    pass

def execFileUntilExcept(fileName, localDict, exceptClass):
    try:
        execfile(fileName, localDict)
    except exceptClass: pass

def execWith(fileName, localDict, inResult=None):
    initialKeyList = localDict.keys()
    localDict["ReturnFromExecExcept"] = ReturnFromExecExcept
    execFileUntilExcept(fileName, localDict, ReturnFromExecExcept)
    for key in initialKeyList + ["__builtins__"]:
        del localDict[key]
    if inResult == None:
        result = Struct()
    else: result = inResult
    for key,value in localDict.items():
        result.__dict__[key]=value
    return result

#---------------------------------------------------------------------------

def toASCII(rawData):
    o0 = ord('A')
    return "".join([ chr(o0 + ord(x)//16)+chr(o0 + ord(x)%16)
                     for x in rawData ])

def fromASCII(encodedData):
    o0 = ord('A')    
    rawData = []
    for i in range(0,len(encodedData),2):
        rawData.append( chr( (ord(encodedData[i])-o0)*16
                             +ord(encodedData[i+1])-o0) )
    return "".join(rawData)

#---------------------------------------------------------------------------
