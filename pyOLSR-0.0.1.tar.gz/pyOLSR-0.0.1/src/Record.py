#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
# TODO:
# - comments are plain wrong
#---------------------------------------------------------------------------

import os, pdb

import Base

#---------------------------------------------------------------------------

# * Log packet: _lp
# - False: don't
# - True:  log every packet received and sent

# * Log levels and sets:
# - bit 1: log basic info before and after each event/processing
# - bit 2: log extended info
# - bit 3: log changes immediatly
# - bit 4: log processing algorithm


# * Log message
#  Hello, Two Hop, etc...
# - bit 1: log message
# - bit 2: log processing

# * Log 

class LogConfig:
    def __init__(self):
        self.traceDir = None
        self.setLevel()

    def setLevel(self): # XXX!: to implement
        self._lsim = True
        self._lp = True
        #self._lm = 0
        self._ls = True              # Log all Sets
        self._lns = max(0, self._ls) # Log Neighbor Set
        self._lls = max(0, self._ls) # Log Link Set
        self._lds = max(0, self._ls) # Log Duplicate Set
        self._lts = max(0, self._ls) # Log Two Hop Neighbor Set
        self._lms = max(0, self._ls) # Log MPR Set
        self._lm  = max(0, self._ls) # Log MPR Selector Set
        self._lt  = max(0, self._ls) # Log Topology
        self._lr  = max(0, self._ls) # Log Routing Table
        self._lmi = max(0, self._ls) # Log MID

        self._link = False # XXX: rename
        self._lec = False  #max(0, self._ls) # Log event cause
        self._ltime = False

    def setNoLog(self):
        self._lsim = False
        self._lp = False
        self._ls = False
        self._lns = False # Log Neighbor Set
        self._lls = False # Log Link Set
        self._lds = False # Log Duplicate Set
        self._lts = False # Log Two Hop Neighbor Set
        self._lms = False # Log MPR Set
        self._lm  = False # Log MPR Selector Set
        self._lt  = False # Log Topology
        self._lr  = False # Log Routing Table
        self._lmi = False # Log MID
        
    def setTraceDir(self, dirName):
        self.traceDir = dirName

#---------------------------------------------------------------------------

class LogManager:
    def __init__(self):
        self.prefix = None
        self.breakPointList = []
        self.currentLine = None

    def openForWrite(self, prefix, runType):
        self.prefix = prefix
        #if os.path.exists("%s/runType" % self.prefix):
        #    os.system("rm -rf %s" % self.prefix)
        breakPointFileName = "%s/breakpoint" % self.prefix
        if os.path.exists(breakPointFileName):
            breakList = [ x.strip()
                    for x in Base.readFile(breakPointFileName).split("\n")]
            self.breakPointList = [ int(x) for x in breakList if len(x)>0 ]
        try: os.mkdir("%s" % self.prefix)
        except OSError: pass
        Base.writeFile("%s/runType" % self.prefix, runType)
        self.f = open("%s/full.log" % self.prefix, "w")
        self.currentLine = 0

    def write(self, data, condition=True):
        if self.f != None and condition:
            if self.currentLine+1 in self.breakPointList:
                pdb.set_trace()
            self.f.write(data)
            self.currentLine += len(data.split("\n"))-1
            #if self.currentLine == 1112:
                
    def openForRead(self):
        pass

class SimLogManager:
    def __init__(self, logManager):
        self.logManager = logManager

#---------------------------------------------------------------------------
