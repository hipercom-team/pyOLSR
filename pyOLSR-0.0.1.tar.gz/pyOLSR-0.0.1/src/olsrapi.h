/*---------------------------------------------------------------------------*
 *                             pyOLSR
 *             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
 *  Copyright 2003 Institut National de Recherche en Informatique et  
 *  en Automatique.  All rights reserved.  Distributed only with permission.
 *---------------------------------------------------------------------------
 * TODO: 
 * - XXX: routeConfigurator function
 * - XXX: address size should be specified at start
 *---------------------------------------------------------------------------*/

#ifndef _OLSRAPI_H
#define _OLSRAPI_H

/*---------------------------------------------------------------------------*/

typedef void* OpaqueOLSRNode;
typedef void* OpaqueOLSRAPI;

typedef void (*OLSR_send_func)(OpaqueOLSRNode* src,
			       void* srcAddr, int srcAddrSize,
			       void* packet, int packetSize);
typedef void (*OLSR_callback_func)(double currentTime, void* data);
typedef void (*OLSR_schedule_func)(double relTime, 
				   OLSR_callback_func callback,
				   void* data);
typedef double (*OLSR_get_clock_func)();

/*---------------------------------------------------------------------------*/

void olsrapi_init();

OpaqueOLSRAPI olsrapi_create(OLSR_schedule_func schedule_func,
			     OLSR_get_clock_func get_clock_func,
			     OLSR_send_func send_func);

void olsrapi_free(OpaqueOLSRAPI* self);

/*---------------------------------------------------------------------------*/

OpaqueOLSRNode olsrapi_create_node(OpaqueOLSRAPI self, void* id, int nbIface);

void* olsrapi_node_get_id(OpaqueOLSRNode self);

void olsrapi_node_start(OpaqueOLSRNode self);

void olsrapi_node_receive(OpaqueOLSRNode self, int ifaceId,
			  void* srcAddr, int srcAddrSize,
			  void* packet, int packetSize);

void olsrapi_node_free(OpaqueOLSRNode self);

/*---------------------------------------------------------------------------*/

#endif  /* _OLSRAPI_H */
