#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

OLSRPort   = 5698

#--------------------------------------------------

WILL_NEVER   = 0 # @>>3940
WILL_LOW     = 1 # @>>3942
WILL_DEFAULT = 2 # @>>3944
WILL_HIGH    = 6 # @>>3946
WILL_ALWAYS  = 7 # @>>3948

#--------------------------------------------------

UNSPEC_LINK  = 0 # @>>3899
ASYM_LINK    = 1 # @>>3901
SYM_LINK     = 2 # @>>3903
LOST_LINK    = 3 # @>>3905

NOT_NEIGH    = 0 # @>>3911
SYM_NEIGH    = 1 # @>>3913
MPR_NEIGH    = 2 # @>>3915

SYM = "sym"
NOT_SYM = "not-sym"

#--------------------------------------------------
