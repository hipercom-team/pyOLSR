/*---------------------------------------------------------------------------*
 *
 *
 * Cedric Adjih - INRIA Rocquencourt - Hipercom - 2003
 *---------------------------------------------------------------------------*/

#include <Python.h>

#include "olsrapi.h"

static int isInitialized = 0;
static void olsr_ensure_initialized()
{
  if (!isInitialized) {
    Py_Initialize();
    initolsrbase();
    isInitialized = 1;
  }
}

void olsrapi_init()
{ 
  olsr_ensure_initialized(); 
}

/*---------------------------------------------------------------------------*/
