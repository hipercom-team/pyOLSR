#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

import PacketManager, Simulation

class PacketTool:
    def __init__(self, addressSize):
        self.mainAddressToNameTable = {}
        self.rawAddressToNameTable = {}
        self.packetManager = PacketManager.PacketManager(self)
        self.addressSize = addressSize

    def parsePacket(self, sendIfaceAddress, recvIfaceAddress, rawPacket):
        return self.packetManager.parsePacket(sendIfaceAddress,
                                              recvIfaceAddress, rawPacket)

    def parseMessage(self, msg):
        return self.packetManager.parseMessage(msg)

    def prettyReprMessage(self, msg):
        r = []
        m = msg.content
        if msg.messageType == PacketManager.MessageType["hello"]:
            htime = PacketManager.fromMantissaExponentByte(m.htime)
            r += ["htime=%s willing=%s" % (htime, m.willingness)]
            for linkEntry in m.linkList:
                #r.append( repr(linkEntry))
                linkEntry.address
                strLinkType = PacketManager.findByValue(PacketManager.LinkType,
                                                        linkEntry.linkType)
                if strLinkType == "UNSPEC_LINK": strLinkType = "unspec"
                elif strLinkType == "ASYM_LINK": strLinkType = "asym"
                elif strLinkType == "SYM_LINK": strLinkType = "sym"
                elif strLinkType == "LOST_LINK": strLinkType = "lost"
                else: raise exceptions.RuntimeError, strLinkType
                strNeighborType = PacketManager.findByValue(
                    PacketManager.NeighborType, linkEntry.neighborType)
                if strNeighborType == "NOT_NEIGH": strNeighborType = "-"
                elif strNeighborType == "SYM_NEIGH": strNeighborType = "neigh"
                elif strNeighborType == "MPR_NEIGH": strNeighborType = "mpr"
                r.append( "%s: %s,%s" % (linkEntry.address, strLinkType,
                                         strNeighborType))

        elif msg.messageType == PacketManager.MessageType["tc"]:
            r += ["ANSN=%s" % m.ANSN]
            r += ["%s" % address for address in m.addressList]            
        elif msg.messageType == PacketManager.MessageType["mid"]:
            r += ["%s" % address for address in m.addressList]
        elif msg.messageType == PacketManager.MessageType["hna"]:            
            print "HNA", m
        else: r += ["unknown - messageType=%d" % msg.messageType]
        return r

    def addRawAddressToName(self, rawAddress, name):
        self.rawAddressToNameTable[rawAddress] = name

    #--------------------------------------------------
    # XXX!! put some order here, these are kludges
    # Address factory

    def netToAddress(self, rawAddress):
        result, empty = self.popFrontAddress(rawAddress)
        assert empty == ''
        return result

    def getAddressSize(self): return self.addressSize

    def popFrontAddress(self, data):
        #addrSize = struct.calcsize("!HH")
        netAddress = data[:self.addressSize]
        dataTail = data[self.addressSize:]
        if not self.rawAddressToNameTable.has_key(netAddress):
            print repr(netAddress)
            print repr(self.rawAddressToNameTable.keys())
        else: name = self.rawAddressToNameTable[netAddress]
        address = Simulation.SimulationAddress(name, netAddress)
        return address, dataTail

#---------------------------------------------------------------------------
