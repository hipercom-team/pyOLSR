#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
#
#---------------------------------------------------------------------------
# TODO:
# - clean up
# - add optional modules with linking to C libraries
#---------------------------------------------------------------------------

import re, os, socket, struct, sys

import Constant
import Base, Scheduler, Node, Record #PacketFormat, Neighbor

# XXX: just in case it is not defined (slackware 7)
socket.IPPROTO_IPV6 = 41
socket.SO_BINDTODEVICE = 25 # XXX: not defined

#---------------------------------------------------------------------------

actuallyRoute = True

#---------------------------------------------------------------------------

ipAddr = "([0-9]+[.][0-9]+[.][0-9]+[.][0-9]+)"
ipv6Addr = "[a-f0-9:]+"
rInetAddrIPv6 = re.compile("inet6 addr: ("+ipv6Addr+")/([0-9]+) Scope:Link")
rBcastAddrIPv6 = re.compile("inet6 addr: ("+ipv6Addr+"/[0-9]+)")

rInetAddr = re.compile("inet addr:"+ipAddr)
rBcastAddr = re.compile("Bcast:"+ipAddr)
rMaskAddr = re.compile("Mask:"+ipAddr)

#XXX: auto-detect windows language.
#rWinFrenchInetAddr = re.compile(".+Adresse physique[ .]+:"+ipAddr)
rWinFrenchName = re.compile(".+Connexion au r.seau local ([0-9]+)[^:]*:")
rWinFrenchInetAddr = re.compile(".+Adresse IP[ .]+: "+ipAddr)
rWinFrenchMaskAddr = re.compile(".+Masque de sous[^:]+:[ \t]*"+ipAddr)
#rWinFrenchMaskAddr = re.compile(".+Masqu(.)")
rWinFrenchDesc = re.compile(".+Description[ \t.]+: (.+)")

#---------------------------------------------------------------------------

def parseInet6Dev():
    result = []
    lineList = Base.readFile("/proc/net/if_inet6").split("\n")
    lineList = [ line.strip() for line in lineList ]
    for line in lineList:
	infoList = line.split(" ")
	infoList = [ info for info in infoList if info != '']
	if len(infoList)>2:
	    result.append( [infoList[-1], infoList[0], eval('0x'+infoList[1])]
	                    + infoList[2:-1] )
    return result

def parseProcIpv6Route():
    def asAddr(x): return ":".join([x[i:i+4] for i in range(0,32,4)])
    lineList = Base.readFile("/proc/net/ipv6_route").split("\n")
    lineList = [ line.strip() for line in lineList ]
    result = []
    for line in lineList:
        if line == '': continue
        info = [x for x in line.split() if x != '']
        #if info[0].startswith("fe80") and info[4].startswith("fe80") and info[1]=='80':
        # dst,dst_len,src,src_len,gw,metric,info,flags
        metric = eval("0x"+info[5])
        if info[0].startswith("fe80") and info[5]>1 and info[1]=='80':
            result.append((asAddr(info[0]), eval("0x"+info[1]), asAddr(info[4]), info[-1]))
    return result


if 0:
    for dest, mask, gw, device in parseProcIpv6Route():
    	if gw.startswith("fe80"):
            print "route -A inet6 del %s gw %s dev %s" % (dest,gw,device)
            os.system("route -A inet6 del %s gw %s dev %s" % (dest,gw,device))
    	else:
            print "route -A inet6 del %s dev %s" % (dest,device)
            os.system("route -A inet6 del %s dev %s" % (dest,device))

#exitNow

#---------------------------------------------------------------------------

def parseProcWireless():
    if not os.path.exists("/proc/net/wireless"): return []
    data = Base.readFile("/proc/net/wireless")
    lineList = [x.strip() for x in data.split("\n")]
    lineList = [x for x in lineList[2:] if x != '']
    return [ re.match("([^:]+):", x).group(1) for x in lineList ]


class LinuxInterfaceConfigurator:

    def __init__(self, withIPv6):
        self.withIPv6 = withIPv6

    def getIfaceList(self):
        data = Base.readFile("/proc/net/dev")
        dataList = filter(lambda x: x!='', data.split("\n"))
        assert dataList[0].startswith("Inter")
        assert dataList[1].startswith(" face")
        dataList = dataList[2:]
        def extractIface(line):
            end = line.find(':')
            return line[:end].strip()
        return map(extractIface, dataList)

    def getWirelessIfaceList(self): return parseProcWireless()

    def getWiredIfaceList(self):
        wirelessList = self.getWirelessIfaceList()
        print self.getIfaceList()
        return [ x for x in self.getIfaceList()
                 if (x not in wirelessList) and x!='lo'
                    and not x.startswith('sit')
                    and not x.startswith('ipsec')
                 and not x.startswith('tap')]

    def setForwarding(self, ifaceName, value=1):
        if self.withIPv6: infix = "ipv6"
        else: infix = "ipv4"
        fileName = "/proc/sys/net/%s/conf/%s/forwarding" % (infix, ifaceName)
        Base.writeFile(fileName, "%d" % value)

    def getForwarding(self, ifaceName):
        if self.withIPv6: infix = "ipv6"
        else: infix = "ipv4"        
        fileName = "/proc/sys/net/%s/conf/%s/forwarding" % (infix, ifaceName)
        return Base.readFile(fileName).startswith("1")

    def readIfconfig(self, ifaceName):
        f = os.popen("/sbin/ifconfig %s" % ifaceName, "r")
        result = f.read()
        f.close()
        return result

    def getIPAddressv4(self, ifaceName):
        return self._returnIfconfigMatchOrNone(ifaceName, rInetAddr)

    def getNetmaskv4(self, ifaceName):
        return self._returnIfconfigMatchOrNone(ifaceName, rMaskAddr)

    def getBroadcastv4(self, ifaceName):
        return self._returnIfconfigMatchOrNone(ifaceName, rBcastAddr)

    def getIPAddress(self, ifaceName):
        if self.withIPv6:
            return self._returnIfconfigMatchOrNone(ifaceName, rInetAddrIPv6)
        else: return self.getIPAddressv4(ifaceName)

    def getBroadcast(self, ifaceName):
        if self.withIPv6: #XXX!
            return self._returnIfconfigMatchOrNone(ifaceName, rInetAddrIPv6)
        else: return self.getBroadcastv4(ifaceName)

    def getNetmask(self, ifaceName):
        if self.withIPv6: #XXX!
            return self._returnIfconfigMatchOrNone(ifaceName, rInetAddrIPv6)
        else: return self.getNetmaskv4(ifaceName)

    def _returnIfconfigMatchOrNone(self, ifaceName, regex):
        mRegex = regex.search(self.readIfconfig(ifaceName))
        if mRegex == None: return None
        else: return mRegex.group(1)

    def addRoute(self, ifaceName, ipAddr, gwAddr, netMask, metric=10):
	if self.withIPv6: family = "-A inet6" #XXX: unimplemented for HNA
	else: family = ""
        self.delRoute(ifaceName, ipAddr, gwAddr, netMask)        
        isNetwork = not (netMask==None or "%s"%(netMask,)=="255.255.255.255")
        #print "isNetwork", isNetwork, netMask, repr(netMask)
        if not isNetwork:
            if ipAddr != gwAddr:
                cmd = ("/sbin/route %s add %s gw %s dev %s metric %s"
                       % (family, ipAddr, gwAddr, ifaceName, metric))
            else: cmd = ("/sbin/route %s add %s dev %s metric %s" 
	               % (family, ipAddr, ifaceName, metric))
        else:
            XXX.to.check
            if ipAddr != gwAddr:
                cmd = ("/sbin/route add -net %s netmask %s gw %s dev %s"
                          % (ipAddr, netMask, gwAddr, ifaceName))
            else:
                cmd = ("/sbin/route add -net %s netmask %s dev %s"
                          % (ipAddr, netMask, ifaceName))
        if actuallyRoute: os.system(cmd)

    def delRoute(self, ifaceName, ipAddr, gwAddr, netMask):
	if self.withIPv6: family = "-A inet6" #XXX: unimplemented for HNA
	else: family = ""	
        isNetwork = not (netMask==None or repr(netMask)=="255.255.255.255")
        if not isNetwork:
            cmd = ("/sbin/route %s del %s dev %s 1>/dev/null 2>/dev/null"
                      % (family, ipAddr, ifaceName))
        else:
	    # XXX: unimplemented for HNA
            cmd = ("/sbin/route del -net %s netmask %s dev %s 1>/dev/null 2>/dev/null"
                      % (ipAddr, netMask, ifaceName))
        if actuallyRoute: os.system(cmd)

#---------------------------------------------------------------------------

class WinInterfaceConfigurator:

    def __init__(self):
        self.initIfaceList()

    def getFullIfaceList(self):
        return self.fullIfaceList

    def initIfaceList(self):
        data = Base.readCommandOutput("ipconfig /all")
        dataList = filter(lambda x: x!='', data.split("\n"))
        #assert dataList[0].startswith("======")
        #assert dataList[1].startswith("Liste d'Inter") # XXX: Win2000 French
        #dataList = dataList[2:]
        #XXX: put back:
        #def extractIface(line):
        #    end = line.find(':')
        #    return line[:end].strip()
        #return map(extractIface, dataList)
        ifaceIndex   = None
        ifaceDesc    = None
        ifaceIP      = None
        ifaceNetMask = None
        fullIfaceList = []
        def flush():
            if ifaceIndex!=None:
                fullIfaceList.append( ("eth%s" % ifaceIndex,
                                     ifaceDesc, ifaceIP, ifaceNetMask) )
        for line in dataList:
            mName = rWinFrenchName.match(line)
            mIP = rWinFrenchInetAddr.match(line)
            mNetMask = rWinFrenchMaskAddr.match(line)
            mDesc = rWinFrenchDesc.match(line)
            if mName:
                flush()
                ifaceIndex = mName.group(1)
                ifaceDesc, ifaceIP, ifaceNetMask = None, None, None
            elif mIP: ifaceIP = mIP.group(1)
            elif mDesc: ifaceDesc = mDesc.group(1).strip()
            elif mNetMask: ifaceNetMask = mNetMask.group(1)
        flush()
        self.fullIfaceList = fullIfaceList

    def getIfaceList(self):
        return [x[0] for x in self.getFullIfaceList()]

    def findIfaceByName(self, name):
        return [x for x in self.getFullIfaceList() if x[0] == name][0]

    def setForwarding(self, ifaceName, value=1):
        #XXX: unimplemented
        #fileName = "/proc/sys/net/ipv4/conf/%s/forwarding" % ifaceName
        #Base.writeFile(fileName, "%d" % value)
        pass

    def getForwarding(self, ifaceName):
        #fileName = "/proc/sys/net/ipv4/conf/%s/forwarding" % ifaceName        
        #return Base.readFile(fileName).startswith("1")
        return 1

    def getIPAddress(self, ifaceName):
        return self.findIfaceByName(ifaceName)[2]

    def getNetmask(self, ifaceName):
        return self.findIfaceByName(ifaceName)[3]

    def getBroadcast(self, ifaceName):
        netmask = ipv4StringToLong( self.getNetmask(ifaceName) )
        ipAddress = ipv4StringToLong( self.getIPAddress(ifaceName) )
        return ipv4LongToString( (ipAddress&netmask)|(0xffffffffL ^ netmask) )

    def addRoute(self, ifaceName, ipAddr, gwAddr, netMask):
        # XXX: what about iface name ?
        self.delRoute(ifaceName, ipAddr, gwAddr, netMask)
        if netMask == None: netMask = "255.255.255.255"
        if ipAddr != gwAddr: os.system("route add %s mask %s %s "
                      % (ipAddr, netMask, gwAddr))
        else: os.system("route add %s mask %s %s" % (ipAddr, netMask, self.getIPAddress(ifaceName)))

    def delRoute(self, ifaceName, ipAddr, gwAddr, netMask):
        # XXX: what about iface name?
        if netMask == None: netMask = "255.255.255.255"        
        os.system("route delete %s mask %s" % (ipAddr, netMask))

#---------------------------------------------------------------------------

BSDIfConfigAll = "/sbin/ifconfig -a"

class BSDInterfaceConfigurator:

    def __init__(self):
        self.initIfaceList()

    def getFullIfaceList(self):
        return self.fullIfaceList

    def initIfaceList(self):
        data = Base.readCommandOutput(BSDIfConfigAll)
	dataList = [ x.strip() for x in data.split("\n") ]
        dataList = [ x for x in dataList if x!="" ]

        fullIfaceList = []
	current = None
        def flush():
            if current != None:
                fullIfaceList.append( current )
        for line in dataList:
            mLine = re.match("([a-zA-Z0-9]+):(.*)", line)
	    if mLine:
                flush()
                current = Base.Struct()
                current.name = mLine.group(1)
                current.moreFlags = mLine.group(2)
                current.addressList = []
	    elif current!=None:
                # XXX: I assume one line per address
                if line.startswith("inet "):
                    data = line.split(" ")
                    addr = None
                    netmask = None
                    broadcast = None
                    while len(data)>0:
                       if data[0] == "inet":
                          addr = data[1] ; data = data[2:]
                       elif data[0] == "netmask":
                          netmask = data[1] ; data = data[2:]
                          if netmask.startswith("0x"):
                              netmaskAsInt = eval(netmask+"L")
                              netmask = ipv4LongToString(netmaskAsInt)
                       elif data[0] == "broadcast":
                          broadcast = data[1] ; data = data[2:]
                       else: 
                          # XXX: could print we are ignoring something
                          data = data[1:]
                    current.addressList.append( ("inet", addr, netmask, broadcast) ) 
                elif line.startswith("inet6 "):
                    #XXX: should handle IPv6
                    pass
                elif line.startswith("ether "):
                    #XXX: what if fails, or if there are several ethAddr?
                    current.ethAddr = line.split(" ")[1]
        flush()

        # Sort out iface list
        # XXX:Note: we remove loopback, and take the first IPv4
        self.fullIfaceList = []
        for iface in fullIfaceList:
            ok = False
            for ifaceAddr in iface.addressList:
                if ifaceAddr[0]=="inet":
                    unused, ipAddr, netMask, broadcast = ifaceAddr
                    if (ipAddr!=None and netMask!=None and broadcast!=None
                        and ipAddr!="127.0.0.1"):
                        iface.ipAddress = ipAddr
                        iface.netMask = netMask
                        iface.broadcast = broadcast
                        ok = True
                        break
            if ok: self.fullIfaceList.append(iface)

    def getIfaceList(self):
        return [x.ipAddress for x in self.getFullIfaceList()]

    def findIfaceByName(self, name):
        return [x for x in self.getFullIfaceList() if x.name == name][0]

    def setForwarding(self, ifaceName, value=1):
        #XXX!: unimplemented
        print "WARNING: setForwarding(%s,%s) is  unimplemented" \
              % (ifaceName, value)

    def getForwarding(self, ifaceName):
        #XXX!: unimplemented
        return 0

    def getIPAddress(self, ifaceName):
        return self.findIfaceByName(ifaceName).ipAddress

    def getNetmask(self, ifaceName):
        return self.findIfaceByName(ifaceName).netMask

    def getBroadcast(self, ifaceName):
        return self.findIfaceByName(ifaceName).broadcast

    def canonizeMask(self, netMask):
        value = ipv4StringToLong(netMask)
        nbBit = 0
        upperBit = 1L<<31
        while (value & upperBit) == upperBit:
            value = value << 1
            nbBit += 1
        return nbBit

    def getRouteArg(self, ifaceName, ipAddr, gwAddr, netMask):
        iface = self.findIfaceByName(ifaceName)
        if netMask == None: netMask = "255.255.255.255"
        else: netMask = "%s" % netMask # ensure it's a string.
        if ipAddr != gwAddr:
            cmd = ""
            if netMask == "255.255.255.255": cmd += " -host %s " % ipAddr
            else: cmd += " -net %s -netmask %s" % (ipAddr, netMask)
            cmd += "%s" % gwAddr
        else:
            # some not-quite-understood magic, found via groups.googgle
            # "-net, -netmask" necessary even in the case of a single entry
            cmd = "-net %s -netmask %s -iface %s -cloning" \
                  % (ipAddr, netMask, iface.ipAddress)
        return cmd

    def addRoute(self, ifaceName, ipAddr, gwAddr, netMask):
        self.delRoute(ifaceName, ipAddr, gwAddr, netMask) #XXX: uneeded
        cmd = "route add "
        cmd += self.getRouteArg(ifaceName, ipAddr, gwAddr, netMask)
	print "# %s" % cmd #XXX
	os.system(cmd)

    # Note: gwAddr was necessary because of *BSD magic.
    def delRoute(self, ifaceName, ipAddr, gwAddr, netMask):
        cmd = "route delete "
        cmd += self.getRouteArg(ifaceName, ipAddr, gwAddr, netMask)
	print "# %s" % cmd #XXX
        os.system(cmd)

#---------------------------------------------------------------------------

def isWindows():
    return sys.platform in ["cygwin"]

def getUnameSystem():
    return os.uname()[0]

class BSDSystem:
    def __init__(self, subname): self.subName = subname
    def getName(self): return "bsd"
    def makeInterfaceConfigurator(self, withIPv6):
        return BSDInterfaceConfigurator(withIPv6)

class LinuxSystem:
    def __init__(self): pass
    def getName(self): return "linux"
    def makeInterfaceConfigurator(self, withIPv6):
        return LinuxInterfaceConfigurator(withIPv6)

class WindowsSystem:
    def __init__(self): pass
    def getName(self): return "windows"
    def makeInterfaceConfigurator(self, withIPv6):
        return WinInterfaceConfigurator(withIPv6)

def getSystem():
    if isWindows(): return WindowsSystem() #XXX: check NT, 1998, etc...
    elif getUnameSystem() == "FreeBSD": return BSDSystem("freebsd")
    elif getUnameSystem() == "OpenBSD": return BSDSystem("openbsd")
    elif getUnameSystem() == "NetBSD": return BSDSystem("netbsd")
    elif getUnameSystem() == "Linux": return LinuxSystem()
    else: raise "Unknown system", os.uname()


#---------------------------------------------------------------------------

#XXX: factor out!
class SimulationAddress:
    def __init__(self, name, netAddress):
        self.name = name
        self.netAddress = netAddress
    def __hash__(self): return hash(self.netAddress)
    def __cmp__(self, other):
        if isinstance(other, SimulationAddress):
            return cmp(self.netAddress, other.netAddress)
        else: return False
    def __repr__(self): return self.name
    def toNet(self): return self.netAddress

IPv4Address = SimulationAddress
IPv6Address = SimulationAddress

class IPv4AddressFactory:
    def popFrontAddress(self, data):
        netAddress = data[0:4]
        (addressLong,) = struct.unpack("!L",netAddress)
        name = ipv4LongToString( addressLong )
        return SimulationAddress(name, netAddress), data[4:]
    def stringToAddress(self, ipDotAddr):
        return ipv4StringToAddress(ipDotAddr)

def unpackNetLong128(data):
    assert len(data)==16
    result = 0L
    for i in range(16):
        result += long(ord(data[i])) << (8L * (15-i))
    return result

def packNetLong128(data):
    result = ""
    for i in range(16):
        value = (data >> (8L*(15-i)))&255
        result += chr(value)
    return result

#print "%x" % unpackNetLong128("\1\0\0\0\0\0\0\0")

class IPv6AddressFactory:
    def popFrontAddress(self,data):
        netAddress = data[0:16]
        addressLong = unpackNetLong128(netAddress)
        name = ipv6LongToString( addressLong )
        return IPv6Address(name, netAddress), data[16:]
    def stringToAddress(self, ipDotAddr):
        return ipv6StringToAddress(ipDotAddr)
    
def ipv4LongToString(addressLong):
    byteList = [ "%d" % ((addressLong>>(8*i))&0xff) for i in 3,2,1,0 ]
    return ".".join(byteList)

def ipv6LongToString(addressLong):
    byteList = [ "%04x" % ((addressLong>>(16L*i))&0xffff) 
		 for i in 7,6,5,4,3,2,1,0 ]
    return ":".join(byteList)

def ipv6StringToLong(strAddress):
    if strAddress.startswith(":"):
	strAddress = "0" + strAddress
    data = strAddress.split(":")
    if '' in data:
        wildcardPos = data.index('')
        data1 = data[0:wildcardPos]
        data2 = data[wildcardPos+1:]
        data = data1 + ['0']*(8-len(data)+1) + data2
    data = map(lambda x: eval("0x"+x), data)
    result = 0L
    for i in data:
        result = (result<<16) | i
    return result

def ipv6StringToAddress(ipColonAddr):
    ipLongAddr = ipv6StringToLong(ipColonAddr)
    ipRawAddr = packNetLong128(ipLongAddr)
    return SimulationAddress(ipColonAddr, ipRawAddr)

def ipv4StringToLong(data):
    data = map(int, data.split("."))
    result = 0L
    for i in data:
        result = (result<<8) | i
    return result

def ipv4StringToAddress(ipDotAddr):
    ipLongAddr = ipv4StringToLong(ipDotAddr)
    ipRawAddr = struct.pack("!L", ipLongAddr)
    return SimulationAddress(ipDotAddr, ipRawAddr)

def ipv6Canonize(ipColonAddr):
    return ipv6LongToString(ipv6StringToLong(ipColonAddr))

#OLSRPort = 1680 #XXX: Constant

def isInNet(ipAddr, netAddr, netMask):
    ipAddrLong  = ipv4StringToLong(ipAddr)
    netAddrLong = ipv4StringToLong(netAddr)
    netMaskLong = ipv4StringToLong(netMask)
    return (ipAddrLong&netMaskLong) == netAddrLong

class RouteManager:
    def __init__(self, iface):
        self.iface = iface
        self.routeCache = {}
    def updateRoute(self, new):
        self.routeCache.items()
        pass

class FilenoFdHandler:
    def __init__(self, fileno, cb): self.fileno, self.cb = fileno, cb
    def fileno(self): return self.fileno
    def waitingForInput(self): return True
    def waitingForOutput(self): return False
    def waitingForExcept(self): return False
    def handleInput(self): cb()
    def handleOutput(self): raise "Impossible"
    def handleExcept(self): raise "Impossible"
    
class RealIface:
    def __init__(self, system, node, netConfig, withIPv6,
                 name, noListenBroadcast=0):
        self.node = node
        self.netConfig = netConfig
        if name == "<wireless>":
            name = netConfig.getWirelessIfaceList()[0]
        elif name == "<wired>":
            name = netConfig.getWiredIfaceList()[0]
        elif name.startswith("<wired-"):
            ifaceIdx = name.split("-")[1].strip(">")
            name = netConfig.getWiredIfaceList()[int(ifaceIdx)]
        self.name = name

        self.ipDotAddress = self.netConfig.getIPAddress( name )
        self.broadcastDotAddress = self.netConfig.getBroadcast( name )
        self.netConfig.setForwarding(self.name)
        self.system = system
	self.withIPv6 = withIPv6

        if not withIPv6:
            addressLong = ipv4StringToLong( self.ipDotAddress )
            netAddress = struct.pack("!L", addressLong)
            self.address = SimulationAddress( self.ipDotAddress, netAddress)
        else:
            # XXX: put elsewhere
            self.ipDotAddress = ipv6Canonize( self.ipDotAddress )
            addressLong = ipv6StringToLong( self.ipDotAddress )
            netAddress = packNetLong128(addressLong)
            self.address = SimulationAddress(self.ipDotAddress,netAddress)

        #self.socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        #self.socket.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)

        if withIPv6:
            self.sockRecv = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
	    s = self.sockRecv
	    s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
	    s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_MULTICAST_IF, 
	                 self.getIfaceIndex())
        else: 
	    self.sockRecv = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
	    self.sockRecv.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
	    self.sockRecv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

        self.sockSend = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        self.sockSend.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        self.sockSend.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
        if isWindows() or noListenBroadcast:
            self.sockRecv.bind((self.ipDotAddress, Constant.OLSRPort)) #XXX: check
        else: # (Linux) XXX! BSDs?
            if withIPv6:
		s.bind(('', Constant.OLSRPort))
		# ff02::1
		Hex_ff02__1 = chr(0xff)+chr(0x2)+13*chr(0)+chr(0x1)
		s.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_JOIN_GROUP, 
                 Hex_ff02__1 + struct.pack("I",self.getIfaceIndex()))
		print self.getIfaceIndex(), self.name
            else:
                #self.sockRecv.bind((self.broadcastDotAddr, Constant.OLSRPort))
                #self.sockRecv.bind((self.ipDotAddress, Constant.OLSRPort))
                #print "BIND TO",self.name

                print "Binding to interface '%s'" %self.name  # XXX!!! I don't understand this at all, without print, the following does not work.
                self.sockRecv.setsockopt(socket.SOL_SOCKET,
                                         socket.SO_BINDTODEVICE, self.name)
                self.sockRecv.bind(("255.255.255.255", Constant.OLSRPort))
                #print "XXX: tchanges in socket code"
                #self.sockSend.bind((self.ipDotAddress, Constant.OLSRPort))
                self.sockSend.setsockopt(socket.SOL_SOCKET,
                                         socket.SO_BINDTODEVICE, self.name)
                self.sockSend = self.sockRecv
                
                
        self.socket = self.sockRecv
        self.node.addFdHandler(self)
        #self.node.addFdHandler(FilenoFdHandler())

    def getIfaceIndex(self): # XXX: v6
	#XXX: implement for Windows and *BSD
	for x in parseInet6Dev():
	    if x[0] == self.name: return x[2]
	return None
	
    # AbstractFdHandler properties
    def fileno(self): return self.sockRecv.fileno()
    def waitingForInput(self): return True
    def waitingForOutput(self): return False
    def waitingForExcept(self): return False
    def handleInput(self): self._evReceivePacket()
    def handleOutput(self): raise "Impossible"
    def handleExcept(self): raise "Impossible"
        
    def getAddress(self):
        return self.address

    def sendPacket(self, packet):
        #print "sendPacket", self.name, self.ipDotAddress
        #XXX: python misleading error msg: sendto( (a,b), c)
	if self.withIPv6:
	    self.socket.sendto(packet, ("ff02::1", Constant.OLSRPort))
	else:
            if self.broadcastDotAddress != None:
            	#self.socket.sendto(packet, (self.broadcastDotAddress, Constant.OLSRPort))
                self.sockSend.sendto(packet, ("255.255.255.255", Constant.OLSRPort))
            else:
            	# For loopback ('lo'), and queries
            	self.socket.sendto(packet, (self.ipDotAddress, Constant.OLSRPort))
            #self.socket.sendto(packet, ("255.255.255.255", OLSRPort))
        
    def _evReceivePacket(self):
	if self.withIPv6:
	    data,(senderAddress,port,stuff1,stuff2) \
                 = self.sockRecv.recvfrom(65536) #XXX: size
	    #print data, senderAddress, port, stuff1, stuff2
	    if "%" in senderAddress:
                #print senderAddress, self.name  
		senderAddress, ifaceName = senderAddress.split("%")
                if ifaceName != self.name: return
                senderAddress = ipv6Canonize(senderAddress)
	    ipAddress = ipv6StringToAddress(senderAddress)
	else:
	    data,(senderAddress,port) = self.sockRecv.recvfrom(65536) #XXX: size
	    #if senderAddress != self.ipDotAddress:
	    ipAddress = ipv4StringToAddress(senderAddress)
        self.node.receivePacket(ipAddress, self, data)

    def getIdent(self): return self.name

#---------------------------------------------------------------------------

class RouteConfigurator:
    def __init__(self, netConfig):
        self.netConfig = netConfig
        self.routingTable = {}
        self.ifaceIdentToIface = {}

    def addIface(self, ifaceIdent, iface):
        self.ifaceIdentToIface[ifaceIdent] = iface
        
    def updateRoute(self, routeList):
        newRoutingTable = {}

        def rpr(mask):
            if mask==None: return ""
            elif repr(mask)=="255.255.255.255": return ""
            else: return repr(mask)

        # XXX: right now netmask is ignored is overlapping check...
        for nextHopAddr, netMask, ifaceIdent, destAddr, metric in routeList:
            ifaceIdent = "%s" % ifaceIdent
            if not self.ifaceIdentToIface.has_key(ifaceIdent):
                print "Warning ignored route with bad ifaceIdent:", repr(ifaceIdent), type(ifaceIdent)
                continue
            ifaceIdent = self.ifaceIdentToIface[ifaceIdent].name # XXX
            if not newRoutingTable.has_key(destAddr):
                newRoutingTable[destAddr] = (nextHopAddr, ifaceIdent, netMask, metric)
                
        for destAddr,(nextHopAddr, ifaceIdent,netMask, metric) \
                in self.routingTable.items():
            if not newRoutingTable.has_key(destAddr):
                # Remove obsolete entry
                self.netConfig.delRoute(ifaceIdent, destAddr, 
                                        nextHopAddr, netMask)
                print "Deleted route %s%s:%s -> %s" \
                      % (ifaceIdent, rpr(netMask), nextHopAddr, destAddr)
            elif (nextHopAddr,ifaceIdent,netMask) != newRoutingTable[destAddr]:
                # Changed a route
                (newNextHopAddr, newIfaceIdent, newNetMask, newMetric
                 )= newRoutingTable[destAddr]
                self.netConfig.delRoute(ifaceIdent, destAddr, 
                                        nextHopAddr, netMask)
                self.netConfig.addRoute(ifaceIdent, destAddr, newNextHopAddr,
                                        netMask, metric)
                print "Changed route %s%s:%s->%s to %s:%s->%s" % (ifaceIdent,
                   rpr(netMask), nextHopAddr, destAddr, newIfaceIdent,
                   newNextHopAddr,destAddr)
            else: pass # Same configuration as before.

        routeInfoList = [ (routeInfo[0]!=routeInfo[1][0], routeInfo)
                          for routeInfo in newRoutingTable.items() ]
        routeInfoList.sort()
        routeInfoList = [ routeInfo[1] for routeInfo in routeInfoList ]


        for destAddr,(nextHopAddr, ifaceIdent, netMask,metric) \
                in routeInfoList:
            if not self.routingTable.has_key(destAddr):
                # Add route to new destination
                self.netConfig.addRoute(ifaceIdent, destAddr, nextHopAddr,
                                        netMask, metric)
                print "Added route to new destination %s%s:%s -> %s" \
                      %(ifaceIdent, rpr(netMask), nextHopAddr, destAddr)

        self.routingTable = newRoutingTable

#---------------------------------------------------------------------------

#XXX remove
def execWith__unused(fileName, localDict):
    initialKeyList = localDict.keys()
    execfile(fileName, localDict, localDict)
    for key in initialKeyList + ["__builtins__"]:
        del localDict[key]
    result = Base.Struct()
    for key,value in localDict.items():
        result.__dict__[key]=value
    return result

#---------------------------------------------------------------------------

def evDisplay(node, displayInterval):
    print "------------- OLSR Node"
    node.computeRoutingTable()
    print node
    node.schedule(displayInterval, evDisplay, [node, displayInterval])

def runForReal(argList):
    system = getSystem()
    hnaList   = []
    ifaceList = []
    for arg in argList:
        if not arg.startswith("hna:"):
            ifaceList.append(arg)
        else:
            infoStr = arg[len("hna:"):].strip()
            if infoStr.find("@")<0:
                print "FATAL: not interface specified for HNA entry '%s'" % arg
                sys.exit(1)
            data = infoStr.split("@")
            hnaInfoStr = data[0]
            hnaIfaceName = data[1]
            if hnaInfoStr.find("/")<0:
                hnaAddr = hnaInfoStr
                hnaMask = "255.255.255.255" # XXX: ipv6
            else:
                hnaData = hnaInfoStr.split("/")
                hnaAddr = hnaData[0]
                hnaMask = hnaData[1]
            hnaList.append( (hnaAddr, hnaMask, hnaIfaceName) )

    config = Base.Struct()
    config.withIPv6 = 0
    config.displayInterval = 3.0
    config.hnaList = hnaList
    config.interfaceList = ifaceList
    runForRealWithConfig(config)

#---------------------------------------------------------------------------

def runForRealWithConfig(config):
    def inConfig(x): return config.__dict__.has_key(x)
    system = getSystem()

    #XXX! hnaList = []
    displayInterval = None
    withIPv6 = 0
    #XXX monitorPrefix = None
    
    if inConfig("interfaceList"):
        ifaceList = config.interfaceList
    else: raise "No interface (interfaceList) specified in configuration file"
    
    #XXX! if inConfig("hnaList"): hnaList = config.hnaList
    if inConfig("displayInterval"): displayInterval = config.displayInterval
    if inConfig("withIPv6"): withIPv6 = config.withIPv6
    #XXX if inConfig("monitorPrefix"): monitorPrefix = config.monitorPrefix

    if withIPv6: IPAddressFactory = IPv6AddressFactory
    else: IPAddressFactory = IPv4AddressFactory
    
    addressFactory = IPAddressFactory()
    netConfig = system.makeInterfaceConfigurator(withIPv6)
    #XXX: remove: packetizer = PacketFormat.Packetizer( IPAddressFactory() )
    
    scheduler = Scheduler.RealTimeScheduler()

    logManager = Record.LogManager()
    logManager.openForWrite("/tmp/pyOLSRLog", "real")
    olsr = Node.PyNode(scheduler, config, logManager)
    #XXX: olsr.setSystem(system)
    #XXX: olsr.setMonitorPrefix(monitorPrefix)

    routeConfigurator = RouteConfigurator(netConfig)

    
    realIfaceTable = {}
    for ifaceName in ifaceList:
        realIface = RealIface(system, olsr, netConfig,
                              config.withIPv6, ifaceName)
        realIfaceTable[ifaceName] = realIface
        routeConfigurator.addIface(realIface.ipDotAddress, realIface)
    olsr.setIfaceList( [realIfaceTable[x] for x in ifaceList] )
    olsr.setAddressFactory( addressFactory )

    olsr.setRouteConfigurator(routeConfigurator)

    if displayInterval != None:
        olsr.schedule(displayInterval, evDisplay, [olsr,displayInterval])
    olsr.start()
    scheduler.run()

#---------------------------------------------------------------------------

def showIface(*argList):
    thisSystem = getSystem()
    if thisSystem.getName() == "windows":
        ifaceList = WinInterfaceConfigurator().getFullIfaceList()
        ifaceList.sort()
        print "List of interfaces:"
        for info in ifaceList:
            print "%s: '%s'\n   (ip=%s netmask=%s)" \
                  % (info[0], info[1], info[2], info[3])
    elif thisSystem.getName() in ["freebsd", "openbsd", "netbsd", "bsd"]:
        ifaceList = BSDInterfaceConfigurator().getFullIfaceList()
        print "List of IPv4 interfaces (loopback excluded):"
        for iface in ifaceList:
            print "%s: (ipv4) ip=%s netmask=%s broadcast=%s\n" \
              % (iface.name, iface.ipAddress, iface.netMask, iface.broadcast)
    elif thisSystem.getName() == "linux":
        ifaceList = LinuxInterfaceConfigurator(False).getIfaceList()
        print "List of interfaces: ", " ".join(ifaceList)
    else: raise "Unknown (unexpected here?) system", thisSystem

#---------------------------------------------------------------------------

#XXX: No scheduler is really needed?
class OLSRQueryManager:
    def __init__(self):
        self.scheduler = Scheduler.RealTimeScheduler()        
        self.addressFactory = IPv4AddressFactory()
        self.system = getSystem()
        self.netConfig = self.system.makeInterfaceConfigurator()        
        self.packetizer = PacketFormat.Packetizer( self.addressFactory )
        self.ifaceList = [ RealIface(self.system,self, self.netConfig,
                                     0, ifaceName, 1)
                           for ifaceName in self.netConfig.getIfaceList()
                           if ifaceName not in ["sit0", "lo"]]

    def sendPacket(self, packet, ifaceNameList):
        ifaceList = [ RealIface(self.system,self, self.netConfig, ifaceName, 1)
                      for ifaceName in self.netConfig.getIfaceList()
                      if ifaceName in ifaceNameList]
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        for iface in ifaceList:
            #s.sendto( packet, (iface, OLSRPort))
            iface.sendPacket(packet)

    def addFdHandler(self, handler): self.scheduler.addFdHandler(handler)        
    def receivePacket(self, ipAddress, iface, packet):
        print ipAddress, iface, packet

#---------------------------------------------------------------------------

if __name__ == "__main__": testConfigurator()

#---------------------------------------------------------------------------
