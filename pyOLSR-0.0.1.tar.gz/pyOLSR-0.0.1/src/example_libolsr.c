/*---------------------------------------------------------------------------*
 *
 *                             pyOLSR
 *
 *             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
 *
 *  Copyright 2003 Institut National de Recherche en Informatique et  
 *  en Automatique.  All rights reserved.  Distributed only with permission.
 *---------------------------------------------------------------------------
 * A demonstration of the OLSR library.
 *---------------------------------------------------------------------------*/

#include <stdlib.h>
#include <assert.h>
#include <stdio.h>

#include "olsrapi.h"

/*---------------------------------------------------------------------------*/

typedef struct {
  double clock;
  OLSR_callback_func callback;
  void* data;
} SchedulerEvent;

#define MAX_SCHEDULER_EVENT 4096

static double currentClock;
static int lastEvent = 0;
static SchedulerEvent event [MAX_SCHEDULER_EVENT];

static void schedule(double relTime, 
		     OLSR_callback_func callback,
		     void* data)
{
  int i;
  int limit = lastEvent+1 < MAX_SCHEDULER_EVENT ?
    lastEvent+1 : MAX_SCHEDULER_EVENT;
  for(i=0;i<limit;i++) {
    if (event[i].callback == NULL) {
      assert( relTime >= 0);
      event[i].clock = currentClock + relTime;
      event[i].callback = callback;
      event[i].data = data;
      if(i+1>lastEvent) lastEvent = i+1;
      return;
    }
  }
  fprintf(stderr,"Scheduler Event overflow\n");
  abort();
}

static void schedule_until(double clockLimit)
{
  for(;;) {
    double bestClock = clockLimit;
    int bestEvent = -1;
    SchedulerEvent currentEvent;
    int i;
    for(i=0;i<=lastEvent;i++) 
      if (event[i].callback!=NULL && event[i].clock<bestClock) {
	bestEvent = i;
	bestClock = event[i].clock;
      }
    if (bestEvent<0) return; /*finished*/
    
    currentEvent = event[bestEvent];
    memset(&(event[bestEvent]), 0, sizeof(event[bestEvent]));
    assert( currentClock <= currentEvent.clock);
    currentClock = currentEvent.clock;
    currentEvent.callback(currentClock, currentEvent.data);
  }
}

double get_clock()
{ return currentClock; }

/*---------------------------------------------------------------------------*/

int nbNode=0;
int nbIface=0;
OpaqueOLSRNode* nodeArray=NULL;

void* memdup(void* data, int size)
{ 
  void* result = malloc(size);
  memcpy(result, data, size);
  return result;
}

void send_func(OpaqueOLSRNode src,
	       void* address, int addressSize,
	       void* packet, int packetSize)
{
  int i;
  int pos = *(int*)(olsrapi_node_get_id(src));
  assert( 0<=pos && pos<nbNode );
  for(i=0;i<nbIface;i++) {
    if(pos-i-1>=0)
      olsrapi_node_receive(nodeArray[pos-i-1], i,
			   memdup(address, addressSize), addressSize,
			   memdup(packet, packetSize), packetSize);

    if(pos+i+1<nbNode)
      olsrapi_node_receive(nodeArray[pos+i+1], i,
			   memdup(address, addressSize), addressSize,
			   memdup(packet, packetSize), packetSize);
    if(pos+i+2<nbNode)
      olsrapi_node_receive(nodeArray[pos+i+2], i,
			   memdup(address, addressSize), addressSize,
			   memdup(packet, packetSize), packetSize);
  }
  free(address);
  free(packet);
}


main(int argc, char** argv)
{
  int i;

  OpaqueOLSRAPI api;

  if(argc != 3) {
    fprintf(stderr,"Syntax: %s <nbNode> <nbInterface>\n", argv[0],
	    argv[1]);
    exit(EXIT_FAILURE);
  }

  memset(event, 0, sizeof(SchedulerEvent));

  olsrapi_init();
  api = olsrapi_create(schedule, get_clock, send_func);

  nbNode = atoi(argv[1]);
  nbIface = atoi(argv[2]);
  assert( nbNode > 0 );
  nodeArray = (OpaqueOLSRNode*)malloc(sizeof(OpaqueOLSRNode)*nbNode);
  for(i=0;i<nbNode;i++) {
    int* id = (int*)malloc(sizeof(int));
    *id = i;
    nodeArray[i] = olsrapi_create_node(api, id, nbIface);
  }

  for(i=0;i<nbNode;i++)
    olsrapi_node_start(nodeArray[i]);

  schedule_until(20.0);

  for(i=0;i<nbNode;i++) {
    olsrapi_node_free(nodeArray[i]);
    nodeArray[i] = NULL;
  }

  olsrapi_free(api);
  exit(EXIT_SUCCESS);
}

/*---------------------------------------------------------------------------*/
