#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
#
#---------------------------------------------------------------------------
# TODO:
# - use Constant.py
#---------------------------------------------------------------------------

C = 0.0625             # @>>3771  XXX -> Constant.py

PacketHeaderSize = 4   # @>>867
MinPacketSize = 12     # @>>926-927
                       # @>>1080-1081
# XXX! IPv4/IPv6 size, etc...

MessageHeaderSizeWithoutAddress = 8 # @>>869-873

# @>>3884-3893
MessageType = {
    "hello":1, # @>>3887
    "tc":2,    # @>>3889
    "mid":3,   # @>>3891
    "hna":4    # @>>3893
}

# @>>3896-3905
LinkType = {
    "UNSPEC_LINK": 0, # @>>3899
    "ASYM_LINK": 1,   # @>>3901
    "SYM_LINK":2,     # @>>3903
    "LOST_LINK":3     # @>>3905
}

# @>>3908-3916
NeighborType = {
    "NOT_NEIGH": 0, # @>>3911
    "SYM_NEIGH": 1, # @>>3913
    "MPR_NEIGH": 2  # @>>3915
}


#---------------------------------------------------------------------------

import operator, exceptions, struct, math
import pdb

import TupleSet

from Constant import SYM_NEIGH, MPR_NEIGH, NOT_NEIGH, SYM_LINK

#---------------------------------------------------------------------------

def findByValue(dict, value):
    for key,valueOfKey in dict.items():
        if value == valueOfKey: return key
    raise exceptions.KeyError, value

#---------------------------------------------------------------------------

def toMantissaExponentByte(value):
    floating = value/float(C)
    b = int(math.log(floating)/math.log(2.0)) # @>>3861
    a = int(math.ceil(16*(floating/(1<<b)-1.0))) # @>>3871-3872
    if a == 16: # @>>3874
        b += 1 ; a = 0
    assert 0<=a<16 and 0<=b<16 # @>>3876
    return a * 16 + b # @>>3877

def fromMantissaExponentByte(value):
    mantissa = (value>>4)
    exponent = value & 0xf
    return C * (1+mantissa/16.0) * (1 << exponent) # !3790 @>3842-3844

#---------------------------------------------------------------------------

class DuplicateTuple:
    def __init__(self): # @>>1045-1052
        self.D_addr = None # @>>1047
        self.D_seq_num = None # @>>1048
        self.D_retransmitted = None # @>>1048-1050
        self.D_iface_list = None # @>>1050-1051
        self.D_time = None # @>>1051-1052

        self.event = None

class DuplicateSet(TupleSet.TupleSet): # @>>1054-1055
    def isExpired(self, entry): return entry.D_time < self.node.getTime()
    
    def find(self, D_addr, D_seq_num): # @>>1093-1095
        return self.findFirst(lambda x: x.D_addr == D_addr
                              and x.D_seq_num == D_seq_num)

#---------------------------------------------------------------------------

class Message:
    def __init__(self):
        # Message Header information !757-761 @>868-873
        self.messageType = None
        self.vtime = None
        self.messageSize = None
        self.originatorAddress = None
        self.timeToLive = None
        self.hopCount = None
        self.messageSequenceNumber = None

        # Packet additionnal information
        self.sendIfaceAddress = None # Sender interface address
        self.recvIfaceAddress = None # Receiver interface address
        self.rawContent = None
        self.content = None

    #def serialize(self):
    #    return repr(self.__dict__)

    #def unserialize(self, data):
    #    self.__dict__ = eval(data)

    def clone(self):
        #XXX: This is actually a shallow copy
        result = Message()
        for name in ["messageType", "vtime", "messageSize",
                     "originatorAddress", "timeToLive", "hopCount",
                     "messageSequenceNumber", "sendIfaceAddress",
                     "recvIfaceAddress", "content", "rawContent"]:
            result.__dict__[name] = self.__dict__[name]
        return result

    def getValidityTime(self): # !3786-3790 @>3837-3843
        return fromMantissaExponentByte(self.vtime)

    def __repr__(self):
        return "<%s>" % repr(self.__dict__)

    def withValue(self, type, ttl, hopCount, expireTime, originatorAddress):
        self.messageType = MessageType[type]
        self.timeToLive = ttl
        self.hopCount = hopCount
        self.vtime = toMantissaExponentByte(expireTime)
        self.originatorAddress = originatorAddress
        return self

#---------------------------------------------------------------------------

class AbstractAddressFactory:
    def addressToNet(self, address): undefined
    def popAddress(self, data):      undefined
    def reprAddress(self, address):  undefined
    def getAddressSize(self, addr):  undefined

class PacketFormatError(exceptions.Exception):
    def __init__(self, error, packet, isWarning=False):
        exceptions.Exception.__init__(self)
        self.error = error
        self.packet = packet
        self.isWarning = isWarning
    def __str__(self):
        return (self.error+" - src address = %s, packet size=%s"
                % (self.packet.sendIfaceAddress, self.packet.size()))
    def __repr__(self):
        return self.__str__()

class PacketBuffer:
    def __init__(self, sendIfaceAddress, recvIfaceAddress, packet, node):
        self.sendIfaceAddress = sendIfaceAddress
        self.recvIfaceAddress = recvIfaceAddress
        self.addressFactory = node
        self.data = packet

    def raiseError(self, error, isWarning = False):
        raise PacketFormatError(error, self, isWarning)

    def raiseWarning(self, warning):
        self.raiseError(warning, True)
        
    def popSubBuffer(self, size):
        if size > len(self.data):
            self.raiseError("packet too short")
        resultData = self.data[0:size]
        self.data = self.data[size:]
        return PacketBuffer(self.sendIfaceAddress, self.recvIfaceAddress,
                            resultData, self.addressFactory)
        
    def popFrontStruct(self, spec):
        assert spec[0] == '!' # usually true, checking caller oversights
        specSize = struct.calcsize(spec)
        if specSize > len(self.data): self.raiseError("packet too short")
        result = struct.unpack(spec, self.data[:specSize])
        self.data = self.data[specSize:]
        return result

    def popFront(self, size):
        if size > len(self.data):
            self.raiseError("packet too short (%s<%s)" % (len(self.data),size))
        result = self.data[0:size]
        self.data = self.data[size:]
        return result

    def popFrontAddress(self):
        rawAddress = self.popFront(self.addressFactory.getAddressSize())
        return self.addressFactory.netToAddress(rawAddress)

    def size(self): return len(self.data)
    
    def crop(self, size):
        assert size >= len(self.data)
        self.data = self.data[:size]

#---------------------------------------------------------------------------

class HelloMessage: # !1264-1279 @>1690-1707
    def __init__(self):
        #self.transmissionInterfaceAddress = None
        self.htime = None
        self.willingness = None
        self.linkList = None

    def clone(self):
        raise Unimplemented

    def __repr__(self):
        return "<%s>" % repr(self.__dict__)

#--------------------------------------------------

class LinkEntry: # !1266-1270 @>1692-1697
    def __init__(self):
        self.neighborType = None
        self.linkType = None
        self.address = None

    def __repr__(self):
        return "%s:%s,%s" % (self.address,
                             findByValue(NeighborType, self.neighborType),
                             findByValue(LinkType, self.linkType))

class HelloMessageHandler:
    def __init__(self, node):
        self.node = node

    def processMessage(self, message):
        message = self._parseMessageContent(message)
        self.node.processHelloMessage(message)
        
    def considerForwardMessage(self, message, packetManager):
        # Do nothing, as mandatory. @>>1999
        return

    def sendMessage(self, ifaceList, message, packetManager):
        message = self._packMessageContent(message, packetManager)
        packetManager.sendSerializedMessage(ifaceList, message)
        
    def _parseMessageContent(self, m):
        m = m.clone()
        helloContent = HelloMessage()
        #XXX: should put 'context' inside the PacketBuffer for errors display
        buffer = PacketBuffer(m.sendIfaceAddress, m.recvIfaceAddress,
                              m.rawContent, self.node)
        (reserve, helloContent.htime, helloContent.willingness,
         ) = buffer.popFrontStruct("!HBB") # !1264 @>1690-1691
        helloContent.linkList = []
        # !1266-1280 @>1692-1707
        while buffer.size() >0: # XXX: not well documented in the draft
            linkCode, reserved, size \
                      = buffer.popFrontStruct("!BBH") # !1266 @>1692-1693
            size -= struct.calcsize("!BBH") # !1353-1356 @>1780-1785
            rawLinkMessage = buffer.popSubBuffer(size)
            if linkCode >= 15:  # !1339 @>2676-2679,1365
                continue
            neighborType = linkCode >> 2 # !1372 @>1807-1808
            linkType = linkCode & 0x3 # !1372 @>1807-1808
            if neighborType not in (SYM_NEIGH, MPR_NEIGH, NOT_NEIGH):
                continue # XXX !noref but implicit
            if (linkType == SYM_LINK and neighborType == NOT_NEIGH):
                continue #!1413-1415 @>1745-1746
            while rawLinkMessage.size() > 0: # !1268-1270 @>1694-1697
                entry = LinkEntry()
                entry.neighborType = neighborType
                entry.linkType = linkType
                entry.address = rawLinkMessage.popFrontAddress() # !1268 @>1694-1695
                helloContent.linkList.append(entry)
        m.rawContent = None
        m.content = helloContent
        return m

    def _packMessageContent(self, message, packetManager):
        # The opposite of _parseMessageContent
        perLinkCode = {}
        for entry in message.content.linkList:
            assert 0<= entry.neighborType < 4
            assert 0<= entry.linkType < 4
            # XXX: check -1413
            linkCode = (entry.neighborType << 2) | entry.linkType # !1372 @>1807-1808
            if not perLinkCode.has_key(linkCode):
                perLinkCode[linkCode] = []
            perLinkCode[linkCode].append(entry.address.toNet())

        rawContent = struct.pack("!HBB", 0, message.content.htime,
                                  message.content.willingness) # !1264 @>1690-1691

        # !1264-1279 @>1690-1707
        for linkCode, rawAddressList in perLinkCode.items():
            linkMessageContent = "".join(rawAddressList)
            size = len(linkMessageContent)+struct.calcsize("!BBH")
            linkHeader = struct.pack("!BBH", linkCode, 0, size) # !1266 @>1692-1693
            rawContent += linkHeader + linkMessageContent # !1268-1270 @>1694-1697

        newMessage = message.clone()
        newMessage.content = None
        newMessage.rawContent = rawContent
        return newMessage
                
#--------------------------------------------------

class TCMessage: # @>>2605-2618
    def __init__(self):
        self.ANSN = None        # @>>2610
        self.reserved = None    # @>>2610
        self.addressList = None # @>>2611-2616

    def __repr__(self):
        return "<%s>" % repr(self.__dict__)

class BaseHandler: #XXX: HELLOMessageHandler should inherit from this.
    def processMessage(self, message):
        message = self._parseMessageContent(message)
        self.reallyProcessMessage(message)
    
    def sendMessage(self, ifaceList, message, packetManager):
        message = self._packMessageContent(message, packetManager)
        packetManager.sendSerializedMessage(ifaceList, message)

    def _packMessageContent(self, message, packetManager): ABSTRACT

class TCMessageHandler(BaseHandler):
    def __init__(self, node):
        self.node = node

    def considerForwardMessage(self, message, packetManager): # @>>2724
        packetManager.defaultForwardingMessage(message) # @>>2727-2728

    def reallyProcessMessage(self, message):
        self.node.processTCMessage(message)

    def _parseMessageContent(self, m):
        m = m.clone()
        tcContent = TCMessage()
        #XXX: should put 'context' inside the PacketBuffer for errors display
        buffer = PacketBuffer(m.sendIfaceAddress, m.recvIfaceAddress,
                              m.rawContent, self.node)
        (tcContent.ANSN, tcContent.reserved
         ) = buffer.popFrontStruct("!HH") # @>>2610
        tcContent.addressList = []
        while buffer.size() >0: # XXX: not well documented in the draft (?)
            address = buffer.popFrontAddress() # @>>2612-2616
            tcContent.addressList.append(address)
        m.rawContent = None
        m.content = tcContent
        return m

    def _packMessageContent(self, message, packetManager):
        # The opposite of _parseMessageContent
        rawContent = struct.pack("!HH", message.content.ANSN,
                                 message.content.reserved) # @>>2610
        rawContent += "".join([x.toNet() # @>>2612-2616
                               for x in message.content.addressList])

        newMessage = message.clone()
        newMessage.content = None
        newMessage.rawContent = rawContent
        return newMessage

#--------------------------------------------------

class MIDMessage: # @>>1493-1512
    def __init__(self):
        self.addressList = None # @>>1500-1504

    def __repr__(self):
        return "<%s>" % repr(self.__dict__)


class MIDMessageHandler(BaseHandler):
    def __init__(self, node):
        self.node = node

    def considerForwardMessage(self, message, packetManager): # @>>1558
        packetManager.defaultForwardingMessage(message) # @>>1560-1563

    def reallyProcessMessage(self, message):
        self.node.processMIDMessage(message)

    def _parseMessageContent(self, m):
        m = m.clone()
        midContent = MIDMessage()
        #XXX: should put 'context' inside the PacketBuffer for errors display
        buffer = PacketBuffer(m.sendIfaceAddress, m.recvIfaceAddress,
                              m.rawContent, self.node)
        midContent.addressList = []
        while buffer.size() >0: # XXX: not well documented in the draft (?)
            address = buffer.popFrontAddress() # @>>1500-1504
            midContent.addressList.append(address)
        m.rawContent = None
        m.content = midContent
        return m

    def _packMessageContent(self, message, packetManager):
        # The opposite of _parseMessageContent
        rawContent = "".join([x.toNet() # @>>1500-1504
                              for x in message.content.addressList])
        newMessage = message.clone()
        newMessage.content = None
        newMessage.rawContent = rawContent
        return newMessage

#---------------------------------------------------------------------------

class PacketManager:
    def __init__(self, node):
        self.node = node
        self.addressFactory = node
        self.messageTypeHandler = {}

        self.messageTypeHandler[MessageType["hello"]] \
             = HelloMessageHandler(node)
        self.messageTypeHandler[MessageType["tc"]] \
             = TCMessageHandler(node)
        self.messageTypeHandler[MessageType["mid"]] \
             = MIDMessageHandler(node)

        self.messageSequenceNumber = 0

    def allocMessageSequenceNumber(self): # @>>1024-1033
        result = self.messageSequenceNumber
        self.messageSequenceNumber += 1 # @>>1029
        if self.messageSequenceNumber >= (1<<16):
            print "WRAP: before", self.messageSequenceNumber # XXX!!
            self.messageSequenceNumber = 0 # @>>4001-4002
            print "WRAP: after", self.messageSequenceNumber
        return result

    #----  Misc:
    def log(self, message):
        #XXX!
        print message
        
    #---- Messagizer/Packetizer
    
    def sendMessage(self, ifaceList, m):
        handler = self.messageTypeHandler.get(m.messageType, None)
        if handler != None:
            handler.sendMessage(ifaceList, m, self)
        else:
            if m.rawContent != None:
                self.sendSerializedMessage(ifaceList, m)
            else:
                self.log("Ignored message for lack of handler: type = %d"
                         % m.messageType)

    def _packetize(self, iface, rawMessageList):
        # XXX! do something about too packet size overflow
        rawPacketContent = "".join(rawMessageList)
        size = PacketHeaderSize + len(rawPacketContent)
        rawPacket = struct.pack("!HH", size, iface.allocSequenceNumber())
        rawPacket += rawPacketContent
        return rawPacket

    def _packMessage(self, m):
        # @>>866-874
        size = (MessageHeaderSizeWithoutAddress + self.node.getAddressSize()
                +len(m.rawContent))
        assert 0<= m.vtime < (1<<8)
        assert 0<= size < ((1<<16)-4) # XXX: what is the max message size?
        rawMessage = struct.pack("!BBH", m.messageType,
                                 m.vtime, size) # @>>869
        rawMessage += m.originatorAddress.toNet() # @>>871
        rawMessage += struct.pack("!BBH", m.timeToLive, m.hopCount,
                                  m.messageSequenceNumber) # @>>873
        rawMessage += m.rawContent
        return rawMessage

    def sendSerializedMessage(self, ifaceList, m):
        rawMessage = self._packMessage(m)
        for iface in ifaceList:
            rawPacket = self._packetize(iface, [rawMessage])
            self.node.sendPacket(iface, rawPacket)

    #---- Depacketizer/Processing/Forwarding

    # ----> This is the real entry point for receiving of packets
    def processPacket(self, sendIfaceAddress, recvIfaceAddress,
                      rawPacket): # @>>1036-1225
        packet = PacketBuffer(sendIfaceAddress, recvIfaceAddress,
                              rawPacket, self.addressFactory)
        messageList, packetSequenceNumber = self._parsePacket(packet)

        # XXX! not implemented? : @>>1076-1081, Processing - step 1
        
        # @>>1036-1045,
        for msg in messageList:
            # @>>1083-1087, Processing - step 2
            if (msg.timeToLive <= 0
                or msg.originatorAddress == self.node.getMainAddress()):
                continue

            # extra implementation related step 
            handler = self.messageTypeHandler.get(msg.messageType, None)
            
            # @>>1089-1103, Processing - step 3
            duplicateTuple = self.node.duplicateSet.find(
                msg.originatorAddress, msg.messageSequenceNumber)
            
            if duplicateTuple == None: # @>>1091 step 3.1
                if handler != None: # @>>1100-1102 - step 3.2
                    handler.processMessage(msg)
                else: pass # we don't know how to process this - just pass
            else: pass # @>>1097-1098 - step 3.1

            if (duplicateTuple != None # @>>1106-1114 - step 4.1
                and msg.recvIfaceAddress in duplicateTuple.D_iface_list):
                pass # @>>1116-1117
            else: # step 4.2:
                if handler != None: # @>>1129-1133 - step 4.2.1
                    handler.considerForwardMessage(msg, self)
                else: # @>>1135-1139 - step 4.2.2
                    handler.defaultForwardingMessage(msg)

    def defaultForwardingMessage(self, msg): # @>>1142-1225
        # Default Forward Algorithm step 1
        # XXX!!! check "symmetric 1-hop neighborhood of the _node_"
        # or "_interface_"
        if not self.node.isSymmetricNeighbor(self.node.ifaceToMainAddress(
            msg.sendIfaceAddress)):
            return # @>>1146-1149

        # Default Forward Algorithm step 2
        duplicateTuple = self.node.duplicateSet.findFirst(
            lambda x: (x.D_addr == msg.originatorAddress # @>>1153
                       and x.D_seq_num == msg.messageSequenceNumber)) # @>>1155
        if duplicateTuple != None:
            if (not duplicateTuple.D_retransmitted # @>>1160-1163
                and msg.recvIfaceAddress not in duplicateTuple.D_iface_list):
                pass # @>>1157-1158
            else: return
        else: pass # @>>1166-1167, Default Forward Algorithm step 3

        # Default Forward Algorithm step 4 @>>1183-1186
        willRetransmit = (self.node.isMPRSelector(self.node.ifaceToMainAddress(
            msg.sendIfaceAddress)) and msg.timeToLive > 1)

        # Default Forward Algorithm step 5 @>>1188-1211
        if duplicateTuple != None: # @>>1200
            duplicateTuple.D_time = (self.node.getLastTime() # @>>1192
                                     + self.node.config.DUP_HOLD_TIME) 
            duplicateTuple.D_iface_list.append(msg.recvIfaceAddress) # @>>1194
            if willRetransmit: # @>>1197-1198
                duplicateTuple.D_retransmitted = willRetransmit
            duplicateTuple.event = self.node.getLastEvent()                
        else: # @>>1200
            duplicateTuple = DuplicateTuple()
            duplicateTuple.D_addr = msg.originatorAddress # @>1202
            duplicateTuple.D_seq_num = msg.messageSequenceNumber # @>1204
            duplicateTuple.D_time = (self.node.getLastTime() # @>>1206
                                     + self.node.config.DUP_HOLD_TIME)
            duplicateTuple.D_iface_list = [msg.recvIfaceAddress] # @>>1208
            # @>>1210 XXX!!! "... and set to false otherwise"
            duplicateTuple.D_retransmitted = willRetransmit # @>>1210-1211
            duplicateTuple.event = self.node.getLastEvent()
            self.node.duplicateSet.add(duplicateTuple)

        if not willRetransmit: return # @>>1214-1215

        newMsg = msg.clone()
        newMsg.timeToLive -= 1   # @>>1218 step 6
        newMsg.hopCount += 1     # @>>1220 step 7
        self.sendSerializedMessage(self.node.getIfaceList(),
                                   newMsg) # @>>1210-1211 step 8

    def parsePacket(self, sendIfaceAddress, recvIfaceAddress, rawPacket):
        """Parses the content of a packet
        (used outside the pyOLSR core).
        
        sendIfaceAddress and recvIfaceAddress are just for information
        purpose and are reported in the resulting messages.

        rawPacket is a string holding the bytes of the packet.
        """
        packet = PacketBuffer(sendIfaceAddress, recvIfaceAddress,
                              rawPacket, self.addressFactory)
        return self._parsePacket(packet)

    def parseMessage(self, msg):
        """Parses the content of a message, according to its type
        and return an appropriate message
        (used outside the pyOLSR core).

        the result object class depends on the message (HelloMessage
        for a HELLO, etc..., or as-is for an unsupported message)
        """
        handler = self.messageTypeHandler.get(msg.messageType, None)
        if handler == None: return msg
        else: return handler._parseMessageContent(msg)
        
    def _parsePacket(self, packet):
        if packet.size()<MinPacketSize: # !805 @>3591-3594
            packet.raiseWarning("packet absolutly too short")
            return
        packetLength,packetSequenceNumber = packet.popFrontStruct("!HH")
        packetLength -= PacketHeaderSize
        if packetLength > packet.size():
            packet.raiseError("packet too short: "+
                              "field 'Packet Length' > actual packet size")
        if packetLength < packet.size():
            packet.raiseWarning("packet too long, field 'Packet Length' <"+\
                              " actual packet size")
            packet.crop(packetLength)

        messageList = []
        finished = False
        while packet.size() > 0 and not finished:
            # XXX: this processing will throw away a whole packet content
            # if there is any error in any message.
            message = self._popMessage(packet)
            if message != None:
                messageList.append(message)
            else: finished = True
        return messageList, packetSequenceNumber

    def _popMessage(self, packet): # !757-761 @>868-873
        MessageHeaderSize = (MessageHeaderSizeWithoutAddress
                             + self.addressFactory.getAddressSize())
        m = Message()
        m.messageType, m.vtime, m.messageSize \
                       = packet.popFrontStruct("!BBH")
        m.originatorAddress = packet.popFrontAddress()
        (m.timeToLive, m.hopCount, m.messageSequenceNumber
         ) = packet.popFrontStruct("!BBH")
        if m.messageSize < MessageHeaderSize:
            packet.raiseWarning("advertised message size too small")
            return None
        m.rawContent = packet.popFront(m.messageSize - MessageHeaderSize)
        m.sendIfaceAddress = packet.sendIfaceAddress
        m.recvIfaceAddress = packet.recvIfaceAddress
        return m

#---------------------------------------------------------------------------
