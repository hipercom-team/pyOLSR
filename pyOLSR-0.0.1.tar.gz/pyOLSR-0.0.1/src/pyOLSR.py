#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

import sys, pdb
import Base, Node, RealWorld, Record

#---------------------------------------------------------------------------

def usage():
    print "FATAL: ", " ".join(sys.argv)
    print """Syntax: %s <configuration file>""" % sys.argv[0]
    sys.exit(1)

#---------------------------------------------------------------------------

# pop empty args
argList = sys.argv[1:]
while len(argList)>0 and argList[-1] == "":
    argList = argList[:-1]

if len(argList)<1:
    usage()

if 0: #XXX: put back:
    if argList[1] == "simul":
        if len(argList)<3: usage()
        if argList[2] != "name":
            if len(argList) not in [3,4]: usage()
            else: Simulation.mainRunScenario(argList[2], argList[3:])
        else:
            if len(argList) not in [4,5]: usage()
            else:
                scenarioString = Simulation.ScenarioTable[argList[3]]
                print "Scenario '%s':\n  %s" % (argList[3], scenarioString)
                Simulation.mainRunScenario(scenarioString, argList[4:])
    elif argList[1] == "real":
        RealWorld.runForReal( argList[2:] )

#---------------------------------------------------------------------------
# Parse arguments

withProfiler = False # XXX: unimplemented
withDebugger = False # XXX: unimplemented

while len(argList)>0:
    if argList[0] == "--profile":
        withProfiler = True
        argList = argList[1:]
    elif argList[0] == "--debugger":
        withDebugger = True
        argList = argList[1:]
    else: break

# Sanity check
if withProfiler and withDebugger:
    raise FatalError, "Profiler and debugger are mutually exclusive"

#---------------------------------------------------------------------------

def run(argList):
    if argList[0] == "iface":
        RealWorld.showIface(argList[2:])
    else:
        print "%s: Using configuration file '%s'" % (sys.argv[0], argList[0])
        olsrConfig = Node.Config()
        config = Base.Struct()
        config.config = olsrConfig
        config.logConfig = Record.LogConfig()
        config.configType = "real"
        config.withIPv6 = False # default value
        info = {"configFileName": argList[0],
                "commandLineArgList": argList[1:],
                "withProfiler": withProfiler,
                "withDebugger": withDebugger
                }
        config = Base.execWith(argList[0], info, config)
        RealWorld.runForRealWithConfig(config)

if withDebugger:
    pdb.run("run(%s)" % argList)
elif withProfiler:
    XXX.unimplemented
else: run(argList)

#---------------------------------------------------------------------------
