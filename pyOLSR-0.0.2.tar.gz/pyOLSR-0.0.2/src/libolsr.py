#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

S=0.1

#import olsrbase
import traceback, os, struct

packetCount = 0

def showMem(): #XXX!
    global packetCount
    f = open("/proc/self/status", "r")
    print packetCount, [x.strip() for x in f.readlines()
                        if x.startswith("VmSize")]

#---------------------------------------------------------------------------

class TestOLSRNode:
    def __init__(self, this):
        self.this = this
        self.retransmitted = False

    def getName(self):
        return "%s" % chr(ord('A')+self.this.getIntId())
        
    def start(self):
        if self.this.getIntId()==0:
            print "start"
            self.this.schedule(1.0*S, self.evEmit, ":")

    def receive(self, srcAddr, packet):
        name = self.getName()
        if not self.retransmitted:
            self.this.schedule(self.this.getIntId()*S/1000.0,
                               self.evEmit, packet)
            self.retransmitted = True
            
    def evEmit(self, clock, last):
        global packetCount
        packetCount += 1
        name = self.getName()
        self.this.send(name, last+name)
        if self.this.getIntId() == 0:
            self.this.schedule(0.01*S, self.evEmit, ":")

    def stop(self):
        if self.this.getIntId() == 0:
            showMem()

#---------------------------------------------------------------------------

import Node, Record

def nodeAndIfaceIdToNetAddress(nodeId, ifaceId):
    return struct.pack("!HH", nodeId, ifaceId)

def netAddressToNodeAndIfaceId(rawAddress):
    return struct.unpack("!HH", rawAddress)

class SimulationAddress:
    def __init__(self, name, netAddress):
        self.name = name
        self.netAddress = netAddress
    def __hash__(self): return hash(self.netAddress)
    def __cmp__(self, other): return cmp(self.netAddress, other.netAddress)
    def __repr__(self): return self.name
    def toNet(self): return self.netAddress

class SimulationNode(Node.OLSRNode):
    def __init__(self, this, nbIface):
        self.this = this
        logConfig = Record.LogConfig()
        logConfig.setNoLog()
        Node.OLSRNode.__init__(self, Node.Config(), logConfig, None)
        for i in range(nbIface):
            #ifaceName = "<%d:@%d>" % (self.this.getIntId(), i)
            ifaceName = self.getIfaceName(self.this.getIntId(), i)
            ifaceAddress = nodeAndIfaceIdToNetAddress(self.this.getIntId(), i)
            self.addIface(i, SimulationAddress(ifaceName, ifaceAddress))
        #if self.this.getIntId() == 1: self.dbg = True
        else: self.dbg = False

    def getIfaceName(self, nodeId, i):
        return "%s%s" % (chr(ord('A')+nodeId), i)

    def getName(self):
        return "%s" % chr(ord('A')+self.this.getIntId())
        #return "<%d>" % self.this.getIntId()
        
    #def start(self): inherited

    def getIfaceById(self, id):
        return self.ifaceList[id]
        #for iface in self.ifaceList:
        #    if iface.identifier == id:
        #        return iface

    def evEmit(self, clock, last):
        raise Unimplemented

    def stop(self):
        if self.this.getIntId() == 0:
            showMem()
        self.display()

    def _runCallback(self, currentTime, callback):
        try:
            callback()
        except:
            traceback.print_exc()
            os.abort()

    def schedule(self, relativeTime, func):
        self.this.schedule(relativeTime, self._runCallback, func)

    def getMainAddress(self):
        return SimulationAddress(
            self.getName(),
            nodeAndIfaceIdToNetAddress(self.this.getIntId(), 0))

    def netToAddress(self, rawAddress):
        nodeId,ifaceId = netAddressToNodeAndIfaceId(rawAddress)
        return SimulationAddress(self.getIfaceName(nodeId,ifaceId), rawAddress)

    def getAddressSize(self):
        return struct.calcsize("!HH")

    def getRealTime(self):
        return self.this.getTime()

    def sendPacket(self, iface, rawPacket):
        self.schedule(0, lambda : self.this.send(iface.getAddress().toNet(),
                                                 rawPacket))

    def receive(self, ifaceId, srcAddr, packet):
        if self.dbg or False:
            print "-"*75
            print "%s->%s:@%s %d" % (self.netToAddress(srcAddr),
                                     self.getName(), ifaceId, len(packet))
        try:
            srcAddr = self.netToAddress(srcAddr)
            iface = self.getIfaceById(ifaceId)
            self.packetManager.processPacket(srcAddr, iface.getAddress(),
                                             packet)
            self.processChange()
        except:
            traceback.print_exc()
            os.abort()

#---------------------------------------------------------------------------

def makeNode(pyrexObject, nbIface):
    try:
        return SimulationNode(pyrexObject, nbIface)
    except:
        traceback.print_exc()
        os.abort()

#---------------------------------------------------------------------------

showMem()

#---------------------------------------------------------------------------
