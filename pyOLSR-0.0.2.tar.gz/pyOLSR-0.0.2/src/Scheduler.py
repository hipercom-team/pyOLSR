#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

#from __future__ import nested_scopes

import time, select, os, sys
import bisect

#---------------------------------------------------------------------------

class SimulationScheduler:
    
    def __init__(self, initialTime = 0.0):
        self.queue=[]
        self.eventCount=0
        self.finished=0
        self.clock=initialTime
        
    def addEvent(self, relativeTime, callback, data):
        assert relativeTime>=0.0
        result=self.eventCount
        newClock=self.clock+relativeTime
        #self.queue.append((newClock, self.eventCount, callback, data, result))
        #self.queue.sort()
        bisect.insort_right(
            self.queue, (newClock, self.eventCount, callback, data, result))
        self.eventCount += 1
        return result

    def _dispatchQueueTop(self):
        self.clock,unused,callback,callbackData,identifier=self.queue[0]
        self.queue=self.queue[1:]
        apply(callback,callbackData)
        
    def run(self):
        while len(self.queue)>0 and not self.finished:
            self._dispatchQueueTop()

    def stop(self): self.finished=1

    def getTime(self): return self.clock

#---------------------------------------------------------------------------

MaxWaitDelay = 3600.0 # XXX: 1 hour

class AbstractFdHandler:
    def fileno(self):           NotImplemented
    def waitingForInput(self):  NotImplemented
    def waitingForOutput(self): NotImplemented
    def waitingForExcept(self): NotImplemented    
    def handleInput(self):      NotImplemented
    def handleOutput(self):     NotImplemented
    def handleExcept(self):     NotImplemented

class FunctionalFdHandler:
    def __init__(self, fd, waitInputFunc=None, waitOutputFunc=None,
                 waitExceptFunc=None, handleInputFunc=None,
                 handleOutputFunc=None, handleExceptFunc=None):
        self.fd = fd
        self.waitInputFunc = waitInputFunc
        self.waitOutputFunc = waitOutputFunc
        self.waitExceptFunc = waitExceptFunc
        self.handleInputFunc = handleInputFunc
        self.handleOutputFunc = handleOutputFunc
        self.handleExceptFunc = handleExceptFunc
    def fileno(self): return self.fd.fileno()
    def waitingForInput(self):
        if self.waitInputFunc != None: return self.waitInputFunc()
        else: return False
    def waitingForOutput(self):
        if self.waitOutputFunc != None: return self.waitOutputFunc()
        else: return False
    def waitingForExcept(self):
        if self.waitExceptFunc != None: return self.waitExceptFunc()
        else: return False
    def handleInput(self):  return self.handleInputFunc()
    def handleOutput(self): return self.handleOutputFunc()
    def handleExcept(self): return self.handleExceptFunc()

class RealTimeScheduler(SimulationScheduler): # implementation reuse
    def __init__(self):
        SimulationScheduler.__init__(self)
        self.clock = self.getTime()
        #self.fdPoll = select.poll()
        #self.fdHandler = {}
        self.fdHandlerList = []

    def addFdHandler(self, fdHandler):
        #self.fdHandler[fd] = (function, argList)
        #XXX: what if double registration ?
        #self.fdPoll.register(fd, pollEventMask)
        #self.fdHandler
        self.fdHandlerList.append(fdHandler)

    def removeFdHandler(self, fdHandler):
        self.fdHandlerList.remove(fdHandler)

    def run(self):
        while not self.finished:
            #print time.time(), self.queue
            # Dispatch current events (deaf by design, if CPU starved)
            delay = MaxWaitDelay
            while len(self.queue)>0:
                nextTime,unused0, unused1,unused2,unused3 = self.queue[0]
                delay = nextTime-time.time()
                if delay<=0:
                    self._dispatchQueueTop()
                    delay = MaxWaitDelay
                else: break
            
            # Wait for some event

            t = time.time()
            #print self.fdHandlerList
            def getFdHandlerList(function):
                return [ x for x in self.fdHandlerList if function(x)]
            inputFdList = getFdHandlerList(lambda x: x.waitingForInput())
            outputFdList = getFdHandlerList(lambda x: x.waitingForOutput())
            exceptFdList = getFdHandlerList(lambda x: x.waitingForExcept())

            #pollResultList = self.fdPoll.poll(delay * 1000)
            #print delay, time.time()-t
            #print pollResultList
            #print "Waiting for", inputFdList, ; sys.stdout.flush()
            (inputFdReady,outputFdReady,exceptFdReady
             ) = select.select(inputFdList, outputFdList, exceptFdList, delay)
            #print "done", ; sys.stdout.flush()
            
            self.clock = time.time()

            # Dispatch fd handlers
            #for fd,event in pollResultList:
            #    function,argList = self.fdHandler[fd]
            #    apply(function, argList)
            for x in inputFdReady: x.handleInput()
            for x in outputFdReady: x.handleOutput()
            for x in exceptFdReady: x.handleExcept()

    def getTime(self): return time.time()

#---------------------------------------------------------------------------

def testScheduler(schedulerClass, isRealTime = 0):
    MaxTime=100
    scheduler=schedulerClass()
    initialClock = scheduler.getTime()

    every={ "1":[], "2":[], "3":[], "fd":[] }
    everyList = []

    def callbackFunc(identifier, interval):
        everyList.append(identifier)
        every[identifier].append( scheduler.clock-initialClock )
        scheduler.addEvent(interval, callbackFunc, (identifier,interval))

    #def callbackFDFunc():
    #    every["fd"].append( (scheduler.clock - initialClock)*10 )
    #    everyList.append( os.read(readFd, 1) )

    class TestCallbackFd:
        def __init__(self, readFd): self.fd = readFd
        def fileno(self): return self.fd
        def waitingForInput(self): return True
        def waitingForOutput(self): return False
        def waitingForExcept(self): return False
        def handleInput(self):
            every["fd"].append( (scheduler.clock - initialClock)*10 )
            everyList.append( os.read(self.fd, 1) )

    if isRealTime:
        #XXX: tests should be more clever
        def childLoop():
            #print os.read(readSyncFd, 1)
            time.sleep(0.5)          
            for i in range(MaxTime):
                os.write(writeFd, "A")
                time.sleep(1.0)
            sys.exit(0)

        readFd, writeFd = os.pipe()
        #readSyncFd, writeSyncFd = os.pipe()
        scheduler.addFdHandler( TestCallbackFd(readFd) )
        if os.fork()==0: childLoop()

    #print writeSyncFd
    c1=scheduler.addEvent(0, callbackFunc, ("3",3) )
    c2=scheduler.addEvent(0, callbackFunc, ("2",2) )
    c3=scheduler.addEvent(0, callbackFunc, ("1",1) )
    scheduler.addEvent(MaxTime-1, scheduler.stop, [])
    #if isRealTime: os.write(writeSyncFd, "@")
    scheduler.run()

    assert (c1,c2,c3) == (0,1,2)
    #if isRealTime: print every,"\n",everyList
    def intRound(x): return int(round(x))
    assert map(intRound, every["1"])==range(0,MaxTime,1)
    assert map(intRound, every["2"])==range(0,MaxTime,2)
    assert map(intRound, every["3"])==range(0,MaxTime+1,3)
    if isRealTime:
        everyFdList = map(intRound, every["fd"])
        #print everyFdList
        assert everyFdList == range(5,MaxTime*10, 10) #NOTE: stringent: 0.1%!
    print "Tests for %s are ok." % schedulerClass

#---------------------------------------------------------------------------

if __name__=="__main__":
    testScheduler(SimulationScheduler, 0)
    print "(please wait, real time scheduler test lasts for long [100 sec])"
    testScheduler(RealTimeScheduler, 1) #XXX: test also I/O

#---------------------------------------------------------------------------
