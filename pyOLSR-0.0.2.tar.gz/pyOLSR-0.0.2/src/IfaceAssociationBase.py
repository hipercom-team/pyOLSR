#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
# IfaceAssociationBase.py
#---------------------------------------------------------------------------

import TupleSet, PacketManager

#---------------------------------------------------------------------------

class IfaceAssociationTuple(TupleSet.BasicTuple):
    def __init__(self):
        self.I_iface_addr = None # @>>1340-1341
        self.I_main_addr = None  # @>>1341-1342
        self.I_time = None       # @>>1342
        self.event = None

class IfaceAssociationSet(TupleSet.TupleSet): # @>>1359-1360
    def isExpired(self, entry):
        return entry.I_time < self.node.getTime()

#---------------------------------------------------------------------------

class IfaceAssociationBase:
    # XXX
    def startIfaceAssociationBase(self):
        # @>>1865-1885
        #self.reset()
        self.eventMIDGeneration()

    def eventMIDGeneration(self):
        if not self.running: return
        self.updateLastCurrentTime()
        self.preEvent("gen-mid")
        self._updateRemoveExpired()
        self.processChange(withRoutingTable=False)
        self.schedule(self.config.MID_INTERVAL,
                      self.eventMIDGeneration) # ZZZ !1544-1546 @>1985-1988
        self._generateMID()
        self.processChange(withRoutingTable=True)
        self.postEvent("gen-mid")

    def _generateMID(self):
        addressList = [ x for x in self.getAddressList()
                        if x != self.getMainAddress() ] # @>>1525-1526
        if len(addressList) == 0: return # @>>1546-1548

        m = PacketManager.Message().withValue(
            "mid",  # @>>1508-1509
            255,    # ttl @>>1509-1510
            0,      # hop count @>>1021
            self.config.MID_HOLD_TIME, # @>>1510-1519
            self.getMainAddress())     # @>>983-990
        
        (m.messageSequenceNumber # @>>1024-1033
         ) = self.packetManager.allocMessageSequenceNumber()

        m.content = PacketManager.MIDMessage()
        m.content.addressList = addressList

        self.packetManager.sendMessage(self.getIfaceList(), m)

    def reprMID(self, withPrefix=False, withTime=False):
        expireInfo = TupleSet.ExpireInfo(self, withTime, self.l._lec)
        result = []
        for t in self.ifaceAssociationSet.iter():
            expireStr = expireInfo.getExpireInfo(t.I_time, t)
            result.append( "%s@%s %s" %(t.I_main_addr, t.I_iface_addr,
                                        expireStr))
        result = ";".join(result)
        if withPrefix: result = "MID: "+result
        return result

    def processMIDMessage(self, m): # @>>1575-1651
        #print "process MID message", m
        changed = False
        #currentTime = self.getTime()
        validityTime = m.getValidityTime() # @>>1580-1582
        
        # Step 1
        sendMainAddress = self.ifaceToMainAddress(m.sendIfaceAddress)
        if not self.isSymmetricNeighbor(sendMainAddress): # @>>1586-1587
            #print "#" * 40, "MID not processed", sendMainAddress
            return # @>>1588

        # Step 2
        for address in m.content.addressList:
            tuple, hasChanged = self.updateIfaceAssociation(
                address, m.originatorAddress, validityTime)
            changed = changed or hasChanged
            tuple.event = self.getLastEvent()

        if changed: # @>>2843
            self.notifyIfaceAssociationBaseChange()


    def updateIfaceAssociation(self, address, mainAddress, validityTime):
        currentTime = self.getLastTime()
        changed = False
        ifaceAssociationTuple = self.ifaceAssociationSet.findFirst(
            lambda x: (x.I_iface_addr == address # @>>1595
                       and x.I_main_addr == mainAddress)) # @>>1597
        if ifaceAssociationTuple != None: # @>>1592-1593
            # Step 2.1
            ifaceAssociationTuple.I_time = (currentTime
                                            + validityTime) # @>>1601
        else:
            # Step 2.2
            ifaceAssociationTuple = IfaceAssociationTuple() # @>>1603
            ifaceAssociationTuple.I_iface_addr = address # @>>1606
            (ifaceAssociationTuple.I_main_addr
             ) = mainAddress # @>>1608
            ifaceAssociationTuple.I_time = (currentTime
                                            + validityTime) # @>>1610
            self.ifaceAssociationSet.add(ifaceAssociationTuple) # @>>1603
            changed = True
        return ifaceAssociationTuple, changed


    def ifaceToMainAddress(self, address): # @>>1613-1650
        # XXX!! resolve our own addresses? we do here (for 2285):
        if address in self.getAddressList():
            return self.getMainAddress()
        
        ifaceAssociationTuple = self.ifaceAssociationSet.findFirst(
            lambda x: x.I_iface_addr == address) # @>>1644
        # Step 1
        if ifaceAssociationTuple != None: # @>>1641-1642
            return ifaceAssociationTuple.I_main_addr # @>>1646-1647
        # Step 2
        else: return address # @>>1649-1650

#---------------------------------------------------------------------------
