#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

import Base, Node, Scheduler, SimulationUtil, Record
import struct
import sys, hotshot, hotshot.stats, time

sys.path.append("../tools/pyVirtNet")
import pyVirtNet

#---------------------------------------------------------------------------

NodeIdxOffset  = 0xC0  # as in 'C'omputer
IfaceIdxOffset = 0xE0  # as in 'E'thernet

class SimulationAddress:
    def __init__(self, name, netAddress):
        self.name = name
        self.netAddress = netAddress
    def __hash__(self): return hash(self.netAddress)
    def __cmp__(self, other): return cmp(self.netAddress, other.netAddress)
    def __repr__(self): return self.name
    def toNet(self): return self.netAddress
    def __getstate__(self): return (self.name, self.netAddress)
    def __setstate__(self, state):
        name, netAddress = state
        self.name = name
        self.netAddress = netAddress

#---------------------------------------------------------------------------

class SimulationIface:
    def __init__(self, simul, node, nodeIdx, ifaceIdx, name):
        self.simul = simul
        self.node = node
        self.nodeIdx = nodeIdx
        self.ifaceIdx = ifaceIdx
        rawAddress = struct.pack("!HH", nodeIdx+NodeIdxOffset,
                                   ifaceIdx+IfaceIdxOffset)
        self.name = name
        self.address = SimulationAddress(self.name, rawAddress)

        self.statRecv = 0
        self.statSend = 0
        
    def getAddress(self):
        return self.address
    
    def sendPacket(self, data):
        self.statSend += 1
        self.simul.emit(self, data)
        
    def receivePacket(self, senderAddress, data):
        self.statRecv += 1
        self.node.receivePacket(senderAddress, self, data)

    def getIfaceIdx(self): return self.ifaceIdx

    def getIdent(self): return ("I["+self.name+"]",)

class SimulationRouteConfigurator:
    def __init__(self):
        pass
    def updateRoute(self, routeList):
        pass

#---------------------------------------------------------------------------

InitialTime = -1.0

class SimulationAddressFactory:
    def getAddressLength(self): return struct.calcsize("!HH")
    
    def popFrontAddress(self, data):
        addrSize = struct.calcsize("!HH")
        netAddress = data[:addrSize]
        dataTail = data[addrSize:]
        nodeIdx,ifaceIdx = struct.unpack("!HH", netAddress)
        nodeIdx -= NodeIdxOffset
        ifaceIdx -= IfaceIdxOffset
        node = self.nodeList[nodeIdx]
        iface = node.ifaceList[ifaceIdx]
        #name = nodeName+self.ifaceIdxToName[nodeName][ifaceIdx]
        #return SimulationAddress(name, netAddress), dataTail
        return iface.getAddress(), dataTail

class AbstractSimulation(SimulationAddressFactory):
    def __init__(self, simConfig):
        self.simConfig = simConfig
        self.scheduler = None

        self.l = simConfig.logConfig
        
        self.state="initial"
        self.nbNode = None
        self.nodeTable = None
        self.nodeList = None
        self.ifaceNameToIface = None

    def _create(self, scheduler, withIfaceName):
        self.scheduler = scheduler
        self.nbNode = len(self.simConfig.nodeList.keys())
        nodeTable = {}
        nodeList = []
        ifaceNameToIface = {}
        nodeIdx = 0
        # Create nodes
        nodeNameList = self.simConfig.nodeList.keys()
        nodeNameList.sort()
        for nodeName in nodeNameList:
            node = self.makeNode(nodeIdx, nodeName,
                                  self.simConfig.nodeList[nodeName])
            if withIfaceName: # XXX hack
                for iface in node.ifaceList:
                    ifaceNameToIface[iface.rawIface.name] = iface
            nodeTable[nodeName] = node
            nodeList.append(node)
            nodeIdx += 1

        self.ifaceNameToIface = ifaceNameToIface
        self.nodeTable = nodeTable
        self.nodeList = nodeList

    def scheduleLinkEvent(self):
        # Schedule link events
        self.connectionMatrix = {}
        for event in self.simConfig.linkList: # XXX: should be called eventList
            clock = event[0]
            evType = event[1]
            if evType == "up" or evType == "down":
                clock,evType,fromIfaceName,toIfaceName = event
                data = [fromIfaceName,toIfaceName]
                if evType == "up": func = self._addLink
                elif evType == "down": func = self._removeLink
            elif evType == "snapshot":
                func = self._doSnapshot
                data = [event[2]]
            elif evType == "check":
                func = self._doCheck
                data = [event[2]]
            else: IMPOSSIBLE
            self.scheduler.addEvent(clock, func, data)
        
        self.state="created"

    def makeNode(self, nodeIdx, nodeName, nodeIfaceList):
        UNIMPLEMENTED # template method


class OLSRSimulation(AbstractSimulation):
    def __init__(self, simConfig, logManager):
        AbstractSimulation.__init__(self, simConfig)
        self.log = logManager        
        self.lastTransmissionTime = None

        self.packetCount = 0
        self.byteCount = 0

    def create(self):
        scheduler = Scheduler.SimulationScheduler(InitialTime)
        self._create(scheduler, True)
        self.scheduleLinkEvent()

    def makeNode(self, nodeIdx, nodeName, nodeIfaceList):
        nbIface = len(nodeIfaceList)
        olsrNode = Node.PyNode(self.scheduler, self.simConfig, self.log)
        olsrNode.setRouteConfigurator(SimulationRouteConfigurator())
        def makeIface(ifaceIdx):
            name = nodeIfaceList[ifaceIdx]
            return SimulationIface(self, olsrNode, nodeIdx, ifaceIdx, name)
        ifaceList = [ makeIface(ifaceIdx) for ifaceIdx in range(nbIface) ]
        olsrNode.setIfaceList(ifaceList)
        olsrNode.setAddressFactory(self)
        return olsrNode
        
    def run(self):
        assert self.state=="created"
        offset = 0 
        for node in self.nodeList:
            self.scheduler.addEvent(0.0-InitialTime+offset,
                                    self._startNode, [node])
            offset += self.simConfig.nodeStartOffset
            
        self.scheduler.addEvent(self.simConfig.duration-InitialTime,
                                self.scheduler.stop, [])
        if self.l._lsim: self.log.write("%s [start]\n"
                                        % self.scheduler.getTime())
        self.realStartTime = time.time()
        self.scheduler.run()

    def _startNode(self, node):
        node.start()
        print "__________start"
        if self.l._link:
            print "*" * 50
            self.log.write("%s [info] %s node %s\n" %
                           (self.scheduler.getTime(), node.getMainAddress(),
                            " ".join(["%s"%x for x in node.getAddressList()])))

    def emit(self, sendIface, rawPacket):
        if not self.connectionMatrix.has_key(sendIface.name):
            return
        recvIfaceList=self.connectionMatrix[sendIface.name].values()
        for recvIface in recvIfaceList:
            delay = 0.0 #XXX: something more realistic
            currentTime = self.scheduler.getTime()
            if self.lastTransmissionTime != None:
                t = self.lastTransmissionTime \
                    + self.simConfig.transmissionMinDelay
                if (delay+currentTime < t):
                    delay = t-currentTime
            self.lastTransmissionTime = currentTime + delay
            self.packetCount += 1
            self.byteCount += len(rawPacket)            
            self.scheduler.addEvent(delay, recvIface.rawIface.receivePacket,
                                    [sendIface.getAddress(), rawPacket])
            
            if self.packetCount%50 == 0:
                delay = time.time()-self.realStartTime
                print ("@%s [%d] - %s packets/sec (%s packets), %s bytes/sec (%s bytes)"
                       % (self.scheduler.getTime(), len(self.scheduler.queue),
                          self.packetCount/delay,  self.packetCount,
                          self.byteCount/delay, self.byteCount))


    #--------------------------------------------------

    def _doCheck(self, data):
        # handled by analyzer
        for node in self.nodeList:
            node.logInfo("check %s" % (data,))

    def _doSnapshot(self, data):
        for node in self.nodeList:
            node.logInfo("snapshot %s" % (data,))
            node.doSnapshot()

    def _addLink(self, fromIfaceName, toIfaceName):
        c = self.connectionMatrix
        if not c.has_key(fromIfaceName):
            c[fromIfaceName] = {}
        if not c[fromIfaceName].has_key(toIfaceName):
            c[fromIfaceName][toIfaceName] = self.ifaceNameToIface[toIfaceName]
            if self.l._lsim or self.l._link:
                self.log.write("%s [link] + %s %s\n" % \
                  (self.scheduler.getTime(), fromIfaceName, toIfaceName))
        else:
            print "Warning, adding already existing link %s->%s" \
                  % (fromIfaceName, toIfaceName)

    def _removeLink(self, fromIfaceName, toIfaceName):
        c = self.connectionMatrix
        if c.has_key(fromIfaceName) and c[fromIfaceName].has_key(toIfaceName):
            del c[fromIfaceName][toIfaceName]
            if self.l._lsim or self.l._link:
                self.log.write("%s [link] - %s %s\n" % \
                  (self.scheduler.getTime(), fromIfaceName, toIfaceName))
        else: 
            print "Warning, removing non-existing link %s->%s" \
                  % (fromIfaceName, toIfaceName)

#---------------------------------------------------------------------------

# XXX: should not be an object
class RunManager(Record.LogManager):
    def __init__(self):
        Record.LogManager.__init__(self) # XXX: should be attribute
        self.fullConfig = None

    #--------------------------------------------------

    def runSimulationScenario(self, scenarioFileName, withCheck):
        fullConfig = self._readSimConfig(scenarioFileName, withCheck, False)
        self.openForWrite(fullConfig.logConfig.traceDir, "simulation")
        Base.writeFile(self.prefix+"/simulation-config.py",
                       Base.readFile(scenarioFileName))
        self._runSimulation(fullConfig)

    def runUMLScenario(self, scenarioFileName, withCheck):
        fullConfig = self._readSimConfig(scenarioFileName, withCheck, True)
        self.openForWrite(fullConfig.logConfig.traceDir, "simulation")
        Base.writeFile(self.prefix+"/simulation-config.py",
                       Base.readFile(scenarioFileName))
        self._runUML(fullConfig)
        
    def _readSimConfig(self, scenarioFileName, withCheck, withUML):
        olsrConfig = Node.Config()
        simConfig = Base.Struct()
        simConfig.scenarioFileName = scenarioFileName
        simConfig.config = olsrConfig
        simConfig.logConfig = Record.LogConfig()
        simConfig.configType = "simulation"
        simConfig.nodeStartOffset = 0.0,
        simConfig.transmissionMinDelay = 0.0
        simConfig.withCheck = withCheck
        simConfig.withUML = withUML

        info = {
            "configFileName": scenarioFileName,
            "logConfig": simConfig.logConfig,
            "simutil": SimulationUtil
         }
        if withUML:
            info["withXterm"] = False
        simConfig = Base.execWith(scenarioFileName, info, simConfig)

        if withCheck:
            simConfig.logConfig.setNoLog()
            simConfig._link = True
            simConfig._lec = True
            simConfig._ltime = True
            simConfig.linkList.append((simConfig.duration, "snapshot", None))
            simConfig.linkList.append((simConfig.duration, "check", None))
            simConfig.duration += 1e-5 # XXX
        
        return simConfig
        
    def _runSimulation(self, fullConfig):
        simulation = OLSRSimulation(fullConfig, self)
        simulation.create()
        simulation.run()

    def _runUML(self, fullConfig):
        pyVirtNet.runSimulation(fullConfig, self)

    #--------------------------------------------------

    def openSimulationResult(self, scenarioDir):
        # XXX: this is a moderatly clever hack: should actually parse 
        # result files to get all config/info
        fullConfig = self._readSimConfig(scenarioDir+"/simulation-config.py")
        self.fullConfig = fullConfig

    #--------------------------------------------------


#---------------------------------------------------------------------------

def run(argList):
    withUML = False
    withCheck = False
    while len(argList)>0:
        current = argList[0]
        if current == "--check":
            argList = argList[1:]
            withCheck = True
        elif current == "--uml":
            argList = argList[1:]
            withUML = True            
        else: break
    if len(argList) >= 1:
        scenarioFileName = argList[0]

    runManager = RunManager()
    if not withUML:
        runManager.runSimulationScenario(scenarioFileName, withCheck)
    else: runManager.runUMLScenario(scenarioFileName, withCheck)
    
if __name__ == "__main__":
    withProfile = False
    #scenarioFileName = "../scenario/grid.py"
    #scenarioFileName = "../scenario/checkLine4.py"
    argList = sys.argv[1:]
    if "--profile" in argList:
        withProfile = True
        argList.remove("--profile")
    
    if not withProfile:
        run(argList)
    else:
        prof = hotshot.Profile("simulation.prof")
        prof.runcall(run, argList)
        print "--closing profile"
        prof.close()

#---------------------------------------------------------------------------
