#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
# A GUI for the display of pyOLSR/pySimOLSR log files
#---------------------------------------------------------------------------
# TODO:
# - This initially used the design: Model/Controller/View
#   the Controllers and Views are in this source file, the model is in
#   Record.py -- but this was abandonned in the middle and the result is a
#   mess.
#---------------------------------------------------------------------------

import os, sys, math, re

import Tkinter
from Tkinter import *


import PacketManager, ConfigParser
import LogAnalysis, Base

sys.path.append("../support") # XXX: remove
sys.path.append("../support/build")

#---------------------------------------------------------------------------
# XXX: could be moved to general library

config = ConfigParser.ConfigParser()
configFileName = os.path.expanduser('~/.tkolsr.cfg')

if not os.path.exists(configFileName):
    print "%s: Creating configuration file '%s'" % (sys.argv[0],
                                                    configFileName)
    config.add_section("directory")
    config.set("directory", "editdir", "tkolsr-data")
    config.set("directory", "resultdir", ".")
    f = open(configFileName, "w")
    config.write(f)
    f.close()
    
config.read(['site.cfg', configFileName])

editDir = config.get("directory","editdir")

def saveInfo(dirName, data):
    if not os.path.exists(editDir):
        os.mkdir(editDir)
    Base.writeFile("%s/%s" % (editDir, dirName), repr(data))

def tryReadInfo(dirName):
    p = "%s/%s" % (editDir, dirName)
    if os.path.exists(p):
        return eval(Base.readFile(p))
    else: return None

#---------------------------------------------------------------------------

#class LogControllerView:
#    def __init__(self, ):

#---------------------------------------------------------------------------

NodeWidth = 1
NodeSize = 100
IfaceSize = 30
IfaceAngle = math.pi*1/3

Margin = 10
GraphSize = 512


if 0:
    NodeSize = 50
    IfaceSize = 20
    GraphSize = 256

class NodeControllerView:
    def __init__(self, info, canvas, model, evRedrawFunc):
        self.info = info
        self.canvas = canvas
        self.model = model
        
        self.x = None
        self.y = None
        self.ifaceAngle = None

        self.color = "#80ffff"
        self.ifaceColor = "#8080ff"

        self.oval = None
        self.text = None
        self.ifaceDrawing = []

        self.controllerState = None
        self.lastX, self.lastY = None, None # undo information

        self.evRedraw = evRedrawFunc

    def createDrawing(self):
        if self.oval != None:
            self.canvas.delete(self.oval)
            self.canvas.delete(self.text)
            for oval,text in self.ifaceDrawing:
                self.canvas.delete(oval)
                self.canvas.delete(text)
        
        x0 = self.x - NodeSize//2 + Margin//2
        y0 = self.y - NodeSize//2 + Margin//2
        x1 = x0 + NodeSize
        y1 = y0 + NodeSize
        t = "node-"+self.model.name
        self.oval = self.canvas.create_oval(
            x0,y0,x1,y1, fill=self.color,width=NodeWidth, tag=t)
        #self.oval.bind("<Return>", None)
        self.text = self.canvas.create_text(
            (x0+x1)//2, (y0+y1)//2, text=self.model.name, tag=t)

        self.canvas.tag_bind(t, "<ButtonPress-1>", self._evButtonPress1)
        self.canvas.tag_bind(t, "<ButtonRelease-1>", self._evButtonRelease1)
        self.canvas.tag_bind(t, "<Shift-Button-1>", self._evButton3)
        self.canvas.tag_bind(t, "<B1-Motion>", self._evButtonMotion1)
        self.canvas.tag_bind(t, "<Control-Z>", self._evCtrlZ)

        self.ifaceDrawing = []
        for i in range(len(self.model.ifaceList)):
            name = self.model.ifaceList[i]
            aa = self.ifaceAngle[i]
            x = self.x + int(math.cos(aa)*NodeSize/2)
            y = self.y + int(math.sin(aa)*NodeSize/2)
            x0 = x - IfaceSize//2 + Margin//2
            y0 = y - IfaceSize//2 + Margin//2
            x1 = x0 + IfaceSize
            y1 = y0 + IfaceSize
            t = "iface-"+name
            oval = self.canvas.create_oval(
                x0,y0,x1,y1, fill=self.ifaceColor,width=NodeWidth, tag=t)

            text = self.canvas.create_text(
                (x0+x1)//2, (y0+y1)//2, text=name, tag=t)

            self.canvas.tag_bind(t, "<ButtonPress-1>",
                                 lambda e,i=i: self._evIfaceButtonPress1(i,e))
            self.canvas.tag_bind(t, "<ButtonRelease-1>",
                                 lambda e,i=i:self._evIfaceButtonRelease1(i,e))
            self.canvas.tag_bind(t, "<B1-Motion>",
                                 lambda e,i=i: self._evIfaceButtonMotion1(i,e))

            self.canvas.tag_bind(t, "<Shift-Button-1>",
                                 lambda e,i=i: self._evIfaceButton3(i,e))

            
            self.ifaceDrawing.append((oval, text))

    def getPos(self, ifaceIdx): # XXX! factor
        xx = self.x + Margin//2
        yy = self.y + Margin//2
        if ifaceIdx == None:
            return (xx,yy,NodeSize/2.0)
        aa = self.ifaceAngle[ifaceIdx]
        x = xx + int(math.cos(aa)*NodeSize/2)
        y = yy + int(math.sin(aa)*NodeSize/2)
        return (x,y,IfaceSize/2.0)

    def redraw(self, propagateToParent = False):
        if propagateToParent:
            self.evRedraw()
            return
        if self.oval == None: self.createDrawing()

        self.xx = self.x + Margin//2
        self.yy = self.y + Margin//2

        # The node itself
        x0 = self.xx - NodeSize//2
        y0 = self.yy - NodeSize//2
        x1 = x0 + NodeSize
        y1 = y0 + NodeSize
        self.canvas.coords(self.oval, x0, y0, x1, y1)
        self.canvas.coords(self.text, (x0+x1)//2, (y0+y1)//2)

        # The interfaces
        for i in range(len(self.ifaceDrawing)):
            aa = self.ifaceAngle[i]
            oval,text = self.ifaceDrawing[i]
            x = self.xx + int(math.cos(aa)*NodeSize/2)
            y = self.yy + int(math.sin(aa)*NodeSize/2)
            x0 = x - IfaceSize//2
            y0 = y - IfaceSize//2
            x1 = x0 + IfaceSize
            y1 = y0 + IfaceSize
            self.canvas.coords(oval, x0, y0, x1, y1)
            self.canvas.coords(text, (x0+x1)//2, (y0+y1)//2)


    def updateCoord(self, nodeIdx, nbNode):
        self.key = ("node", "coord", nodeIdx)
        if self.info.has_key(self.key):
            self.x, self.y, self.ifaceAngle = self.info.get(self.key)
            return
        a = 2*math.pi*nodeIdx/float(nbNode)
        a = - math.pi/2 + a
        size = GraphSize-Margin
        self.x = size//2 + int(math.cos(a)*(size/2-NodeSize/2))
        self.y = size//2 + int(math.sin(a)*(size/2-NodeSize/2))

        nbIface = len(self.model.ifaceList)
        self.ifaceAngle = []
        for i in range(nbIface):

            if nbIface>1:
                da = 2.0*i/float(nbIface-1)-1.0
            else: da = 0.0
            aa = a+math.pi+da*IfaceAngle
            print da
            self.ifaceAngle.append(aa)
        
        self.info.set(self.key, (self.x, self.y, self.ifaceAngle))

    #--------------------------------------------------

    def _evButtonPress1(self, event):
        if self.controllerState != None:
            print "Warning, bad state", self.controllerState
            return
        self.controllerState = "move-node"
        self.mouseX0 = event.x
        self.mouseY0 = event.y
        self.lastX = self.x
        self.lastY = self.y

    def _evButtonRelease1(self, event):
        if self.controllerState != "move-node":
            print "Warning, bad state", self.controllerState
            return
        self.x = event.x - self.mouseX0 + self.lastX
        self.y = event.y - self.mouseY0 + self.lastY
        self.controllerState = None
        self.info.set(self.key, (self.x, self.y, self.ifaceAngle))        
        self.redraw(True)

    def _evButtonMotion1(self, event):
        if self.controllerState != "move-node":
            print "Warning, bad state", self.controllerState
            return
        self.x = event.x - self.mouseX0 + self.lastX
        self.y = event.y - self.mouseY0 + self.lastY
        self.redraw(True)

    def _evIfaceButtonPress1(self, ifaceIdx, event):
        if self.controllerState != None:
            print "Warning, bad state", self.controllerState
            return
        self.controllerState = "move-iface"
        #self.mouseX0 = event.x
        #self.mouseY0 = event.y
        self._mouseAngle = math.atan2(event.y - self.yy, event.x - self.xx)
        self._lastAngle = self.ifaceAngle[ifaceIdx]
        self._moveIfaceIdx = ifaceIdx

    def _evIfaceButtonRelease1(self, ifaceIdx, event):
        if (self.controllerState != "move-iface"
            or ifaceIdx != self._moveIfaceIdx):
            print "Warning, bad state", self.controllerState
            return
        self._evIfaceButtonMotion1(ifaceIdx, event)
        self.controllerState = None
        self.info.set(self.key, (self.x, self.y, self.ifaceAngle))
        self.redraw(True)

    def _evIfaceButtonMotion1(self, ifaceIdx, event):
        if (self.controllerState != "move-iface"
            or ifaceIdx != self._moveIfaceIdx):
            print "Warning, bad state", self.controllerState
            return
        _newMouseAngle = math.atan2(event.y - self.yy, event.x - self.xx)
        self.ifaceAngle[ifaceIdx] = (self._lastAngle + _newMouseAngle
                                     - self._mouseAngle)
        self.redraw(True)

    def _evButton3(self, ifaceIdx, event):
        XXX

    def _evIfaceButton3(self, ifaceIdx, event):
        XXX
        
    def _evCtrlZ(self, event): # XXX! doesn't work and not enough
        print "undo"
        if self.lastX == None: return
        self.x = self.lastX
        self.y = self.lastY
        self.lastX, self.lastY = None, None
        self.redraw(True)

    #--------------------------------------------------

#---------------------------------------------------------------------------

class GraphDecoration:
    def __init__(self, graphFrame):
        self.content = {}
        self.halfLine = True
        self.graphFrame = graphFrame
        self.itemList = []
        self.arcData = {}
        
    def remove(self):
        for item in self.itemList:
            self.graphFrame.canvas.delete(item)
        self.itemList = []

    def addArc(self, fromIdx, toIdx, info):
        if not self.arcData.has_key((fromIdx,toIdx)):
            self.arcData[(fromIdx, toIdx)] = []
        self.arcData[(fromIdx, toIdx)].append(info)

    def redraw(self):
        self.remove()
        for (fromIdx,toIdx),info in self.arcData.items():
            fromNodeView,fromIfaceIdx = self.graphFrame.getNodeByAddr(fromIdx)
            toNodeView,toIfaceIdx = self.graphFrame.getNodeByAddr(toIdx)
            x0,y0,r0 = fromNodeView.getPos(fromIfaceIdx)
            x1,y1,r1 = toNodeView.getPos(toIfaceIdx)
            angle = math.atan2(y1-y0, x1-x0)
            xxm = (x0+x1)/2.0
            yym = (y0+y1)/2.0
            xx0 = x0 + r0*math.cos(angle)
            yy0 = y0 + r0*math.sin(angle)
            xx1 = x1 - r1*math.cos(angle)
            yy1 = y1 - r1*math.sin(angle)
            item1 = self.graphFrame.canvas.create_line(xx0,yy0,xxm,yym)
            item2 = self.graphFrame.canvas.create_line(xxm,yym,xx1,yy1,width=3,
                                                       arrow=LAST)
            self.itemList.append( item1 )
            self.itemList.append( item2 )
    

class GraphFrame:
    def __init__(self, parent):
        self.parent = parent
        self.frame = Frame(parent, bg="white")
        self.graphDecoration = None
        self.create()

    def create(self):
        self.label = Label(self.frame, text="Graph", width=10,
                           relief=GROOVE, bg="white")
        self.canvas = Canvas(self.frame, width=GraphSize, height=GraphSize,
                             bg="white") #, bd=10, relief=GROOVE)
        self.frame.bind("<Control-S>", lambda e: IMPOSSIBLE)

        self.label.pack(side=TOP)
        self.canvas.pack(side=TOP)
        self.frame.pack(side=LEFT)

    def setModelController(self, model, controller):
        # XXX: if model already exists, reset all
        self.model = model
        self.controller = controller
        self.nodeViewList = [NodeControllerView(model, self.canvas, x,
                                                self.evNodeRedraw)
                             for x in model.getNodeList()]
        nbNode = len(self.nodeViewList)
        self.addrToNode = {}
        for i in range(nbNode):
            nodeView = self.nodeViewList[i]
            for j in range(len(nodeView.model.ifaceList)):
                ifaceName = nodeView.model.ifaceList[j]
                self.addrToNode[ifaceName] = (nodeView, j)
            #self.addrToNode[] = self.nodeViewList[i]
            nodeView.updateCoord(i, nbNode)
        self.redraw()

    def evNodeRedraw(self):
        self.redraw()

    def getNodeByAddr(self, ifaceAddr):
        return self.addrToNode[ifaceAddr]

    def redraw(self):
        for nodeView in self.nodeViewList:
            nodeView.redraw()
        if self.graphDecoration != None:
            self.graphDecoration.redraw()

    def displayLogGraph(self, logGraph):
        if self.graphDecoration != None:
            self.graphDecoration.remove()
            
        self.graphDecoration = GraphDecoration(self)
        self.graphDecoration.halfLine = False
        for fromIdx,toIdx in logGraph.graph:
            self.graphDecoration.addArc(fromIdx, toIdx, "arrow")
        self.graphDecoration.redraw()


#---------------------------------------------------------------------------

class AnalysisFrame:
    def __init__(self, parent):
        self.parent = parent
        self.frame = Frame(parent)
        self.create()

    def create(self):
        pass

LineIdxPrefixTemplate = "% 5d % 7.3f"

#---------------------------------------------------------------------------

MaxAddressStrSize = 10

class PacketModelController:
    def __init__(self, model):
        self.model  = model
        self.packetEventLineIdxList = []
        self.packetMessageIdxList = []        
        
    def setMessage(self, message):
        self.message = message
        self.model._updateFromMessage()
        
    def setPacket(self, packet):
        self.packet = packet
        self.model._updateFromPacket()

class PacketFrame:
    def __init__(self, parent):
        self.parent = parent
        self.model = None
        self.create()

    def setModelController(self, model, controller):
        self.model = model
        self.parentController = controller

    def create(self):
        self.frame = Frame(self.parent, width=500, height=500) #, bg="white")

        self.packetFrame = Pmw.Group(self.frame, tag_text='Packet')
        self.packetFrame.pack(side=TOP, fill='both', expand='yes')

        self.messageFrame = Pmw.Group(self.frame, tag_text='Message')
        self.messageFrame.pack()

        # --- Message

        #     Message.originator
        self.messageOriginatorBar = Pmw.MessageBar(
            self.messageFrame.interior(),
            entry_width = MaxAddressStrSize, #XXX            
            entry_relief = 'groove',
            labelpos = 'w',
            label_text = "Originator:")
        #self.messageOriginatorBar.pack(fill='both') XXX: remove
        
        #     Message.info
        self.messageInfoBar = Pmw.MessageBar(
            self.messageFrame.interior(),
            entry_width = 20, #XXX
            entry_relief = 'groove',
            labelpos = 'w',
            label_text = "Info:") 
        #self.messageInfoBar.pack(fill='both') XXX: remove

        self.messageLabelVariable = StringVar()
        self.messageLabel = Label(self.messageFrame.interior(),
                                  relief = 'groove', fg = 'blue',
                                  textvariable = self.messageLabelVariable)
        #self.packetLabel.bind("<Button-1>", lambda *l: PACKET_LABEL)
        self.messageLabel.pack(fill='x')

        #     Message.content
        self.messageContentList = Pmw.ScrolledListBox(
            self.messageFrame.interior(),
            labelpos = 'nw',
            label_text = "Message Content",
            #listbox_height = 6,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand = None
            )
        self.messageContentList.pack(fill='both')

        #    Message.eventList
        self.messageEventList = Pmw.ScrolledListBox(
            self.messageFrame.interior(),
            labelpos = 'nw',
            label_text = "Message Event",
            listbox_width = 30,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand = self._evMessageEventListDoubleClick
            )
      
        self.messageEventList.pack(side=TOP, fill='both')


        #self.label = Label(self.frame, text="Hello World") XXX!

        # --- Packet
        
        self.packetSenderBar = Pmw.MessageBar(
            self.packetFrame.interior(),
            entry_width = MaxAddressStrSize, #XXX
            entry_relief = 'groove',
            labelpos = 'w',
            label_text = "Sender iface:")
        #self.packetSenderBar.pack(fill='both')  - XXX! remove

        self.packetReceiverBar = Pmw.MessageBar(
            self.packetFrame.interior(),
            entry_width = MaxAddressStrSize, #XXX
            entry_relief = 'groove',
            labelpos = 'w',
            label_text = "Receiver iface:")
        #self.packetReceiverBar.pack(fill='both') - XXX! remove

        self.packetLabelVariable = StringVar()
        self.packetLabel = Label(self.packetFrame.interior(),
                                 relief = 'groove',
                                 fg = 'blue',
                                 textvariable = self.packetLabelVariable)
        #self.packetLabel.bind("<Button-1>", lambda *l: PACKET_LABEL)
        self.packetLabel.pack(fill='x')

        #    Packet.messageList
        self.packetMessageList = Pmw.ScrolledListBox(
            self.packetFrame.interior(),
            labelpos = 'nw',
            label_text = "Packet content",
            listbox_height = 4,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand = self._evPacketMessageListDoubleClick
            )
        #self.packetMessageList['font'] = 'fixed'
        self.packetMessageList.pack(fill='both')

        #    Packet.eventList
        self.packetEventList = Pmw.ScrolledListBox(
            self.packetFrame.interior(),
            labelpos = 'nw',
            label_text = "Packet events",
            listbox_height = 10,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand = self._evPacketEventListDoubleClick
            )
        self.packetEventList.pack(fill='both')

        self.frame.pack(side=RIGHT)
        
        self._update()        

    def _evPacketEventListDoubleClick(self):
        selection = self.packetEventList.curselection()
        if len(selection) == 0: return # XXX: understand why
        pos = int(selection[0])
        lineIdx = self.model.packetEventLineIdxList[pos]
        self.parentController.setEventFrameLine(lineIdx)        
        
    def _evPacketMessageListDoubleClick(self):
        selection = self.packetMessageList.curselection()
        if len(selection) == 0: return # XXX: understand why
        pos = int(selection[0])
        messageIdx = self.model.packetMessageIdxList[pos]
        logDB = self.parentController.getDB() #XXX        
        logMessage = logDB.msgDB.get(LogAnalysis.packInt(messageIdx),
                                     False)
        self._updateFromMessage(logMessage)

    def _evMessageEventListDoubleClick(self):
        selection = self.messageEventList.curselection()
        if len(selection) == 0: return # XXX: understand why
        pos = int(selection[0])
        lineIdx = self.model.messageEventLineIdxList[pos][1]
        self.parentController.setEventFrameLine(lineIdx)

    def setPacketEventAt(self, line):
        logDB = self.parentController.getDB() #XXX
        eventType = line.getEventName()
        if eventType == "[send-packet]":
            logPacket,info = logDB._parseSendPacketEvent(line.lineIdx, False)
        elif eventType == "[receive-packet]":
            logPacket,info = logDB._parseRecvPacketEvent(line.lineIdx, False)
        else: IMPOSSIBLE

        self._updateFromPacket(logPacket, info, withMessage=True)


    def _update(self):
        #self.messageOriginatorBar.message("state", "--------------------")
        #self.messageInfoBar.message("state", "") XXX: remove
        #self.packetMessageList.setlist(["l1", "l2", "l3"])
        
        for i in range(10):
            self.messageEventList.insert("%d" % i)

    def _updateFromMessage(self, logMessage):
        if logMessage == None:
            self.messageOriginatorBar.message("state", "")
            self.messageInfoBar.message("state", "")
            self.messageContentList.setlist([])
            self.messageEventList.setlist([])
            return
        logDB = self.parentController.getDB() #XXX

        dataList = []

        m = logMessage.content
        #XXX: should be in PacketTool
        messageName = self._strMessageType(m.messageType).upper()
        labelTxt = "%s - %s - msgSeq=%s" % (m.originatorAddress, messageName,
                                            m.messageSequenceNumber)
        self.messageLabelVariable.set(labelTxt)
        dataList.append( "[%s]"%messageName)
        dataList.append( "vtime=%s size=%s"
                         % ( m.getValidityTime(), m.messageSize))
        dataList.append("origin=%s ttl=%s" %
                        (m.originatorAddress,m.timeToLive ))
        dataList.append("hop=%s seqNum=%s" %
                        (m.hopCount, m.messageSequenceNumber))
        msg = self.parentController.parseMessage(m)
        #width = int(self.messageContentList.cget("entry_width"))
        width = 20 # XXX!
        dataList += [ "-" * width ]
        dataList += self.parentController.prettyReprMessage(msg)
        self.messageContentList.setlist(dataList)

        dataList = []
        self.model.messageEventLineIdxList = logMessage.eventLineIdxList
        for action,lineIdx in logMessage.eventLineIdxList:
            line = logDB.getLogLineAt(lineIdx)
            eventName = line.getEventName()
            content = line.getContent().split(" ")
            data = LineIdxPrefixTemplate%(line.lineIdx, line.getClock())
            if eventName == "[send-packet]":
                sendName = content[-2]                
                data += " %s sent" % sendName
            elif eventName == "[receive-packet]":
                recvName = content[-2]
                sendName = content[-3]
                data += " %s -> %s" % (sendName, recvName)
            else: raise "IMPOSSIBLE eventName", eventName
            
            dataList.append(data)
        self.messageEventList.setlist(dataList)

    def _updateFromPacket(self, logPacket, info, withMessage=True):
        logDB = self.parentController.getDB() #XXX
        self.model.packetInfo = info
        clock, nodeName, ifaceAddress = info
        self.model.logPacket = logPacket
        self.packetSenderBar.message("state", ifaceAddress)

        dataList = []
        self.model.packetEventLineIdxList = logPacket.eventLineIdxList
        for lineIdx in logPacket.eventLineIdxList:
            line = logDB.getLogLineAt(lineIdx)
            data = LineIdxPrefixTemplate%(line.lineIdx, line.getClock())
            eventName = line.getEventName()
            content = line.getContent().split(" ")            
            if eventName == "[send-packet]":
                data += "  send"
            elif eventName == "[receive-packet]":
                data += "  recv"
                data += " by "+ content[-2]
            else: raise "IMPOSSIBLE", eventName

            dataList.append(data)
        self.packetEventList.setlist(dataList)

        self.packetLabelVariable.set(
            "%s - pktSeq=%s" %
            (logPacket.ifaceAddress, logPacket.packetSequenceNumber))

        dataList = []
        self.model.packetMessageIdxList = logPacket.messageIdxList
        for messageIdx in logPacket.messageIdxList:
            logMessage = logDB.msgDB.get(LogAnalysis.packInt(messageIdx),
                                         False)
            # MMM
            #logMessage.content =
            messageType = logMessage.content.messageType
            size = logMessage.content.messageSize
            seqNum = logMessage.content.messageSequenceNumber
            ttl = logMessage.content.timeToLive
            data = self._strMessageType(messageType)
            dataList.append("%s seq=%s (%s b.) ttl=%d"
                            % (data, seqNum, size, ttl))
        self.packetMessageList.setlist(dataList)

        if withMessage and len(logPacket.messageIdxList)>0:
            messageIdx = logPacket.messageIdxList[0]
            logMessage = logDB.msgDB.get(LogAnalysis.packInt(messageIdx),
                                         False)
            self._updateFromMessage(logMessage)

    def _strMessageType(self, value):
        return PacketManager.findByValue(PacketManager.MessageType, value)

#---------------------------------------------------------------------------

EventConvert = {
    ("[event-begin]", 0, 0) : ("[event]",0),
    ("[event-end]", 1, 1)   : ("[event-end]",0),
    ("[event-end]", 2, 1)   : ("[event-end]",0),
    ("[state-begin]", 1, 1) : ("[state]",1),
    ("[state-end]", 2, 2)   : ("[state-end]",1)
}

class EventModelController:
    def __init__(self, model):
        self.model  = model
        self.filterStr = "level0"
        self.filterData = None
        self._minLineIdx = 1 # inclusive
        self._countLineIdx = self.model.db.getLineCount()
        self._currentLineIdx = 1
        self._currentLastLineIdx = None
        self._autoUpdatePacket = False
        self.updateCursorMode = "bound"

        self.filterLineCache = {}
        self.filterLineCacheList = []

    def setLevel(self, level):
        self.filterStr = level
        self.filterData = None

    def setAutoUpdatePacket(self, should):
        self._autoUpdatePacket = should

    def getLevel(self):
        if self.filterStr == "level0": return 0
        elif self.filterStr == "level1": return 1
        elif self.filterStr == "level2": return 2
        elif self.filterStr == "level*": return 3
        else: return -1

    def _setCurrentLineAtBottom(self, count):
        nbTextLine = count
        line = self.getFilterLine(self._currentLineIdx, -1)
        if line == None: line = self.getFilterLine(self._currentLineIdx, +1)
        if line == None: return
        self._currentLineIdx = line.lineIdx
        for i in range(nbTextLine-2):
            currentLineIdx = line.lineIdx - 1
            previousLine = line
            line = self.getFilterLine(currentLineIdx, -1)
            if line == None: 
                line = previousLine
                break
        self._minLineIdx = line.lineIdx

    def _setCurrentLineAtTop(self, count):
        line = self.getFilterLine(self._currentLineIdx, -1)
        if line == None: line = self.getFilterLine(self._currentLineIdx, +1)
        if line == None: return
        self._currentLineIdx = line.lineIdx
        self._minLineIdx = self._currentLineIdx

    def getEventList(self, count, canRestart=True): #, lowerBoundLineIdx=1):
        line = self.getFilterLine(self._minLineIdx, -1)
        if line == None: line = self.getFilterLine(self._minLineIdx, +1)
        if line == None: return []
        result = [ line ]
        lineIdx = line.lineIdx

        while len(result)!=count and lineIdx<self._countLineIdx:
            lineIdx += 1
            line = self.getFilterLine(lineIdx, +1)
            if line != None:
                lineIdx = line.lineIdx
                result.append(line)
            else: break # XXX: check

        if self._currentLineIdx < result[0].lineIdx and canRestart:
            if self.updateCursorMode == "bound":
                self._setCurrentLineAtTop(count)
                return self.getEventList(count, False)
            else:
                self._currentLineIdx =result[0].lineIdx
                return result
        elif result[-1].lineIdx <= self._currentLineIdx and canRestart:
            if self.updateCursorMode == "bound":
                self._setCurrentLineAtBottom(count)
                return self.getEventList(count, False)
            else:
                if len(result)>1:
                    self._currentLineIdx = result[-2].lineIdx
                return result
        else: return result

    def setLineIdx(self, newLineIdx):
        self._currentLineIdx = newLineIdx
        return
        self._currentLineIdx = lineIdx
        self.updateCursorMode = "bound"
        self._updateBecauseOfNewCurrentLineIdx()

    
    def _getLineAt(self, lineIdx):
        return self.model.db.getLogLineAt(lineIdx)

    def _isValidLineIdx(self, lineIdx):
        return 1 <= lineIdx and lineIdx <= self._countLineIdx

    def getFilterLineUncached(self, lineIdx, increment=-1):
        if self.filterStr == "level*": return self._getLineAt(lineIdx)
        while self._isValidLineIdx(lineIdx):
            line = self._getLineAt(lineIdx)
            parentLine = line.getParent()
            grandParentLine = parentLine.getParent()
            grandGrandParentLine = grandParentLine.getParent()
            if (parentLine.lineIdx == line.lineIdx and
                (self.filterStr == "level0" or self.filterStr == "level1"
                 or self.filterStr == "level2")):
                return line
            if (grandParentLine.lineIdx == parentLine.lineIdx
                and (self.filterStr == "level1"
                     or self.filterStr == "level2")):
                return line
            if (grandGrandParentLine.lineIdx == grandParentLine.lineIdx
                and (self.filterStr == "level2")):
                return line

            eventName = line.getEventName()
            if self.filterStr == "message":
                if (eventName == "[send-packet]"
                    or eventName == "[receive-packet]"):
                    return line
            if self.filterStr == "full-filter":
                for filterType,filterInfo in self.filterData:
                    if filterType == "node":
                        if filterInfo != line.getNode(): break
                    elif filterType == "packet":
                        if not line.isPacket(): break
                    elif filterType == "send-packet":
                        if not line.isSendPacket(): break
                    elif filterType == "receive-packet":
                        if not line.isReceivePacket(): break
                    elif filterType == "iface":
                        if filterInfo != line.getIface(): break
                else: return line

            if increment == 0: return None
            lineIdx += increment
        return None

    def getFilterLine(self, lineIdx, increment=-1):
        # XXX: this is LIFO, LRU would be better
        key = (lineIdx,increment,self.filterStr, self.filterData)
        if self.filterLineCache.has_key(key):
            return self.filterLineCache[key]
        result = self.getFilterLineUncached(lineIdx, increment)
        if len(self.filterLineCacheList)>=1000:
            oldestKey = self.filterLineCacheList[0]
            del self.filterLineCacheList[0:1]
            del self.filterLineCache[oldestKey]
        self.filterLineCache[key] = result
        self.filterLineCacheList.append(key)
        return result

    def getLine(self, lineIdx):
        return self.model.db.getLineAt(lineIdx)
            
    def X(self):
        clock = self.model.db.getClockAt(self._currentLineIdx)
        self.eventIdxCounter.setvalue(self._currentLineIdx)
        self.clockCounter.setvalue(clock)

    def run(self):
        pass


class EventFrame:
    def __init__(self, parent):
        self.parent = parent
        self.model = None
        self.create()
        self.updatedPacket = False # XXX!!


    def evButtonFilter(self, buttonName):
        if buttonName == "no exp.": self.model.setLevel("level0")
        elif buttonName == "exp.1": self.model.setLevel("level1")
        elif buttonName == "exp.2": self.model.setLevel("level2")
        elif buttonName == "[pckt]":
            self.model.setLevel("message")
            self.model.setAutoUpdatePacket(True)
        elif buttonName == "pckt":
            self.model.setLevel("message")
            self.model.setAutoUpdatePacket(False)
        elif buttonName == "node":  self.model.setLevel("node")
        else: raise "Unknown button name", buttonName
        self._update()


    def evScrollCommand(self, *l):
        action = l[0]
        if action == "moveto":
            pos = int(1+float(l[1]) * self.model._countLineIdx)
            self._setLineTop(pos)
        elif action == "scroll" and l[2] == "units":
            direction = int(l[1])
            line = self.model.getFilterLine(self.model._minLineIdx+direction,
                                            direction)
            if line != None:
                self._setLineTop(line.lineIdx)
            # XXX!: this does not always work?
        else: print "evScrollCommand", l

    #--------------------------------------------------
    # Cursor management

    # XXX: should be elsewhere
    def setLine(self, newLineIdx):
        self.model._currentLineIdx = newLineIdx
        self._updateBecauseOfNewCurrentLineIdx()

    def _setLineTop(self, pos):
        if pos < 1: pos = 1
        if pos >= self.model._countLineIdx:
            pos = max(self.model._countLineIdx-1, 1)
        self.model._minLineIdx = pos # XXX
        self.model.updateCursorMode = "cursor" # XXX
        self._update()

    def _validateCounter(self, value):
        try: value = int(value)
        except ValueError: return -1
        if value < 1: return -1
        if self.model._countLineIdx <= value: return -1
        #print "ZZZXXX!! VALIDATE", value
        #print value, self.model._currentLineIdx
        if value == self.model._currentLineIdx+1:
            # Certainly a +1 button press
            line = self.model.getFilterLine(value,+1)
            #print "+1", value, line #-XXX
            if line != None: self.model._currentLineIdx = line.lineIdx
            self.eventIdxCounter.setvalue("%s"%self.model._currentLineIdx)
        elif value == self.model._currentLineIdx-1:
            # Certainly a -1 button press
            line = self.model.getFilterLine(value,-1)
            if line != None: self.model._currentLineIdx = line.lineIdx
            self.eventIdxCounter.setvalue("%s"%self.model._currentLineIdx)
        else:
            self.model._currentLineIdx = value
        self._updateBecauseOfNewCurrentLineIdx()
        return 1

    def _updateBecauseOfNewCurrentLineIdx(self):
        self.model.updateCursorMode = "bound" # XXX
        self._updateCounter()
        self._updateEventText()
        self._updatePacketFrame()

    #--------------------------------------------------

    def _validateClock(self, value):
        try: value = float(value)
        except ValueError: return -1
        if self.model == None: return -1
        firstLine = self.model._getLineAt(1)
        lastLine = self.model._getLineAt(self.model._countLineIdx)
        self.model.updateCursorMode = "bound" # XXX!! ??
        if value<firstLine.getClock() or value > lastLine.getClock():
            return -1
        return 1

    def create(self):
        self.frame = Frame(self.parent) #, bg="white")

        self.choosenLabelVariable = StringVar()
        self.choosenLabel = Label(self.frame,
                                  relief = 'groove', fg = 'blue',
                                  textvariable = self.choosenLabelVariable)
        #self.packetLabel.bind("<Button-3>", self._evChoosenLabelDoubleClick)
        self.choosenLabel.pack(fill='x')
        
        self.buttonFrame = Pmw.Group(self.frame, tag_text='Event')
        self.buttonFrame.pack(side=TOP, fill=Y)
        self.eventIdxCounter = Pmw.Counter(
            self.buttonFrame.interior(),
            entryfield_validate = self._validateCounter,
            datatype = 'integer',
            labelpos = 'w',
            label_text = 'Event counter')
        self.eventIdxCounter.pack(side=TOP, fill=Y, expand=1, padx=10, pady=5)
        self.clockCounter = Pmw.Counter(
            self.buttonFrame.interior(),            
            entryfield_validate = self._validateClock,
            datatype = 'real',
            labelpos = 'w',
            label_text = 'Clock')
        self.clockCounter.pack(side=TOP, fill=Y, expand=1, padx=10, pady=5)
        self.filterBox = Pmw.RadioSelect(
            self.buttonFrame.interior(),
            #labelpos='e', label_text='expansion',
            command = self.evButtonFilter)
        for buttonText in [ "no exp.", "exp.1", "exp.2", "pckt",
                            "[pckt]" ]:
            self.filterBox.add(buttonText)
        self.filterBox.pack(side=TOP, fill=X)

        #self.eventText = Pmw.ScrolledText(
        #    self.frame, hscrollmode = "none", vscrollmode = "none")
        self.eventTextFrame = Frame(self.frame)
        self.eventText = Text(self.eventTextFrame,
                              cursor="",
                              exportselection=False,
                              selectbackground="white",
                              width=50,
                              background="white")

        if 0:
            self.eventText = Pmw.ScrolledText(
                self.eventTextFrame,
                #cursor = "",
                #exportselection=False,
                #selectbackground="white",
                #background="white",
                hscrollmode = "none", vscrollmode = "none")
        
        self.eventText.configure(state = 'disabled')
        self.eventText.pack(side=RIGHT,fill=Y)
        #self.eventText.bind("<Button-3>", self._evTextButton1) XXX
        #self.eventText.bind("<B3-Motion>", self._evTextButton1)
        #self.eventText.bind("<ButtonRelease-3>", self._evTextButton1)

        self.eventScroll = Scrollbar(self.frame,
                                     command = self.evScrollCommand)
        self.eventScroll.pack(side=LEFT, fill=Y)
        self.eventScroll.set(0.0,0.001)
        #self.eventText.bind("<A>", self._evTextButton1)
        self.eventTextFrame.pack(fill=Y)

        self.frame.pack(side=LEFT, fill=Y)
        #self.buttonFrame = Frame(self.frame, bg="white")

        self._update()

    def _ok(self, *l): IMPOSSIBLE

    def _evTextButton1(self, event):
        pos = "%s"%self.eventText.index("@%d,%d"%(event.x, event.y))
        x,y = [eval(z) for z in pos.split(".")]
        self._currentLineIdx = x
        self._update()

    def _update(self):
        if self.model == None: return
        self._updateCounter()
        self._updateEventText()

    def _updateCounter(self):
        line = self.model._getLineAt(self.model._currentLineIdx) #XXX
        #clock = self.model.db.getClockAt(self._currentLineIdx)
        self.eventIdxCounter.setvalue(line.lineIdx)
        self.clockCounter.setvalue(line.getClock())
        
    def _updatePacketFrame(self):
        if self.model._autoUpdatePacket:
            line = self.model._getLineAt(self.model._currentLineIdx) #XXX
            eventName = line.getEventName()
            if (eventName == "[send-packet]"
                or eventName == "[receive-packet]"):
                self.parentController.setPacketEventAt(line)

    def _updateScrollBar(self):
        if len(self._lineList) <2:
          v0,v1 = 0.0,1.0
        else:
          v0 = (self._lineList[0].lineIdx-1) / float(self.model._countLineIdx)
          v1 = (self._lineList[-1].lineIdx) / float(self.model._countLineIdx)
        self.eventScroll.set(v0,v1)

    def _getTextYSize(self): return int(self.eventText.cget("height"))

    def _getTextXSize(self): return int(self.eventText.cget("width"))

    def _evTextClick(self, event):
        pos = self.eventText.index( ("@%s,%s" % (event.x, event.y)))
        yPos = int(pos.split(".")[0])-1
        xPos = int(pos.split(".")[1])-1
        if yPos < len(self._lineList):
            self.setLine(self._lineList[yPos].lineIdx)

    def _evTextButton2(self, event):
        pos = self.eventText.index( ("@%s,%s" % (event.x, event.y)))
        yPos = int(pos.split(".")[0])-1
        xPos = int(pos.split(".")[1])-1
        if yPos < len(self._lineList):
            #lineIdx = self._lineList[yPos].lineIdx - XXX
            line = self._lineList[yPos]
            self.parentController.setPacketEventAt(line)

    def _evTextButton3(self, event):
        pos = self.eventText.index( ("@%s,%s" % (event.x, event.y)))
        yPos = int(pos.split(".")[0])-1
        xPos = int(pos.split(".")[1])-1
        if yPos < len(self._lineList):
            lineIdx = self._lineList[yPos].lineIdx
            self.parentController.setNodeStateAt(lineIdx)

    def _evTextControlButton1(self, event):
        pos = self.eventText.index( ("@%s,%s" % (event.x, event.y)))
        yPos = int(pos.split(".")[0])-1
        xPos = int(pos.split(".")[1])-1
        if yPos < len(self._lineList):
            lineIdx = self._lineList[yPos].lineIdx
            self.parentController.addBreakPoint("%s" % lineIdx)
        
    def _updateEventText(self):
        t = self.eventText

        t.configure(state = 'normal')
        t.delete(1.0, END)

        nbTextLine = int(t.cget("height"))
        lineList = self.model.getEventList(nbTextLine+1)
        #if len(lineList)<nbTextLine+1:
        #    lineList += [ None ] *
        self._lineList = lineList

        currentLineIdx = self.model._currentLineIdx
        nbLine = len(lineList)
        #for i in range(nbLine-1):
        for i in range(nbTextLine):
            if i >= len(lineList):
                t.insert(END, "")
                t.insert(END, "")
                continue
            line = lineList[i]
            #if ((i == nbLine-1 and line.lineIdx <= currentLineIdx)
            #            if (i <nbLine-1 and
            if ((line.lineIdx == currentLineIdx) or
               (line.lineIdx <= currentLineIdx < lineList[i+1].lineIdx)):
                tagPrefix = "current"
            else: tagPrefix = ""
            l1 = "% 6d" % line.lineIdx
            if 0:
                parentLine = line.getParent()
                grandParentLine = parentLine.getParent()
                l1 += "% 3d % 3d"%(parentLine.lineIdx,
                                   grandParentLine.lineIdx)
            if 1:
                l1 += " % 8.4f" % line.getClock()
            
            t.insert(END, l1 , tagPrefix+"lineIdx")
            t.insert(END, " ", tagPrefix+"normal")
            
            eventName = line.getEventName()
            modelLevel = self.model.getLevel()
            level = line.getLevel()
            if EventConvert.has_key((eventName, modelLevel, level)):
                eventName, level = EventConvert[(eventName, modelLevel, level)]
            #if eventName == "[send-packet]" and not self.updatedPacket:
            #    self.updatedPacket = True                
            #    self.parentController.setPacketEventAt(line)
                
            #if eventName == "event-begin" and
            #if eventName == "event-begin" and
            EventNameSize = 15
            l2 = ((level*2)*" "+(eventName+EventNameSize*" "))[0:EventNameSize] + " "
                
            t.insert(END, l2, tagPrefix+"lineIdx")
            t.insert(END, " ", tagPrefix+"normal")
            l3 = line.getContent()
            l3 = (l3+100*".")[:self._getTextXSize()-len(l1)-len(l2)-2]
            t.insert(END, l3+"\n", tagPrefix+"line") 
            #print line.getLevel(), line.lineIdx
            #t.insert(END, "%s %s %s\n" % (line.getLevel(), i, line.line))

        for suffixTagName in "lineIdx", "normal","line":
            for prefixTagName in "", "current":
                tagName = prefixTagName+suffixTagName
                t.tag_bind(tagName, "<Button-1>", self._evTextClick)
                t.tag_bind(tagName, "<KeyPress-h>", lambda *l: IMPOSSIBLE)
                t.tag_bind(tagName, "<Button-2>", self._evTextButton2)
                t.tag_bind(tagName, "<Button-3>", self._evTextButton3)
                t.tag_bind(tagName, "<Control-Button-1>",
                           self._evTextControlButton1)
        t.tag_config("lineIdx", foreground="blue", background="white")
        t.tag_config("normal", foreground="black", background="white")
        t.tag_config("line", foreground="black", background="white")
        
        t.tag_config("currentlineIdx", background="green", foreground="blue")
        t.tag_config("currentnormal", foreground="black", background="green")
        t.tag_config("currentline", foreground="black", background="green")

        t.tag_remove(SEL, 1.0, END) # XXX doesn't quite work
        t.tag_add(SEL, 1.0, 1.0)
        
        t.configure(state = 'disabled')
        self._updateScrollBar() # XXX
        logGraph = self.model.model.db.findGraph(self.model._currentLineIdx)
        self.parentController.setCurrentLogGraph(logGraph)
        return


    def _XXX_create(self):
        # Time frame
        self.buttonFrame = Frame(self.frame) #, bg="white")
        self.buttonForward=Button(self.buttonFrame, text=">",
                                  command=self.evForward)
        self.buttonBackward=Button(self.buttonFrame, text="<",
                                   command=self.evBackward)
        #self.button=Button(self.moveFrame, text="<<<|", command=self.evRewind)
        #self.buttonTakeBack=Button(self.moveFrame, text="<|!",
        #                           command=self.evTakeBack)
        #self.buttonWrite=Button(self.moveFrame, text="[..]",
        #                        command=self.evRevert)
        self.buttonBackward.pack(side=LEFT, fill=X)
        self.buttonForward.pack(side=LEFT, fill=X)
        self.buttonFrame.pack(side=TOP)
            
        # Scrollbar frame
        #self.listFrame = Frame(self.frame, bg="white")
        self.listFrame = self.frame # xXX: remove listFrame
        self.scrollbar=Scrollbar(self.listFrame) #, bg="white")
        self.listEvent=Listbox(self.listFrame, width=50, 
                               yscrollcommand=self.scrollbar.set)
        #, bg="white")
        self.scrollbar.config(command=self.listEvent.yview)
        self.listEvent.bind("<Button-1>", self.evClockChoice)
        self.listEvent.pack(side=RIGHT, fill=Y)
        self.scrollbar.pack(side=RIGHT, fill=Y)
        self.listFrame.pack(side=TOP, fill=Y)
        
        # End
        #self.frame.pack(side=LEFT, fill=Y) # XXX ZZZ

    def evClockChoice(self, event):
        print event, event.__dict__

    def evForward(self): UNIMPLEMENTED
    def evBackward(self): UNIMPLEMENTED

    def setModelController(self, model, controller):
        # XXX: if model already exists, reset all
        self.model = model
        self.parentController = controller
        self._update()

    def updateEventList(self):
        pass

    #def updateEventList(self):
    #     self.listEvent.delete(0,END)
    #     for i in range(0,20):
    #         line = self.model.readEventLine(i)
    #         self.listEvent.insert(END, line)
   
#---------------------------------------------------------------------------

class NodeFrame:
    def __init__(self, parent):
        self.parent = parent
        self.model = None
        self.boxContentTable = {}
        self.create()

    def create(self):
        self.frame = Frame(self.parent)
        
        self.nodeFrame = Pmw.Group(self.frame, tag_text='Node')
        self.nodeFrame.pack(side=TOP, fill=Y)

        self.nodeLabelVariable = StringVar()
        self.nodeLabel = Label(self.nodeFrame.interior(),
                               relief = 'groove',
                               fg = 'blue',
                               textvariable = self.nodeLabelVariable)
        self.nodeLabel.bind("<Button-3>", self._evNodeLabelDoubleClick)
        self.nodeLabel.pack(fill='x', side='top')

        self.leftFrame = Frame(self.nodeFrame.interior())
        self.leftFrame.pack(side='left', fill='y')
        self.rightFrame = Frame(self.nodeFrame.interior())
        self.rightFrame.pack(side='right',fill='y')
        
        self.neighborBox = Pmw.ScrolledListBox(
            self.leftFrame,            
            labelpos = 'nw',
            label_text = "Neighbor",
            #listbox_height = 6,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand =
            lambda: self._evStateBoxDoubleClick("neighbor")
            )
        self.neighborBox.pack(fill='both')
        
        self.twoHopBox = Pmw.ScrolledListBox(
            self.leftFrame,            
            labelpos = 'nw',
            label_text = "Two Hop",
            #listbox_height = 6,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand =
            lambda: self._evStateBoxDoubleClick("two-hop")
            )
        self.twoHopBox.pack(fill='both')

        self.mprBox = Pmw.ScrolledListBox(
            self.leftFrame,            
            labelpos = 'nw',
            label_text = "MPR",
            listbox_height = 6,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand =
            lambda: self._evStateBoxDoubleClick("mpr")
            )
        self.mprBox.pack(fill='both')

        self.mprSelectorBox = Pmw.ScrolledListBox(
            self.leftFrame,            
            labelpos = 'nw',
            label_text = "MPRS",
            listbox_height = 6,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand =
            lambda: self._evStateBoxDoubleClick("mpr-selector")
            )
        self.mprSelectorBox.pack(fill='both')

        self.topologyBox = Pmw.ScrolledListBox(
            self.rightFrame,            
            labelpos = 'nw',
            label_text = "TC",
            #listbox_height = 6,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand =
            lambda: self._evStateBoxDoubleClick("topology")
            )
        self.topologyBox.pack(fill='both')

        self.duplicateBox = Pmw.ScrolledListBox(
            self.rightFrame,            
            labelpos = 'nw',
            label_text = "Duplicate",
            #listbox_height = 6,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand =
            lambda: self._evStateBoxDoubleClick("duplicate")
            )
        self.duplicateBox.pack(fill='both')

        self.routeBox = Pmw.ScrolledListBox(
            self.rightFrame,            
            labelpos = 'nw',
            label_text = "Route",
            #listbox_height = 6,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand =
            lambda: self._evStateBoxDoubleClick("route")
            )
        self.routeBox.pack(fill='both')

        self.midBox = Pmw.ScrolledListBox(
            self.rightFrame,            
            labelpos = 'nw',
            label_text = "MID",
            #listbox_height = 6,
            listbox_font = "fixed",
            selectioncommand = None,
            dblclickcommand =
            lambda: self._evStateBoxDoubleClick("mid")
            )
        self.midBox.pack(fill='both')


        self.frame.pack(fill='both')

    def _update(self):
        pass

    def _evStateBoxDoubleClick(self, name):
        if self.boxContentTable.has_key(name):
            dataList,box = self.boxContentTable[name]
            selection = box.curselection()
            if len(selection) == 0: return # XXX: understand why
            pos = int(selection[0])
            mLineIdx = re.search("[\\\\]([0-9]+)", dataList[pos])
            if mLineIdx:
                lineIdx = int(mLineIdx.group(1))
                self.parentController.setEventFrameLine(lineIdx)
        else: print "XXX: warning, no box '%s'" %s

    def _evNodeLabelDoubleClick(self, *whatever):
        mLineIdx = re.search("- ([0-9]+)", self.nodeLabelVariable.get())
        if mLineIdx:
            lineIdx = int(mLineIdx.group(1))
            self.parentController.setEventFrameLine(lineIdx)
        
    def _updateFromState(self, logState):
        for box,name in [(self.neighborBox, "neighbor"),
                         (self.twoHopBox, "two-hop"),
                         (self.mprBox, "mpr"),
                         (self.midBox, "mid"),
                         (self.mprSelectorBox, "mpr-selector"),
                         (self.topologyBox, "topology"),
                         (self.duplicateBox, "duplicate"),
                         (self.routeBox, "route")]:
            data = logState.table[name]
            if data == "":
                box.setlist([])
                self.boxContentTable[name] = ([],box)
            else:
                dataList = data.split(";")
                box.setlist(dataList)
                self.boxContentTable[name] = (dataList, box)
        info = "%s - %s" % (logState.nodeName, logState.topLineIdx)
        self.nodeLabelVariable.set(info)        
        line = self.parentController.getLineAt(logState.topLineIdx)
        line = line.getParent()
        if line.getEventName() == "[event-begin]":
            info += " - "+line.get(2)


    def setModelController(self, model, controller):
        # XXX: if model already exists, reset all
        self.model = model
        self.parentController = controller
        self._update()

    def setNodeStateAt(self, lineIdx):
        line = self.parentController.getLineAt(lineIdx)
        if line == None: return
        while True:
            eventName = line.getEventName()
            if eventName == "[state-begin]": break 
            if line.getLevel()==0: return
            line = line.getParent()
        #print "setNodeStateAt", line.getContent(0)
        logState = self.parentController.getStateAt(line.lineIdx)
        self._updateFromState(logState)
        
        
        
#---------------------------------------------------------------------------

class TkOLSRAnalysisApplication:
    def __init__(self, parent):
        self.displayMode = "graph"
        self.parent = parent
        self.create()

    def create(self):
        self.frame = Frame(self.parent, bd=6, relief=RIDGE, bg="white")

        self.menu = Menu(self.frame)
        root.config(menu=self.menu)

        self.filemenu = Menu(self.menu)
        self.menu.add_cascade(label="File", menu=self.filemenu)
        self.filemenu.add_command(label="Save pos", command=self._evSavePos)
        self.filemenu.add_command(label="Clear breakpoints",
                                  command=self._evClearBreakPoint)
        #self.filemenu.add_command(label="Open...", command=None)
        self.filemenu.add_separator()
        self.filemenu.add_command(label="Exit", command=self.evExit)

        self.graphFrame  = GraphFrame(self.frame)
        self.packetFrame = PacketFrame(self.frame)
        self.eventFrame  = EventFrame(self.frame)
        self.nodeFrame   = NodeFrame(self.frame)

        #self.panel = Pmw.PanedWidget(
        #    self.frame, orient='horizontal')
        #self.eventPane  = self.panel.add("Event")
        #self.eventFrame = EventFrame(self.eventPane)

        #self.eventPane2  = self.panel.add("Another Event")
        #self.eventFrame2 = EventFrame(self.eventPane2)
        #self.panel.updatelayout()
        
        #self.frame = AnalysisFrame(root)
        #self.panel.pack(fill=Y)
        self.frame.pack(fill=Y)

    def _evSavePos(self):
        self.model.writeLogConfig()

    def _evClearBreakPoint(self):
        self.model.clearBreakPoint()

    def evExit(self):
        sys.exit(0)

    def open(self, dirName):
        self.model = LogAnalysis.LogAnalysis()
        self.dirName = dirName
        self.model.openSimulationResult(dirName)
        self.controller = self
        self.graphFrame.setModelController(self.model, self.controller)
        self.eventFrame.setModelController(EventModelController(self.model),
                                           self.controller)
        self.packetFrame.setModelController(PacketModelController(self.model),
                                            self.controller)
        self.nodeFrame.setModelController(None, self.controller)

    #--------------------------------------------------
    # Controller functions
    def setCurrentLogGraph(self, logGraph):
        self.currentLogGraph = logGraph
        if self.displayMode == "graph":
            self.graphFrame.displayLogGraph(self.currentLogGraph)

    def parseMessage(self, msg):
        return self.model.packetTool.parseMessage(msg)

    def prettyReprMessage(self, msg):
        return self.model.packetTool.prettyReprMessage(msg)

    def setPacketEventAt(self, line):
        self.packetFrame.setPacketEventAt(line)

    def setEventFrameLine(self, newLineIdx):
        self.eventFrame.setLine(newLineIdx)

    def setNodeStateAt(self, lineIdx):
        self.nodeFrame.setNodeStateAt(lineIdx)

    def getDB(self): return self.model.db

    def getLineAt(self, lineIdx):
        return self.model.db.getLogLineAt(lineIdx)

    def getStateAt(self, lineIdx):
        return self.model.db._parseStateBegin(lineIdx, False)

    def addBreakPoint(self, info):
        print "adding breakpoint at %s" % info
        self.model.addBreakPoint(info)

    def setSelection(self):
        pass

#---------------------------------------------------------------------------

root = Tk()
root.tk_setPalette(background="white", activeBackground="white",
                   highlightBackground="white", selectBackground="white",
                   insertBackground="white", throughColor="white")
import Pmw
Pmw.initialise(root)

if not os.environ.has_key("INPYDOC"): # Don't run when pydoc (see Makefile)
    application = TkOLSRAnalysisApplication(root)
    application.open(sys.argv[1]) #XXX: "Syntax: "
    root.mainloop()

#---------------------------------------------------------------------------
