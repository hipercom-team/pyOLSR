#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
# Implements the neighbor sensing part of OLSR.
# Essentially manages the link set, the neighbor set and two hop neighbor set:
# - processes and generates HELLOs
#---------------------------------------------------------------------------

# One minor detail in the draft at the "XXX!!!"

from __future__ import generators

from Constant import *

import TupleSet, PacketManager, TopologyDiscovery
import pdb

#---------------------------------------------------------------------------

class LinkTuple(TupleSet.BasicTuple): # @>>1364-1373
    def __init__(self):
        self.L_local_iface_addr = None    # @>>1365
        self.L_neighbor_iface_addr = None # @>>1367
        self.L_SYM_time = None            # @>>1368
        self.L_ASYM_time = None           # @>>1369-1370
        self.L_time = None                # @>>1370-1371
        self.neighborTuple = None         # XXX! ref
        self.status = None
        
        self.event = None
        
    def getStatus(self):
        return self.status

    def updateStatus(self, currentTime):
        if self.L_SYM_time >= currentTime: # @>>1923
            self.status = SYM_LINK # @>>1925
        elif (self.L_ASYM_time >= currentTime # @>>1927
              and self.L_SYM_time < currentTime): # @>>1930
            self.status = ASYM_LINK # @>>1932
        elif (self.L_ASYM_time < currentTime # @>>1934
              and self.L_SYM_time < currentTime): # @>>1936
            self.status = LOST_LINK # @>>1938
        else: IMPOSSIBLE
        if self.neighborTuple != None:
            self.neighborTuple.updateStatus()


class LinkSet(TupleSet.TupleSet): # !1188 @>1384
    def isExpired(self, entry):
        return entry.L_time < self.node.getTime()
    
    def _notifyRemoval(self, entry):
        neighborTuple = entry.neighborTuple
        entry.neighborTuple = None # removing back-reference
        neighborTuple.removeLink(entry)
        self.node.notifyNeighborLinkChange(neighborTuple)

    def removeExpired(self):
        return self.removeExpiredAndUpdateState()

    def removeExpiredAndUpdateState(self):
        updatedCount = 0
        newContent = []
        for entry in self.content[:]:
            if not self.isExpired(entry):
                if entry.updateStatus(self.node.getTime()):
                    updatedCount += 1
                newContent.append(entry)
            else:
                self._notifyRemoval(entry)
                updatedCount += 1
        self.content = newContent
        return updatedCount

#---------------------------------------------------------------------------

class NeighborTuple(TupleSet.BasicTuple): # !1193-1198 @>>1395-1407
    def __init__(self, node):
        self.N_neighbor_main_addr = None # !1194 @>>1395-1396
        self.N_status = None             # !1196 @>>1397-1398
        self.N_willingness = None        # !1196 @>>1397-1398
        self.linkTupleList = []
        self.node = node
        self.twoHopTupleList = [] # @>>2565-2566
        self.mprSelectorTupleList = [] # @>>2568-2569, XXX!!! why plural?
        # XXX! implement @>>2571-2584
        self.event = None

    def countLink(self): return len(self.linkTupleList)
        
    def addLink(self, linkTuple):
        self.linkTupleList.append(linkTuple)
    def removeLink(self, linkTuple):
        self.linkTupleList.remove(linkTuple)
    def hasLink(self, linkTuple):
        return linkTuple in self.linkTupleList
    def iterLink(self):
        return iter(self.linkTupleList)

    def addMPRSelectorTuple(self, mprSelectorTuple):
        self.mprSelectorTupleList.append(mprSelectorTuple)

    def notifyMPRSelectorRemoval(self, mprSelectorTuple):
        self.mprSelectorTupleList.remove(mprSelectorTuple)

    def addTwoHopNeighbor(self, twoHopNeighborTuple):
        twoHopNeighborTuple.neighborTuple = self
        self.twoHopTupleList.append(twoHopNeighborTuple)
        
    def notifyTwoHopNeighborRemoval(self, twoHopNeighborTuple):
        self.twoHopTupleList.remove(twoHopNeighborTuple)

    def iterTwoHopNeighbor(self):
        return iter(self.twoHopTupleList)

    def updateStatus(self):
        previousStatus = self.N_status
        # @>>2198-2211:
        N_status = NOT_SYM # @>>2211
        for otherLinkTuple in self.iterLink():
            if otherLinkTuple.getStatus() == SYM_LINK: # @>>2205-2207
                #XXX?!! check- if otherLinkTuple.L_SYM_time >= currentTime: 
                N_status = SYM # @>>2209
        self.N_status = N_status
        
        if (self.N_status != previousStatus # @>>2546-2557
            or previousStatus == None): # @>>2553
            self.event = self.node.getLastEvent()
            #print ">>>>>>>>> N_status change", neighborTuple
            self.node.notifyNeighborhoodChange()

        if previousStatus == SYM and N_status == NOT_SYM:
            # @>>2546-2551 is translated here
            #pdb.set_trace() # TTT
            self._removeAllTwoHopTuple()

    def _removeAllTwoHopTuple(self):
        for twoHop in self.twoHopTupleList[:]:
            twoHop.neighborTuple = None # prevent looping recursion? XXX
            self.node.removeTwoHopNeighborTuple(twoHop)
        self.twoHopTupleList = []


class NeighborSet(TupleSet.TupleSet): # XXX! not defined in draft
    def isExpired(self, entry): 
        return False # !XXX: must be removed

#---------------------------------------------------------------------------
    
class TwoHopNeighborTuple(TupleSet.BasicTuple): # @>>1411-1420
    def __init__(self):
        self.N_neighbor_main_addr = None # @>>1416-1417
        self.N_2hop_addr= None           # @>>1417-1418
        self.N_time = None               # @>>1419-1420
        self.neighborTuple = None        # @>>2565-2566

        self.event = None

class TwoHopNeighborSet(TupleSet.TupleSet): # @>>1422-1423
    def notifyRemoval(self, entry):
        neighborTuple = entry.neighborTuple

        if neighborTuple != None:
            neighborTuple.notifyTwoHopNeighborRemoval(entry)
        else:
            # XXX!! bug here
            #print "XXX!! there is a bug here"
            pass
        entry.neighborTuple = None            
        
    def isExpired(self, entry):
        return entry.N_time < self.node.getTime()
    def _notifyRemoval(self, entry):
        self.notifyRemoval(entry)
        #print "XXX!! unimplemented - mess"

#---------------------------------------------------------------------------

def isMainAddress(x): return 1 # XXX! to implement

UpdateMIAFromHello = True # XXX!! an "optimization"

class NeighborSensing:
    # This is a mixin of OLSRNode

    def startNeighborSensing(self):
        # @>>1872-1885
        self.immediateHelloCount = 0
        self.eventHelloGeneration()

    def _updateMIAFromHello(self, m):
        if UpdateMIAFromHello and (m.sendIfaceAddress != m.originatorAddress):
            self.updateIfaceAssociation(
                m.sendIfaceAddress, m.originatorAddress, m.getValidityTime())

    def removeTwoHopNeighborTuple(self, twoHopNeighborTuple):
        self.twoHopNeighborSet.remove(twoHopNeighborTuple)

    def processHelloMessage(self, m): # @>>1875-1885
        self._updateMIAFromHello(m)
        linkTuple = self._processHelloLinkSet(m)
        neighborTuple = self._processHelloNeighborSet(m, linkTuple)
        self._processHelloTwoHopNeighborSet(m, neighborTuple)
        self._processHelloMPRSelectorSet(m, neighborTuple)

    def _findAddrInLinkMessage(self, m, address, isSelected):
        for linkEntry in m.content.linkList:
            if (linkEntry.address == address):
                if isSelected(linkEntry):
                    return linkEntry
        return None

    def _processHelloLinkSet(self, m):
        currentTime = self.getLastTime()
        currentExpiringTime = self.expireClock.getTime()
        validityTime = m.getValidityTime() # @>>2064-2065
        linkTuple = self.linkSet.findFirst( # @>>2082
            lambda x: x.L_neighbor_iface_addr == m.sendIfaceAddress)
        if linkTuple == None:
            # @>>2084 ; step 1
            linkTuple = LinkTuple()
            linkTuple.L_neighbor_iface_addr = m.sendIfaceAddress # @>>2086
            linkTuple.L_local_iface_addr = m.recvIfaceAddress # @>>2088-2090
            linkTuple.L_SYM_time = currentTime - 1 # @>>2092
            linkTuple.L_ASYM_time = currentTime + validityTime # @>>2094
            linkTuple.updateStatus(currentExpiringTime)
            self.linkSet.add(linkTuple)

        # step 2
        linkTuple.L_ASYM_time = currentTime + validityTime # @>>2102 step 2.1
        # step 2.2  @>>>2104-2106
        linkEntry = self._findAddrInLinkMessage( #XXX!!!: UNSPEC_ not draft
            m, m.recvIfaceAddress, lambda x: x.linkType != UNSPEC_LINK)
        if linkEntry != None:
            linkType = linkEntry.linkType
            if linkType == LOST_LINK: # @>>2109
                linkTuple.L_SYM_time = currentTime - 1 # @>>2111
            elif linkType == SYM_LINK or linkType == ASYM_LINK: # @>>2114
                linkTuple.L_SYM_time = currentTime + validityTime # @>>2117
                linkTuple.L_time = (linkTuple.L_SYM_time # @>>2119
                                    + self.config.NEIGHB_HOLD_TIME)
         # @>>2121 step 2.3:
        linkTuple.L_time = max(linkTuple.L_time, linkTuple.L_ASYM_time)
        linkTuple.updateStatus(currentExpiringTime)
        linkTuple.event = self.getLastEvent()
        return linkTuple # just avoid another lookup

    def _processHelloNeighborSet(self, m, linkTuple):
        assert linkTuple.L_neighbor_iface_addr == m.sendIfaceAddress
        if linkTuple.neighborTuple == None:
            neighborTuple = self.neighborSet.findFirst( # @>>2160-2164
                lambda x: x.N_neighbor_main_addr ==
                self.ifaceToMainAddress(linkTuple.L_neighbor_iface_addr))
            if neighborTuple == None: # @>>2178-2193
                neighborTuple = NeighborTuple(self)
                (neighborTuple.N_neighbor_main_addr # @>>2191-2193
                 ) = self.ifaceToMainAddress(linkTuple.L_neighbor_iface_addr)
                neighborTuple.event = self.getLastEvent()
                self.neighborSet.add(neighborTuple)

            if not neighborTuple.hasLink(linkTuple):
                neighborTuple.addLink(linkTuple)
                linkTuple.neighborTuple = neighborTuple #XXX: creates GC loop
        else:
            neighborTuple = linkTuple.neighborTuple

        self._updateNeighborTuple(neighborTuple) # @>>2195-2196

        # Willingness update @>>2225-2249
        # it is now obscure why the draft puts a condition which should be true
        #well: in fact the condition is not true if the sender sent a very
        #wrong message, or changed main addresses, so we do it as in the draft:
        #
        # XXX!!! this was leading to unconsistencies, removed line:
        #neighborTuple = self.neighborSet.findFirst( # @>>2236-2237
        #    lambda x: x.N_neighbor_main_addr == m.originatorAddress)
        #print ">>>>>>>>>> post-updated", neighborTuple

        # (now neighborTuple changed only if something obscure happened).
        if neighborTuple != None: # @>>2236
            neighborTuple.N_willingness = m.content.willingness # @>>2247-2249
        return neighborTuple

    # XXX!: must be called on removal:
    # XXX!!: complete deletion must be implemented
    def _updateNeighborTuple(self, neighborTuple): # XXX!: is it present twice
        previousStatus = neighborTuple.N_status
        # @>>2198-2211:
        #currentTime = self.getLastTime()
        N_status = NOT_SYM # @>>2211
        for otherLinkTuple in neighborTuple.iterLink():
            if otherLinkTuple.getStatus() == SYM_LINK: # @>>2205-2207
                #XXX?!! check- if otherLinkTuple.L_SYM_time >= currentTime: 
                N_status = SYM # @>>2209
        neighborTuple.N_status = N_status
        if (neighborTuple.N_status != previousStatus # @>>2546-2557
            or previousStatus == None): # @>>2553
            self.event = self.getLastEvent() 
            self.notifyNeighborhoodChange() 

    #XXX: this function could have been factored in places of the draft.
    def isSymmetricNeighbor(self, mainAddress):
        assert isMainAddress(mainAddress)
        neighborTuple = self.neighborSet.findFirst( # @>>2272-2275
            lambda x: x.N_neighbor_main_addr == mainAddress)
        # (see also: @>>2205-2211)
        # XXX!!! this relies on link being 'not expired'
        return neighborTuple!=None and neighborTuple.N_status == SYM 

    def _processHelloTwoHopNeighborSet(self, m, neighborTuple): # @>>2260-2323
        # NOTE: this relies on _processHelloNeighborSet being called
        # before this method.
        twoHopRemovalOccured = False # XXX!!!! check that _adding_ doesn't
                                     # should not have an effect
        currentTime = self.getLastTime()
        validityTime = m.getValidityTime() # @>>2269-2270

        if not self.isSymmetricNeighbor(m.originatorAddress): # @>>2277
            # XXX check is this always equivalent to @>>2272-2275 (in impl.)
            return

        for linkEntry in m.content.linkList: # @>>2281 - step 1
            
            if (linkEntry.neighborType == SYM_NEIGH
                or linkEntry.neighborType == MPR_NEIGH): # @>>2282-2283

                # @>>2285-2286 - step 1.1:
                if (self.ifaceToMainAddress(linkEntry.address)
                    == self.getMainAddress()):
                    continue # @>>2288-2290

                # step 1.2:
                twoHopMainAddress = self.ifaceToMainAddress(linkEntry.address)
                twoHopNeighborTuple = self.twoHopNeighborSet.findFirst(
                    # @>>2312-2313
                    lambda x: (x.N_neighbor_main_addr == m.originatorAddress
                               and x.N_2hop_addr == twoHopMainAddress))
                twoHop = twoHopNeighborTuple
                if twoHop == None: # @>>2292
                    twoHop = TwoHopNeighborTuple()
                    twoHop.N_neighbor_main_addr = m.originatorAddress # @>>2303
                    twoHop.N_2hop_addr = twoHopMainAddress # @>>2306

                    neighborTuple = self.neighborSet.findFirst(
                        lambda x: x.N_neighbor_main_addr
                        == m.originatorAddress)
                    neighborTuple.addTwoHopNeighbor(twoHop)

                    self.twoHopNeighborSet.add(twoHop)
                twoHop.N_time = currentTime + validityTime # @>>2308-2309
                twoHop.event = self.getLastEvent()
                
            elif linkEntry.neighborType == NOT_NEIGH: # @>>2315-2317 - step 2
                twoHopRemovalOccured = True # @>>2559-2560
                self.twoHopNeighborSet.removeSelected( # @>>2318-2323
                    lambda x: (x.N_neighbor_main_addr == m.originatorAddress 
                               and x.N_2hop_addr ==
                               self.ifaceToMainAddress(linkEntry.address)))
        if twoHopRemovalOccured: # @>>2559-2560
            self.notifyTwoHopNeighborhoodChange()

    def _processHelloMPRSelectorSet(self, m, neighborTuple): # @>>2494-2540
        currentTime = self.getLastTime()
        validityTime = m.getValidityTime() # @>>2508-2510

        # @>>2503-2506
        for oneOfMyAddresses in self.getAddressList():
            linkEntry = self._findAddrInLinkMessage(
                m, oneOfMyAddresses,
                lambda x: x.neighborType == MPR_NEIGH)
            if linkEntry !=None: break

        if linkEntry != None: # @>>2503
            mprSelectorTuple = self.mprSelectorSet.findFirst(
                lambda x: m.originatorAddress == x.MS_addr) # @>>2514
            if mprSelectorTuple == None: # @>>2512 - step 1
                mprSelectorTuple = TopologyDiscovery.MPRSelectorTuple()
                mprSelectorTuple.MS_addr = m.originatorAddress # @>>2527
                mprSelectorTuple.neighborTuple = neighborTuple
                neighborTuple.addMPRSelectorTuple(mprSelectorTuple)
                self.mprSelectorSet.add(mprSelectorTuple) # @>>2516
            # @>>2529-2533 - step 2
            mprSelectorTuple.MS_time = currentTime + validityTime # @>>2535
            mprSelectorTuple.event = self.getLastEvent()

    def eventMPRChange(self):
        # Accept to send only a bounded number of HELLOs per HELLO interval
        # on MPR change.
        # @>>2583-2584
        if self.immediateHelloCount < self.config.maxImmediateHelloOnChange:
            self._generateHello()
            self.immediateHelloCount += 1
            
    def eventHelloGeneration(self):
        if not self.running: return
        self.updateLastCurrentTime()
        self.preEvent("gen-hello")
        self._updateRemoveExpired()
        self.processChange(withRoutingTable=False)
        self.schedule(self.config.HELLO_INTERVAL,
                      self.eventHelloGeneration) # @>>1985-1989
        self._generateHello()
        self.immediateHelloCount = 0
        self.processChange(withRoutingTable=True)
        self.postEvent("gen-hello")

    def _generateHello(self):
        #if self.dbg:
        #    print "--- Generate Hello", self.getMainAddress(), self.getTime()
        #    print self.reprNeighborLink()
        currentTime = self.getLastTime()
        #linkPerIface = {}

        # @>>1970-1971 - identify all advertised neighbors:
        neighborMainAddressList = []
        for neighborTuple in self.neighborSet.iter():
            neighborMainAddressList.append(neighborTuple.N_neighbor_main_addr)
        
        for iface in self.getIfaceList():
            linkList = []
            visitedMainAddress = {}

            def _addLinkEntry(linkType,neighborType,address):
                linkEntry = PacketManager.LinkEntry()
                linkEntry.linkType     = linkType
                linkEntry.neighborType = neighborType
                linkEntry.address      = address
                linkList.append(linkEntry)

            for linkTuple in self.linkSet.iter(): # XXX!! currentTime
                if linkTuple.L_time >= currentTime: # @>>1917-1918
                    (linkType, neighborType, neighborMainAddress
                     ) = self._getLinkCode(linkTuple)
                else: continue
                if linkTuple.L_local_iface_addr == iface.getAddress():
                    visitedMainAddress[neighborMainAddress] = True
                    _addLinkEntry(linkType, neighborType,
                                  linkTuple.L_neighbor_iface_addr)

            for address in neighborMainAddressList: # @>>1970-1972
                if not visitedMainAddress.has_key(address):
                    _addLinkEntry(UNSPEC_LINK, # @>>1974
                                  self._getNeighborType(address), # @>>1976
                                  address) # @>>1972
                
            #linkPerIface[iface.getAddress()] = linkList
            self._sendHelloMessage(iface, linkList)


    def _getLinkCode(self, linkTuple):
        currentTime = self.getLastTime()
        # Step 1: @>>1921-1939
            # Step 1.1:
        if linkTuple.L_SYM_time >= currentTime: # @>>1923
            linkType = SYM_LINK # @>>1925
            # Step 1.2:
        elif (linkTuple.L_ASYM_time >= currentTime # @>>1927
              and linkTuple.L_SYM_time < currentTime): # @>>1930
            linkType = ASYM_LINK # @>>1932
            # Step 1.3:
        elif (linkTuple.L_ASYM_time < currentTime # @>>1934
              and linkTuple.L_SYM_time < currentTime): # @>>1936
            linkType = LOST_LINK # @>>1938
        else:
            self.log("XXX: Impossible link tuple state %s" %
                     linkTuple)
            return None,None,None #<--- XXX

        # Step 2: @>>1940-1967
        # XXX!!! the draft should explicitly exclude this:
        #neighborMainAddress = self.ifaceToMainAddress( # @>>1942
        #    linkTuple.L_neighbor_iface_addr)
        neighborMainAddress = linkTuple.neighborTuple.N_neighbor_main_addr
        return (linkType, self._getNeighborType(neighborMainAddress),
                neighborMainAddress)
    
    def _getNeighborType(self, mainAddress):
        neighborTuple = self.neighborSet.findFirst( # @>>1942
            lambda x: x.N_neighbor_main_addr == mainAddress)
        if neighborTuple == None:
            pdb.set_trace()            
            self.log(("XXX: Impossible: link %s but no associated"
                     +"neighbor tuple") % linkTuple)
            #return None #<--- XXX
            IMPOSSIBLE
        if self.isMPR(mainAddress): # @>>1942-1943 - step 2.1
            neighborType = MPR_NEIGH # @>>1945
        elif neighborTuple != None: # @>>1947-1948 (should be always true)
            if neighborTuple.N_status == SYM: # @>>1951 - step 2.2.1
                neighborType = SYM_NEIGH # @>>1953
            elif neighborTuple.N_status == NOT_SYM: # @>>1955-1956 - step 2.2.2
                neighborType = NOT_NEIGH # @>>1967
            else: Impossible
        return neighborType


    def _sendHelloMessage(self, iface, linkList):
        m = PacketManager.Message().withValue(
            "hello",   # @>>1714-1715
            1,         # @>>1715
            0,         # @>>1021
            self.config.NEIGHB_HOLD_TIME, # @>>1715-1716
            self.getMainAddress())        # @>>983-990
        
        (m.messageSequenceNumber # @>>1024-1033
         ) = self.packetManager.allocMessageSequenceNumber()

        m.content = PacketManager.HelloMessage()
        m.content.willingness = self.getWillingness() # @>>1900-1912
        m.content.htime = PacketManager.toMantissaExponentByte(
            self.config.HELLO_INTERVAL) # @>>1896-1898
        m.content.linkList = linkList

        self.packetManager.sendMessage([iface], m) # @>>1998-1999

    #--------------------------------------------------

    def notifyNeighborLinkChange(self, neighborTuple): # @>>XXX ref
        self._updateNeighborTuple(neighborTuple)

    def removeNeighborExpired(self):
        for neighborTuple in self.neighborSet.iter():
            if neighborTuple.countLink() == 0:
                self.neighborSet.remove(neighborTuple)

    #--------------------------------------------------
    
    def getLinkTupleStatus(self, linkTuple, clock):
        if linkTuple.L_time >= clock:
            if linkTuple.L_SYM_time >= clock: linkStr = "sym"
            elif linkTuple.L_ASYM_time >= clock: linkStr = "asym"
            else: linkStr = "lost"
        else: linkStr = "expired"
        return linkStr

    def reprNeighborLink(self, withPrefix=False, withTime=False):
        expireInfo = TupleSet.ExpireInfo(self, withTime, self.l._lec)
        currentTime = self.getLastTime()
        expireClockTime = self.expireClock.getTime()
        result = []
        for neighborTuple in self.neighborSet.iter():
            #expireStr = expireInfo.getExpireInfo(neighbor.D_time)
            s = "%s %s[" % (neighborTuple.N_neighbor_main_addr,
                            neighborTuple.N_status)
            linkStrList = []
            for linkTuple in neighborTuple.linkTupleList:
                linkStr = self.getLinkTupleStatus(linkTuple, expireClockTime)
                currentLinkStr =  self.getLinkTupleStatus(linkTuple,
                                                          currentTime)
                if linkStr != currentLinkStr:
                    linkStr += "*"
                
                expireStr = expireInfo.getExpireInfo(linkTuple.L_time,
                                                     linkTuple)
                linkStrList.append( "%s@%s %s %s"
                                    % ( 
                                       linkTuple.L_neighbor_iface_addr,
                                       linkTuple.L_local_iface_addr,
                                       expireStr, linkStr))
            result.append(s+",".join(linkStrList)+"]")
        result = (";".join(result))+""
        if withPrefix: result = "Neighbor: "+result
        return result 

    def reprTwoHopNeighbor(self, withPrefix=False, withTime=False):
        expireInfo = TupleSet.ExpireInfo(self, withTime, self.l._lec) 
        result = []
        for twoHop in self.twoHopNeighborSet.iter():
            expireStr = expireInfo.getExpireInfo(twoHop.N_time, twoHop)
            result.append("%s->%s %s" % (twoHop.N_neighbor_main_addr,
                                         twoHop.N_2hop_addr, expireStr))
        result = ";".join(result)
        if withPrefix: result = "TwoHopNeighbor: "+result
        return result

    def reprMPRSelector(self, withPrefix=False, withTime=False):
        expireInfo = TupleSet.ExpireInfo(self, withTime, self.l._lec)
        result = []
        for t in self.mprSelectorSet.iter():
            expireStr = expireInfo.getExpireInfo(t.MS_time, t)
            result.append( "%s %s" % (t.MS_addr, expireStr))
        result = ";".join(result)
        if withPrefix: result = "MPRSelector: "+result
        return result

#---------------------------------------------------------------------------
