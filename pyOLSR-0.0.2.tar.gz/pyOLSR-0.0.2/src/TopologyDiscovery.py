#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
# The part handles Topology Discovery, or more precisely:
# - Topology Control packets (TC) ; generation and processing.
# - MPR computation.
#---------------------------------------------------------------------------

import TupleSet, PacketManager, NeighborSensing, Constant, Base
from NeighborSensing import SYM, NOT_SYM

#---------------------------------------------------------------------------

class MPRSelectorTuple(TupleSet.BasicTuple):
    def __init__(self): # !1239-1242 @>1433-1437
        self.MS_addr = None
        self.MS_time = None
        self.neighborTuple = None # @>>2568-2569

class MPRSelectorSet(TupleSet.TupleSet):
    def isExpired(self, entry):
        return entry.MS_time < self.node.getTime()
    def _notifyRemoval(self, entry):
        entry.neighborTuple.notifyMPRSelectorRemoval(entry)

class TopologyTuple(TupleSet.BasicTuple): # @>>1450-1463
    def __init__(self):
        self.T_dest_addr = None # @>>1451-1452
        self.T_last_addr = None # @>>1452-1454
        self.T_seq = None       # @>>1454
        self.T_time = None      # @>>1454-1463

        self.event = None

class TopologySet(TupleSet.TupleSet): # @>>1446-1448
    def isExpired(self, entry):
        return entry.T_time < self.node.getTime()

#---------------------------------------------------------------------------

def _includedIn(list1, list2):
    for x in list1:
        if x not in list2: return False
    return True

class TopologyDiscovery:
    # This is a mixin of OLSRNode
	
    def resetTopologyDiscovery(self):
        self.ANSN = 0 # @>>2639
        self.lastAddressList = []
        self.lastSentTCTime = None

    def startTopologyDiscovery(self):
        # @>>1865-1885
        self.resetTopologyDiscovery()
        self.eventTCGeneration()

    def processTCMessage(self, m): # @>>2731-2805
        changed = False
        currentTime = self.getLastTime()
        validityTime = m.getValidityTime() # @>>2733-2736
        # Step 1        
        sendMainAddress = self.ifaceToMainAddress(m.sendIfaceAddress)
        if not self.isSymmetricNeighbor(sendMainAddress): # @>>2739-2740
            return # @>>2741
        # Step 2
        topologyTuple = self.topologySet.findFirst(
            lambda x: (x.T_last_addr == m.originatorAddress # @>>2753
                    and self.ansnGreater(x.T_seq, m.content.ANSN))) # @>>2755
        if topologyTuple != None: # @>>2751
            #probably.untested # XXX!!
            return # @>>2757-2759
        # Step 3
        removedTopologyTupleList = \
        self.topologySet.removeSelected(
            lambda x: (x.T_last_addr == m.originatorAddress # @>>2764
                       and self.ansnGreater(m.content.ANSN, x.T_seq))) #@>>2766
        changed = changed or (len(removedTopologyTupleList) > 0) # @>>2847

        # Step 4
        for address in m.content.addressList:
            topologyTuple = self.topologySet.findFirst(
                lambda x: (x.T_last_addr == m.originatorAddress # @>>2776
                           and x.T_dest_addr == address)) # @>>2778
            # Step 4.1
            if topologyTuple != None: # @>>2774
                topologyTuple.T_time = currentTime + validityTime # @>>2782
            else: # Step 4.2
                topologyTuple = TopologyTuple()
                topologyTuple.T_dest_addr = address # @>>2787
                topologyTuple.T_last_addr = m.originatorAddress # @>>2789
                topologyTuple.T_seq = m.content.ANSN # @>>2791
                topologyTuple.T_time = currentTime + validityTime # @>>2793
                topologyTuple.event = self.getLastEvent()                
                self.topologySet.add(topologyTuple) # @>>2784
                changed = True # @>>2847

        if changed: self.notifyTopologyChange() # @>>2841
            
    def eventTCGeneration(self):
        if not self.running: return
        self.updateLastCurrentTime()
        self.preEvent("gen-tc")
        self._updateRemoveExpired()
        self.processChange(withRoutingTable=False)        
        self.schedule(self.config.TC_INTERVAL,
                      self.eventTCGeneration) # XXX !1544-1546 @>1985-1988
        self._generateTC()
        self.processChange(withRoutingTable=True)
        self.postEvent("gen-tc")

    def _getMPRSelectorList(self):
        addressList = []
        for mprSelectorTuple in self.mprSelectorSet.iter():
            addressList.append( mprSelectorTuple.MS_addr )
        return addressList

    def _generateTC(self):
        addressList = self._getMPRSelectorList() # @>>2672-2675
        #XXX: 16-bits ANSN hardcoded here.
        if not _includedIn(addressList, self.lastAddressList):
            # ANSN is increased, this is a 'MUST'
            self.ANSN = (self.ANSN+1) %  (1<<16) # @>>2681-2682
        elif not _includedIn(self.lastAddressList, addressList):
            # ANSN is increased, this is a 'SHOULD'
            self.ANSN = (self.ANSN+1) %  (1<<16) # @>>2682-2684
        if addressList == []:
            if (self.lastSentTCTime == None
                or (self.getLastTime() # @>>2710-2714
                    > self.lastSentTCTime+self.config.TOP_HOLD_TIME)):
                return # No need to send empty TC - @>>2714-2715
        
        m = PacketManager.Message().withValue(
            "tc",   # @>>2620
            255,    # ttl @>>2620-2621
            0,      # hop count @>>1021
            self.config.TOP_HOLD_TIME, # @>>2622-2623
            self.getMainAddress())     # @>>983-990
        
        (m.messageSequenceNumber # @>>1024-1033
         ) = self.packetManager.allocMessageSequenceNumber()

        m.content = PacketManager.TCMessage()
        m.content.ANSN = self.ANSN # XXX! increase it. @>>2639-2650
        m.content.reserved = 0 # @>>2664-2667        
        m.content.addressList = addressList

        # XXX!!! Where do we say in the draft it is broadcast on all ifaces?
        self.packetManager.sendMessage(self.getIfaceList(), m)
        self.lastSentTCTime = self.getLastTime()
        self.lastAddressList = addressList

    def ansnGreater(self, s1, s2): # @>>2735-2736
        maxValue = (1<<16)-1 # @>>4005-4006
        return ( # @>>4008-4009
            ((s1 > s2) and (s1-s2 <= maxValue/2)) # @>>4011
            or ((s2 > s1) and (s2-s1 > maxValue/2)) ) # @>>4013
        # XXX!!! check that it's maxValue, not maxValue+1

    def reprTopology(self, withPrefix=False, withTime=False):
        expireInfo = TupleSet.ExpireInfo(self, withTime, self.l._lec)
        result = []
        for t in self.topologySet.iter():
            expireStr = expireInfo.getExpireInfo(t.T_time, t) 
            result.append( "%s->%s %s" %(t.T_last_addr, t.T_dest_addr,
                                         expireStr))
        result = ";".join(result)
        if withPrefix: result = "Topology: "+result
        return result

#---------------------------------------------------------------------------

class MPRSelection:

    def resetMPRSelection(self):
        self.mprList = []

    def isMPR(self, ifaceAddress): 
        mainAddress = self.ifaceToMainAddress(ifaceAddress)
        return mainAddress in self.mprList

    def startMPRSelection(self):
        # @>>1865-1885
        self.allNeighborAreMPR = False
        self.resetMPRSelection()

    def computeMPR(self):
        "Recompute MPRs of the nodes and returns True iff the MPR Set changed"
        if self.allNeighborAreMPR:
            XXX.DONT
            return self._computeMPRAllNeighbor()
        else: return self._computeRealMPR()

    def _computeRealMPR(self): # @>>2369-2492
        # step 2
        mprList = []
        def merge(moreMPRList):
            for x in moreMPRList:
                if x not in mprList: mprList.append(x)
        for iface in self.getIfaceList():
            merge(self._computeMPRSetOnIface(iface))
        self.mprList = mprList

    def _computeMPRSetOnIface(self, iface): # @>>ZZZ
        # Compute N
        isInN = {} # Hash table: addr -> neighborTuple
        ifaceAddress = iface.getAddress()
        for linkTuple in self.linkSet.iter():
            if linkTuple.L_local_iface_addr == ifaceAddress:
                mainAddress = linkTuple.neighborTuple.N_neighbor_main_addr
                if (not isInN.has_key(mainAddress)
                    and linkTuple.neighborTuple.N_status == SYM):
                    isInN[mainAddress] = linkTuple.neighborTuple
                    
        # Compute N2
        isInN2 = {} # Hash table: addr -> [ ... twoHopNeighborTuple, ... ]
        for twoHop in self.twoHopNeighborSet.iter():
            # Older version BEGIN
            # neighborTuple = self.neighborSet.findFirst(
            #  lambda x: x.N_neighbor_main_addr == twoHop.N_neighbor_main_addr
            #    and ifaceAddress in [y.L_local_iface_addr
            #                         for y in x.linkTupleList])
            # if neighborTuple == None: # @>>2386-2389
            #    continue # it wasn't a 2-hop neighbor reachable from iface
            # Older version END
            # New version BEGIN
            neighborTuple = twoHop.neighborTuple
            if ifaceAddress not in [x.L_local_iface_addr for x in
                                    neighborTuple.linkTupleList]:
                continue # @>>2386-2389
            # New version END
                            
            if not isInN.has_key(neighborTuple.N_neighbor_main_addr):
                continue # @>>2417
            assert neighborTuple.N_status == SYM
            if neighborTuple.N_status == Constant.WILL_NEVER: 
                continue # (i) - @>>2420-2421
            if neighborTuple.N_neighbor_main_addr == self.getMainAddress():
                continue # (ii) - @>>2423 - XXX!!! Is it possible at all?
            if isInN.has_key(twoHop.N_2hop_addr):
                continue # (iii) - @>>2425-2428
            isInN2[twoHop.N_2hop_addr] = (isInN2.get(twoHop.N_2hop_addr, [])
                                          + [twoHop])

        # Transform data structure in flat data structures
        flatNeighborList = [(x.N_neighbor_main_addr, x.N_willingness)
                            for x in isInN.values()]
        flatTwoHopList = [(twoHopTuple.N_neighbor_main_addr, twoHopAddress)
                          for (twoHopAddress,twoHopTupleList) in isInN2.items()
                          for twoHopTuple in twoHopTupleList]
            
        ifaceMPRSet = genericMPRComputation(flatNeighborList, flatTwoHopList,
                                            Constant.WILL_ALWAYS, False)
        return ifaceMPRSet

    def _computeMPRAllNeighbor(self):
        mprList = []
        oldMPRList = self.mprList
        for neighborTuple in self.neighborSet.iter():
            if neighborTuple.N_status == NeighborSensing.SYM:
                mprList.append( neighborTuple.N_neighbor_main_addr )
        mprList.sort()
        self.mprList = mprList
        if self.mprList != oldMPRList:
            return True
        else: False

    def reprMPRSet(self, withPrefix=False, withTime=False):
        result = ";".join(["%s"%x for x in self.mprList])
        if withPrefix: result = "MPRSet: " + result
        return result

#---------------------------------------------------------------------------

def genericMPRComputation(oneHopList, twoHopList, alwaysWillingness, d=False):
    oneHopWillingness = {}
    twoHopOfOneHop = {}
    for oneHop, willingness in oneHopList:
        oneHopWillingness[oneHop] = willingness
        twoHopOfOneHop[oneHop] = []

    if d: print "---- MPRComputation\noneHop=%s\ntwoHop=%s" % (oneHopList, twoHopList)
    #print oneHopList, twoHopList

    oneHopOfTwoHop = {}
    for oneHop, twoHop in twoHopList:
        twoHopOfOneHop[oneHop].append(twoHop)
        if not oneHopOfTwoHop.has_key(twoHop):
            oneHopOfTwoHop[twoHop] = []
        oneHopOfTwoHop[twoHop].append(oneHop)

    initialOneHopReachable = twoHopOfOneHop.copy() # for D(y), @>>2431-2436
    mprList = []

    if d:
        print "-- initially:"
        print "oneHop", twoHopOfOneHop
        print "twoHop", oneHopOfTwoHop

    def chooseOneHopAsMPR(selectedOneHop):
        if d: print "++ %s is MPR, removing twoHop(s):" % selectedOneHop,
        mprList.append( selectedOneHop )
        # Remove oneHop and all its twoHop from the datastructures
        for twoHop in twoHopOfOneHop[selectedOneHop][:]:
            # Phase 1 - remove twoHop from the twoHopList of other oneHop
            if oneHopOfTwoHop.has_key(twoHop):
                for oneHop in oneHopOfTwoHop[twoHop]:
                    twoHopOfOneHop[oneHop].remove(twoHop)
            # Phase 2 - remove twoHop
            del oneHopOfTwoHop[twoHop]
            if d: print twoHop,
        # Phase 3 - remove selectedOneHop
        #del oneHopWillingness[selectedOneHop]
        del twoHopOfOneHop[selectedOneHop]
        del oneHopWillingness[selectedOneHop]
        if d: print

    # step 1 -
    if d: print "-- step 1, choose MPR with WILL_ALWAYS"
    for oneHop, willingness in oneHopList:
        if willingness == alwaysWillingness:
            chooseOneHopAsMPR(oneHop)

    # step 2
    # it is implicit

    # step 3
    if d: print "-- step 3, choose mandatory MPR"
    oneHopIsUnique = {}
    for twoHop, oneHopList in oneHopOfTwoHop.items():
        if len(oneHopList) == 1:
            oneHopIsUnique[oneHopList[0]] = True
            if d: print "%s only link to %s" %(oneHopList[0],twoHop)
    for oneHop in oneHopIsUnique.keys():
        chooseOneHopAsMPR(oneHop)

    if d: print "-- step 4, choose MPR iteratively"
    # step 4 -
    while len(oneHopOfTwoHop.keys()) > 0: # @>>2452-2453
        if d: print "- oneHop,TwoHop\n",twoHopOfOneHop,"\n",oneHopOfTwoHop
        candidateList = []
        for oneHop,willingness in oneHopWillingness.items():
            if len(twoHopOfOneHop[oneHop])>0:
                candidateList.append( (willingness,
                                       len(twoHopOfOneHop[oneHop]), # 4.1
                                       len(initialOneHopReachable[oneHop]),
                                       # ^^^ D(y), @>>2431-2436
                                       oneHop) )
        candidateList.sort()  # 4.2 @>>2460-2474
        unused1, unused2, unused3, selectedOneHop = candidateList[-1]
        chooseOneHopAsMPR(selectedOneHop)

    return mprList

#---------------------------------------------------------------------------
