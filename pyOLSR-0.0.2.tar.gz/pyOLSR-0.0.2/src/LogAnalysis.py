#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
# Create 'databases' (random seek/indexed information) from a log file
#---------------------------------------------------------------------------
# TODO:
# - LogAnalysis should be a proxy of LogDB
#---------------------------------------------------------------------------

import re, os, struct
import bsddb, cPickle

import Base, PacketTool
import Simulation

#---------------------------------------------------------------------------

rClock = re.compile("(-?[0-9.]+)")
FmtIndex = "!fI"

#---------------------------------------------------------------------------

FmtIndexSize = struct.calcsize(FmtIndex)

NodeIdxOffset  = 0xC0  # as in 'C'omputer #XXX!!
IfaceIdxOffset = 0xE0  # as in 'E'thernet #XXX!!

#---------------------------------------------------------------------------

class IdxDB:
    def __init__(self, name, shouldRewrite=False):
        self.counter = 0
        fileName = name
        if shouldRewrite:
            os.system("rm -f %s" % fileName) # XXX!!
            self.btree = bsddb.btopen(fileName, "c")
            self.btree[chr(0xff)] = EOFString
        else: self.btree = bsddb.btopen(fileName, "r")

    def getIdx(self, name, shouldCreate=True):
        result = self.btree.set_location(name)
        if result[0] != name:
            if shouldCreate:
                result = self.counter
                self.btree[name] = packInt(self.counter)
                self.counter += 1
            else: result = None # XXX! key error
        else:
            result = unpackInt(result[1])
        #print name, result
        return result

    def close(self): self.btree.close()

def packInt(value):
    return struct.pack("!i", value)

def unpackInt(data):
    return struct.unpack("!i", data)[0]

#--------------------------------------------------

class DB:
    def __init__(self, name, shouldRewrite = False):
        fileName = name
        if shouldRewrite:
            os.system("rm -f %s" % fileName) # XXX!!
            self.btree = bsddb.btopen(fileName, "c")
        else: self.btree = bsddb.btopen(fileName, "r")

    #--------------------------------------------------

    def set(self, key, value):
        self.btree[key] = value

    #def setInt(self, key, intValue):
    #    self.set(key, packInt(intValue))

    def get(self, key): return self.btree[key]

    #def getInt(self, key): return self._unpackInt(key)

    #def getIntAtIdx(self, keyIdx):
    #    return self.getInt(packInt(keyIdx))

    def last(self): return self.btree.last()

    def close(self):
        self.btree.close()
        self.btree = None

#--------------------------------------------------

class ObjectDB(DB):
    def __init__(self, name, factory=None, shouldRewrite = False):
        self.factory = factory
        DB.__init__(self, name, shouldRewrite)

    read = DB.get
    write = DB.set

    def get(self, key, shouldCreate = False):
        return self.factory(self, key, shouldCreate)

    def setLocation(self, key): 
        return self.btree.set_location(key)

    def previous(self):
        return self.btree.previous()

    def next(self):
        return self.btree.next()
        
    def set(self, *l): REMOVED_METHOD    

#--------------------------------------------------

class LogObject(Base.Struct):
    def __init__(self, objectDB, key, shouldCreate=False):
        self.key = key
        self.objectDB = objectDB
        if self.objectDB.btree.has_key(key):
            self.load()
        else:
            if not shouldCreate: raise KeyError
            self.postCreate()

    def postCreate(self): pass

    def postLoad(self): pass
        
    def save(self):
        data = self.__dict__.copy()
        del data["objectDB"]
        del data["key"]
        data = repr(data)
        self.objectDB.write(self.key, data)

    def load(self):
        self.__dict__.update(eval(self.objectDB.read(self.key)))
        self.postLoad()

    def getIdx(self): return unpackInt(self.key)
        
#--------------------------------------------------

InvalidIdx = (-1)
Invalid = ('invalid',)

class LogPacket(LogObject):
    #def __init__(self, objectDB, key, shouldCreate=False):
    #    LogObject.__init__(self, objectDB, key, shouldCreate)
    def postLoad(self): pass
    def postCreate(self):
        self.eventNode = Invalid
        self.eventLineIdxList = []
        self.messageIdxList = []

class LogMessage(LogObject):
    def postLoad(self):
        self.content = cPickle.loads(self.content)
        
    def postCreate(self):
        self.eventNode = Invalid
        self.eventLineIdxList = []
        self.packetIdx = InvalidIdx
        self.content = None

    def save(self):
        content = self.content
        self.content = cPickle.dumps(content)
        LogObject.save(self)
        self.content = content


class LogState(LogObject):
    def postLoad(self): pass
    def postCreate(self):
        self.eventNode = Invalid
        self.eventLineIdxList = []
        self.table = {}

class LogGraph(LogObject):
    def postCreate(self):
        self.graph = []

#--------------------------------------------------

class LogLine:
    def __init__(self, logAnalysis, lineIdx):
        self.logAnalysis = logAnalysis
        self.lineIdx = lineIdx
        self.line = logAnalysis.db.getLineAt(lineIdx).strip()
        
    def getClock(self):
        return float(self.line.split(" ")[0])

    def getEventName(self):
        return self.line.split(" ")[1]

    def getContent(self, offset=2):
        return " ".join(self.line.split(" ")[offset:])

    def get(self, pos, toPos=None):
        tokenList = self.line.split(" ")
        if toPos == None: return tokenList[pos]
        else: return tokenList[pos:toPos]

    def getLineParent(self):
        return self.logAnalysis.db.getLineParent(self.lineIdx)

    def getParent(self):
        return LogLine(self.logAnalysis, self.getLineParent())

    def getTopParent(self):
        line = self
        while line.getLevel()>0:
            line = line.getParent()
        return line

    def getLevel(self):
        previous = self
        current = self
        level = 0
        while True:
            current = current.getParent()
            if current.lineIdx == previous.lineIdx: return level
            level += 1
            previous = current

    def getNode(self):
        eventName = self.getEventName()
        if eventName.startswidth("[table-"):
            return self.get(3).strip(":")
        elif eventName in ["event-begin", "event-end"]:
            return self.get(4)
        elif eventName == "[link]": return None
        elif eventName == "[start]": return None
        elif eventName == "[stop]": return None        
        elif eventName in ("[state-begin]","[state-end]"):
            return self.get(3)
        else: raise "IMPOSSIBLE eventName", eventName

    def getIface(self): #XXX: can't work
        if eventName == "[send-packet]": return self.get(4)
        elif eventName == "[receive-packet]": return self.get(5)
        else: return None

    def isPacket(self):
        eventName = self.getEventName()
        return (eventName == "[send-packet]"
                or eventName == "[receive-packet]")

    def isSendPacket(self):
        return self.getEventName() == "[send-packet]"

    def isReceivePacket(self):
        return self.getEventName() == "[receive-packet]"

class LogDB:
    def __init__(self, logAnalysis, dirName):
        self.logAnalysis = logAnalysis
        self.dirName     = dirName
        self.logF = open(self.dirName+"/full.log")

    def open(self, shouldRewrite):
        self.msgDB = ObjectDB(self.dirName+"/msg.db",
                              LogMessage, shouldRewrite)
        self.msgDB.idxDB = IdxDB(self.dirName+"/msgIdx.db", shouldRewrite)
        self.packetDB = ObjectDB(self.dirName+"/packet.db",
                                 LogPacket, shouldRewrite)
        self.packetDB.idxDB = IdxDB(self.dirName+"/msgIdx.db", shouldRewrite)

        self.stateDB = ObjectDB(self.dirName+"/state.db",
                                LogState, shouldRewrite)
        
        #self.eventIdxDB  = IdxDB(self.dirName+"/eventToIdx.db", True)
        self.lineDB        = DB(self.dirName+"/line.db", shouldRewrite)
        self.lineParentDB  = DB(self.dirName+"/lineParent.db", shouldRewrite)

        self.graphDB = ObjectDB(self.dirName+"/graph.db",
                                LogGraph, shouldRewrite)

    def close(self):
        self.msgDB.close()
        self.msgDB.idxDB.close()
        self.packetDB.close()
        self.packetDB.idxDB.close()
        self.stateDB.close()
        self.lineDB.close()
        self.lineParentDB.close()
        self.graphDB.close()

    def openNot(self):
        XXX.unimplemented
        #self.msgIdxDB    = IdxDB(self.dirName+"/msgToIdx.db")
        #self.packetIdxDB = IdxDB(self.dirName+"/packetToIdx.db")
        #self.eventIdxDB  = IdxDB(self.dirName+"/eventToIdx.db")
        #self.lineDB      = DB(self.dirName+"/line.db")

    def setLinePos(self, lineIdx, linePos, lineParent = None):
        self.lineDB.set(packInt(lineIdx), packInt(linePos))
        if lineParent == None:
            lineParent = lineIdx
        self.lineParentDB.set(packInt(lineIdx), packInt(lineParent))

    def getLineParent(self, lineIdx):
        return unpackInt(self.lineParentDB.get(packInt(lineIdx)))
        
    def getLinePos(self, lineIdx):
        return unpackInt(self.lineDB.get(packInt(lineIdx)))

    def getLineEventName(self, lineIdx):
        line = self.getLineAt(lineIdx)
        return line.split(" ")[1]

    def getLineAt(self, lineIdx):
        pos = self.getLinePos(lineIdx)
        self.logF.seek(pos)
        return self.logF.readline().strip()

    def getLogLineAt(self, lineIdx):
        if lineIdx > self.getLineCount(): return None
        else: return LogLine(self.logAnalysis, lineIdx)

    def getClockAt(self, lineIdx):
        line = self.getLineAt(lineIdx).split(" ")
        return float(line[0])

    def getLineCount(self):
        try: result = self.lineDB.last()
        except KeyError: return 0
        return unpackInt(result[0])

    #def getClockAt(self, lineIdx):
    #    line = self.getLineAt(lineIdx)
    #    return float(line[:line.find(" ")]) XXX!

    # XXX!! must take into account int(clock)//ClockScale -1 and +1
    def _getPacketKey(self, ifaceAddress, clock, seqNum, offset=0):
        packetName = "%s-%s-%s"%(ifaceAddress,
                                 seqNum, offset+int(clock)//ClockScale)
        return packInt(self.packetDB.idxDB.getIdx(packetName))

    # XXX!! must take into account int(clock)//ClockScale -1 and +1
    def _getMsgKey(self, name, clock, seqNum):
        msgName = "%s-%s-%s" % (name, seqNum, int(clock)//ClockScale)
        return packInt( self.msgDB.idxDB.getIdx(msgName) )

    def _getStateKey(self, name, clock, lineIdx):
        result = ("%s"% name + chr(0xff)
                  + struct.pack("!iii",
                                (int(clock)),
                                int((clock-int(clock))*1000000),
                                lineIdx))
        return result

    def _getGraphKey(self, clock, lineIdx):
        clockOffset = 2.0
        clock += clockOffset
        result = struct.pack("!iii", (int(clock)),
                             int((clock-int(clock))*1000000),
                             lineIdx)
        return result

    #def getPacketAt(self, packetIdx, shouldCreate=None):
    #    self.packetDB.get()
    #    #XXXself._getPacket()

    def getMsgAt(self, msgIdx, shouldCreate=None):
        XXX

    def _parseSendPacketEvent(self, lineIdx, shouldCreate=False):
        line = self.getLineAt(lineIdx)
        dataList = line.split(" ")
        clock = float(dataList[0])
        nodeName = dataList[2]
        ifaceAddress = dataList[3]
        rawPacket = Base.fromASCII(dataList[4])
        messageList,packetSequenceNumber = \
            self.logAnalysis.packetTool.parsePacket(ifaceAddress,
                                                    None, rawPacket)
        packetKey = self._getPacketKey(ifaceAddress, clock,
                                       packetSequenceNumber)
        logPacket = self.packetDB.get(packetKey, True) 
        logPacket.ifaceAddress = ifaceAddress
        logPacket.packetSequenceNumber = packetSequenceNumber
        if shouldCreate:
            logPacket.eventLineIdxList.append(lineIdx)
            logPacket.rawPacket = rawPacket # UUU
            assert len(logPacket.messageIdxList) == 0
            for message in messageList:
                msgKey = self._getMsgKey(message.originatorAddress, clock,
                                         message.messageSequenceNumber)
                logMessage = self.msgDB.get(msgKey, True)
                logMessage.eventLineIdxList.append(("send",lineIdx))
                logMessage.packetIdx = logPacket.getIdx()
                #logMessage.content = message.__dict__
                #(logMessage.content["originatorAddress"] 
                # ) = repr(logMessage.content["originatorAddress"])
                logMessage.content = message
                logMessage.save()
                logPacket.messageIdxList.append( logMessage.getIdx() )

            logPacket.save()
        return logPacket, (clock, nodeName, ifaceAddress)

    def _parseStateBegin(self, lineIdx, shouldCreate=False):
        assert (not shouldCreate) or self.logAnalysis.mode == "parsing"
        # (can't parse imbricated)
        line = self.getLineAt(lineIdx)
        dataList = line.split(" ")
        clock = float(dataList[0])
        nodeName = dataList[2]
        
        stateKey = self._getStateKey(nodeName, clock, lineIdx)
        logState = self.stateDB.get(stateKey, True)

        if shouldCreate:
            self.logAnalysis.mode = "parsing-state"
            self.logAnalysis.lineParentStack.append(lineIdx)
            self._currentStateFrom = nodeName
            self._currentState = logState
            logState.topLineIdx = lineIdx
            logState.nodeName = nodeName
        return logState

    def _parseStateEnd(self, lineIdx, shouldCreate=False):
        assert shouldCreate
        assert self.logAnalysis.mode == "parsing-state"
        line = self.getLineAt(lineIdx)
        dataList = line.split(" ")
        clock = float(dataList[0])
        nodeName = dataList[2]

        assert self._currentStateFrom == nodeName
        self._currentState.save()
        self.logAnalysis.mode = "parsing"
        self.logAnalysis.lineParentStack.pop()
        self._currentStateFrom = None
        self._currentState = None
        
        return

    def _parseEventBegin(self, lineIdx, shouldCreate=False):
        if shouldCreate:
            self.logAnalysis.lineParentStack.append(lineIdx)

    def _parseEventEnd(self, lineIdx, shouldCreate=False):
        if shouldCreate:
            self.logAnalysis.lineParentStack.pop()

    def _parseLink(self, lineIdx):
        line = self.getLineAt(lineIdx)
        dataList = line.split(" ")
        clock = float(dataList[0])
        action = dataList[2]
        sendIfaceAddress = dataList[3]
        recvIfaceAddress = dataList[4]
        if action == "-":
            self._currentTopology.remove((sendIfaceAddress, recvIfaceAddress))
        elif action == "+":
            self._currentTopology.append((sendIfaceAddress, recvIfaceAddress))
        else: IMPOSSIBLE
        self.addGraph(self._currentTopology, clock, lineIdx)

    def _parseRecvPacketEvent(self, lineIdx, shouldCreate=False):
        line = self.getLineAt(lineIdx)
        dataList = line.split(" ")
        clock = float(dataList[0])
        nodeName = dataList[2]
        sendIfaceAddress = dataList[3]
        recvIfaceAddress = dataList[4]
        rawPacket = Base.fromASCII(dataList[5]) # UUU
        messageList,packetSequenceNumber = \
          self.logAnalysis.packetTool.parsePacket(sendIfaceAddress,
                                                  recvIfaceAddress, rawPacket)
        packetKey = self._getPacketKey(sendIfaceAddress, clock,
                                       packetSequenceNumber)
        logPacket = self.packetDB.get(packetKey, True)
        if shouldCreate:
            logPacket.eventLineIdxList.append(lineIdx)
            for message in messageList:
                msgKey = self._getMsgKey(message.originatorAddress, clock,
                                         message.messageSequenceNumber)
                logMessage = self.msgDB.get(msgKey, True)
                logMessage.eventLineIdxList.append(("recv",lineIdx))
                logMessage.packetIdx = logPacket.getIdx()
                logMessage.save()
            logPacket.save()

        return logPacket, (clock, nodeName, sendIfaceAddress)

    def _parseTable(self, lineIdx, shouldCreate=False):
        line = self.getLineAt(lineIdx)
        dataList = line.split(" ")
        clock = float(dataList[0])
        nodeName = dataList[2].strip(":")
        tableName = dataList[1].replace("[table-", "").rstrip("]")
        info = " ".join(dataList[3:])
        assert (not shouldCreate) or self.logAnalysis.mode == "parsing-state"
        assert self._currentStateFrom == nodeName
        self._currentState.table[tableName] = info
        return
    
    def parseLineAt(self, lineIdx):
        e = self.getLineEventName(lineIdx)
        if e == "[send-packet]": self._parseSendPacketEvent(lineIdx, True)
        elif e == "[receive-packet]": self._parseRecvPacketEvent(lineIdx, True)
        elif e == "[state-begin]": self._parseStateBegin(lineIdx, True)
        elif e == "[state-end]": self._parseStateEnd(lineIdx, True)
        elif e == "[link]": self._parseLink(lineIdx)
        elif e.startswith("[table-"): self._parseTable(lineIdx, True)
        elif e == "[event-begin]": self._parseEventBegin(lineIdx, True)
        elif e == "[event-end]": self._parseEventEnd(lineIdx, True)        
        else: print e

    def getNodeByMainAddress(self, mainAddress):
        for node in self.nodeList(): # UUU
            if mainAddress in node.ifaceList: return node
        else: raise KeyError, mainAddress

    def addGraph(self, topology, clock, lineIdx):
        graphKey = self._getGraphKey(clock, lineIdx)
        #print repr(graphKey), lineIdx, clock, topology
        logGraph = self.stateDB.get(graphKey, True)
        logGraph.graph = topology
        logGraph.save()
        self._currentTopology = topology[:]

    def findGraph(self, lineIdx):
        clock = self.getClockAt(lineIdx)
        graphKey = self._getGraphKey(clock, lineIdx)
        otherGraphKey,someData = self.stateDB.setLocation(graphKey)
        if graphKey<otherGraphKey: # XXX!! how is it possible?
            otherGraphKey,someData = self.stateDB.previous()
        #print repr(graphKey), repr(otherGraphKey), otherGraphKey<=graphKey
        logGraph = self.stateDB.get(otherGraphKey, False)
        #print logGraph
        return logGraph
        
#---------------------------------------------------------------------------

class LogNode:
    def __init__(self, name):
        self.name = name
        self.ifaceList = None


def sort(l):
    result = l[:]
    result.sort()
    return result

EOFString = "<end of database>"

ClockScale = 16

class LogAnalysis:
    def __init__(self):
        self.dirName = None
        self.tupleConfig = {} # config as tuple, a la Linda.

    def has_key(self, key):
        return self.tupleConfig.has_key(key)

    def get(self, key):
        return self.tupleConfig[key]

    def set(self, key, value):
        self.tupleConfig[key] = value
        
    def openSimulationResult(self, dirName):
        self.dirName = dirName
        runManager = Simulation.RunManager()
        runManager.openSimulationResult(dirName)
        self.runManager = runManager

        # create the LogNode list
        nodeList = []
        nodeTable = {}
        config = self.runManager.fullConfig
        for nodeName in sort(config.nodeList.keys()):
            node = LogNode(nodeName)
            node.ifaceList = config.nodeList[nodeName]
            nodeList.append(node)
            nodeTable[nodeName] = node
        self.nodeTable = nodeTable
        self.nodeList = nodeList

        # update from tkInter configuration

        # open index file
        fullIndexFileName = self.dirName+"/full.index"
        if not os.path.exists(fullIndexFileName) or True: # XXX!!
            self.makeIndexFile()
        else:
            self.db = LogDB(self, self.dirName)
            self.db.open(False)
            
        self.db.open(shouldRewrite = False)

        self.currentEvent = 0
        #self.nbEvent = (os.stat(fullIndexFileName)[stat.ST_SIZE]
        #                /FmtIndexSize)
        self.nbEvent = self.db.getLineCount()
        #self.fIndex = open(fullIndexFileName, "rb")
        #self.fLog = open(self.dirName+"/full.log", "r") # XXX: windows port.

        # try to read the config
        self.tryReadLogConfig()

    def getNodeList(self):
        return self.nodeList[:]

    def writeLogConfig(self):
        Base.writeFile(self.dirName+"/log-config.py",
                       repr(self.tupleConfig))

    def tryReadLogConfig(self):
        fileName = self.dirName+"/log-config.py"
        if os.path.exists(fileName):
            self.tupleConfig = eval(Base.readFile(fileName))

    def clearBreakPoint(self):
        fileName = self.dirName+"/breakpoint"
        if os.path.exists(fileName): os.remove(fileName)

    def addBreakPoint(self, info):
        fileName = self.dirName+"/breakpoint"
        f = open(fileName, "a")
        f.write("%s\n" % info)
        f.close()

    #--------------------------------------------------

    def readEventLine(self, index):
        """Returns None if out of range"""
        if index<0 or self.nbEvent<= index:
            return None
        #self.fIndex.seek(index*FmtIndexSize)
        #clock,pos = struct.unpack(FmtIndex, self.fIndex.read(FmtIndexSize))
        #self.fLog.seek(pos)
        #return self.fLog.readline().strip()
        return self.db.getLineAt(index+1)

    #--------------------------------------------------

    def _createNetAddressEquivalence(self):
        nodeTable = self.runManager.fullConfig.nodeList
        nodeList = nodeTable.keys()
        nodeList.sort()
        for nodeIdx in range(len(nodeList)):
            ifaceList = nodeTable[nodeList[nodeIdx]]
            for ifaceIdx in range(len(ifaceList)):
                newNodeIdx = nodeIdx + NodeIdxOffset
                newIfaceIdx = ifaceIdx + IfaceIdxOffset
                netAddress = struct.pack("!HH", newNodeIdx, newIfaceIdx)
                self.packetTool.addRawAddressToName(netAddress,
                                                    ifaceList[ifaceIdx])
        #
        #print nodeTable
        #
        #nodeIdx,ifaceIdx = struct.unpack("!HH", netAddress)
        #nodeIdx -= NodeIdxOffset
        #ifaceIdx -= IfaceIdxOffset
        #node = self.nodeList[nodeIdx]
        #iface = node.ifaceList[ifaceIdx]
        #
        #name = nodeTable[nodeList[nodeIdx]][ifaceIdx]
        #exitNow

    def makeIndexFile(self):

        #addressFactory = self #Base.Struct()
        #addressFactory.getAddressSize = (lambda: 4)
        #addressFactory.XXX.YYY = 123456
        #print self.runManager.fullConfig
        self.packetTool = PacketTool.PacketTool(4) # XXX 4: addressSize
        self._createNetAddressEquivalence()
        #packetManager = PacketManager.PacketManager(addressFactory)
        #self.packetManager = packetManager # XXX!!

        self.db = LogDB(self, self.dirName)
        self.db.open(True)
        f = open(self.dirName+"/full.log")

        self.mode = "parsing"
        self.lineParentStack = [ None ]
        lineIndex = 1
        first = True
        while True:
            #if lineIndex == 100000: break # XXX!!
            pos = f.tell()
            line = f.readline()
            if line == "": break
            line = line.strip()
            mClock = rClock.match(line)
            if mClock != None:
                if first:
                    self.db.addGraph([], float(line.split(" ")[0]), 0)
                    first = False
                self.db.setLinePos(lineIndex, pos, self.lineParentStack[-1])
                assert line == self.db.getLineAt(lineIndex)
                self.db.parseLineAt(lineIndex)
            else: raise "Syntax error in log file '%s', no clock line" % (self.dirName+"/full.log"), line
            lineIndex += 1
        self.mode = None
        print "END", lineIndex

        f.close()
        self.db.close()

#---------------------------------------------------------------------------
