#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------
# RoutingTable.py:
# - routing table computation
#---------------------------------------------------------------------------

import TupleSet, Constant
from NeighborSensing import SYM, NOT_SYM # XXX -> Constant
from Constant import SYM_LINK

class RoutingTuple(TupleSet.BasicTuple):
    def __init__(self): # @>>2822
        self.R_dest_addr = None  # @>>2823-2824
        self.R_next_addr = None  # @>>2824
        self.R_dist = None       # @>>2826
        self.R_iface_addr = None # @>>2826-2828

class RoutingTable(TupleSet.TupleSet):
    def isExpired(self, entry):
        return False

class RoutingTableCalculation:
    # This is a Node mixin
    def resetRoutingTable(self):
        self.routingTable = RoutingTable(self)

    def addRoutingEntry(self, dest, next, dist, iface_addr, dg):
        if dg: print "+ %s->%s->%s(%d)"% (iface_addr, next, dest, dist)
        entry = RoutingTuple()
        entry.R_dest_addr  = dest
        entry.R_next_addr  = next
        entry.R_dist       = dist
        entry.R_iface_addr = iface_addr
        self.routingTable.add(entry)

    def computeRouteTable(self, dg=False):
        currentTime = self.getLastTime()
 
        # step 1 - @>>2872
        self.resetRoutingTable()
        table = self.routingTable
        # step 2 - @>>XXX
        for neighborTuple in self.neighborSet.iter():
            if neighborTuple.N_status == NOT_SYM: continue
            isMainAddressReached = False
            lastLinkTuple = None
            for linkTuple in neighborTuple.linkTupleList:
                if linkTuple.getStatus() != SYM_LINK: continue
                
                if (linkTuple.L_neighbor_iface_addr ==
                    neighborTuple.N_neighbor_main_addr):
                    isMainAddressReached = True
                self.addRoutingEntry(
                    dest = linkTuple.L_neighbor_iface_addr,
                    next = linkTuple.L_neighbor_iface_addr,
                    dist = 1,
                    iface_addr = linkTuple.L_local_iface_addr, dg=dg)

                lastLinkTuple = linkTuple
            if not isMainAddressReached and lastLinkTuple !=None :
                self.addRoutingEntry(
                    dest = neighborTuple.N_neighbor_main_addr,
                    next = lastLinkTuple.L_neighbor_iface_addr,
                    dist = 1,
                    iface_addr = lastLinkTuple.L_local_iface_addr, dg=dg)

        # step 3 - @>>2919-2942
        visitedTwoHop = []
        for twoHopNeighborTuple in self.twoHopNeighborSet.iter():
            twoHop = twoHopNeighborTuple
            # XXX!!! can be the node itself in the twoHopNeighborSet? @>>2920
            neighborTuple = self.neighborSet.findFirst(
                lambda x: x.N_neighbor_main_addr == twoHop.N_2hop_addr
                and x.N_status == SYM)
            
            if neighborTuple != None: continue # @>>2919-2920
            nextAddress = twoHop.N_neighbor_main_addr
            neighborTuple = self.neighborSet.findFirst(
                lambda x: (x.N_neighbor_main_addr == nextAddress)
                #and x.N_status == SYM # Ok:  neighbor @>>2922 is neces. sym.
                and x.N_willingness != Constant.WILL_NEVER)
            if neighborTuple != None:
                entry = self.routingTable.findFirst(
                    lambda x: x.R_dest_addr ==
                    neighborTuple.N_neighbor_main_addr)
                #print neighborTuple, "XXX", twoHop, self.getLastTime()
                assert entry != None # XXX!! check this is necessary
                self.addRoutingEntry(
                    dest = twoHop.N_2hop_addr,           # @>>2926
                    next = entry.R_next_addr,            # @>>2928
                    dist = 2,                            # @>>2935
                    iface_addr = entry.R_iface_addr, dg=dg) # @>>2937

        # XXX!!! there are two 'step 3'
        # @>>2944-2985 - step 3bis
        if dg: print "-- Using Topology Set"
        if dg: print self.reprTopology()
        h = 2 # @>>2946
        tableChanged = True
        while tableChanged:
            tableChanged = False # @>>2947-2948
            if dg: print "- distance is %d" % h

            # @>>2944-2978 - step 3.1
            for topologyEntry in self.topologySet.iter(): # @>>2950
                routeEntry = table.findFirst( # @>>2951-2952
                    lambda x: x.R_dest_addr == topologyEntry.T_dest_addr)
                if routeEntry != None: continue
                routeEntry = table.findFirst( # @>>2952-2954
                    lambda x: (x.R_dest_addr == topologyEntry.T_last_addr
                               and x.R_dist == h))
                if routeEntry == None: continue
                # XXX!!! how is "if does not exist" ensured? @>>2955
                tableChanged = True # @>>2947-2948
                self.addRoutingEntry(
                    dest = topologyEntry.T_dest_addr,
                    next = routeEntry.R_next_addr,
                    dist = h+1,
                    iface_addr = routeEntry.R_iface_addr, dg=dg)

            # @>>XXX step 3.2
            # XXX!!! how is this possible at all?

            h += 1

        # @>> - step 4
        for ifaceAssociationTuple in self.ifaceAssociationSet.iter(): # @>>2987
            routeEntry = table.findFirst( # @>>2990-2991
                lambda x: x.R_dest_addr == ifaceAssociationTuple.I_main_addr)
            if routeEntry == None: continue # @>> 2988
            ifaceRouteEntry = table.findFirst( # @>>2995
                lambda x: x.R_dest_addr == ifaceAssociationTuple.I_iface_addr)
            if ifaceRouteEntry != None: continue # @>>2993
            self.addRoutingEntry(
                dest = ifaceAssociationTuple.I_iface_addr, # @>>2999-3000
                next = routeEntry.R_next_addr, # @>>3002-3003
                dist = routeEntry.R_dist,   # @>>3005-3006
                iface_addr = routeEntry.R_iface_addr, dg=dg) # @>>3008-3009
        
        self.shouldRecomputeRoute = False

    def reprRoutingTable(self, withPrefix=False, withTime=False):
        result = []
        for routeEntry in self.routingTable.iter():
            result.append( "%s->%s->%s(%d)" %
                           (routeEntry.R_iface_addr, routeEntry.R_next_addr,
                            routeEntry.R_dest_addr, routeEntry.R_dist))
        result = ";".join(result)
        if withPrefix: result = "RoutingTable: "+result
        return result        
    
#---------------------------------------------------------------------------
