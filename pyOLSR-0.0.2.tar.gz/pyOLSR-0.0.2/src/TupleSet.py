#---------------------------------------------------------------------------
#                             pyOLSR
#             Cedric Adjih, projet Hipercom, INRIA Rocquencourt        
#  Copyright 2003 Institut National de Recherche en Informatique et  
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

from __future__ import generators

class BasicTuple:
    def __repr__(self):
        return "<%s>" % repr(self.__dict__)

class TupleSet:
    def __init__(self, node):
        self.content = []
        self.node = node

    def __repr__(self):
        result = "[%s\n" % self.__class__.__name__
        for entry in self.content:
            result += "%s\n" % repr(entry)
        result += "]\n"
        return result
        
    def isExpired(self, entry): raise Unimplemented

    def add(self, entry):
        self.content.append(entry)

    def remove(self, entry, withNotification=True):
        if withNotification:
            self._notifyRemoval(entry)
        self.content.remove(entry)
    
    def findFirst(self, isSelectedFunc):
        """Search the first non-expired entry for which isSelectedFunc
        is true. Purging the expired entries is done as a byproduct.
        XXX! not done now. This was buggy."""
        oldContent = self.content[:]
        for entry in oldContent:
            #if not self.isExpired(entry): XXX: expire is different
            if isSelectedFunc(entry):
                return entry
        return None

    def iter(self):
        return iter(self.content[:]) # it's a copy, thus list can be changed

    def removeExpired(self):
        removedCount = 0
        newContent = []
        for entry in self.content[:]:
            if not self.isExpired(entry):
                newContent.append(entry)
            else:
                self._notifyRemoval(entry)
                removedCount += 1
        self.content = newContent
        return removedCount

    def _notifyRemoval(self, entry): pass

    def removeSelected(self, isSelectedFunc):
        newContent = []
        removedTupleList = []
        for entry in self.content[:]:
            if not isSelectedFunc(entry):
                newContent.append(entry)
            else:
                self._notifyRemoval(entry)
                removedTupleList.append(entry)
        self.content = newContent
        return removedTupleList

#------------------------------

class ExpireInfo:
    def __init__(self, node, withTime, withEventCause):
        self.currentTime = node.getLastTime()
        self.expireClockTime = node.expireClock.getTime()
        self.withTime = withTime
        self.withEventCause = withEventCause

    def getExpireInfo(self, tupleTime, tuple):
        if tupleTime == None: optTime = "."
        else:
            if tupleTime >= self.currentTime: optTime = "+"
            elif tupleTime >= self.expireClockTime: optTime = "="
            else: optTime = "-"
            if self.withTime: optTime+="/%s" % tupleTime

        if self.withEventCause:
            if tuple.event != None:
                optTime += '\\%s' % tuple.event

        return optTime

#---------------------------------------------------------------------------
