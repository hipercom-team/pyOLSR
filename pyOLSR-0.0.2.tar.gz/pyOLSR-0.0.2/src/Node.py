#---------------------------------------------------------------------------
#			      pyOLSR
#	      Cedric Adjih, projet Hipercom, INRIA Rocquencourt
#  Copyright 2003 Institut National de Recherche en Informatique et
#  en Automatique.  All rights reserved.  Distributed only with permission.
#---------------------------------------------------------------------------

import math, sys
import pdb

import Constant
import Base, NeighborSensing, TopologyDiscovery, PacketManager
import RoutingTable, IfaceAssociationBase, TupleSet

#--------------------------------------------------

class Config:
    def __init__(self):
	scale = 3.0
	self.HELLO_INTERVAL   = scale * 2.0 # @>>3815
	self.REFRESH_INTERVAL = scale * 2.0 # @>>3817
	self.TC_INTERVAL      = scale * 5.0 # @>>3819
	self.MID_INTERVAL     = self.TC_INTERVAL # @>>3821
	self.HNA_INTERVAL     = self.TC_INTERVAL # @>>3823

	self.NEIGHB_HOLD_TIME = 3 * self.HELLO_INTERVAL # @>>3829
	self.TOP_HOLD_TIME    = 3 * self.TC_INTERVAL # @>>3831
	self.DUP_HOLD_TIME    = 30.0 # @>>3833
	self.MID_HOLD_TIME    = 3 * self.MID_INTERVAL # @>>3835
	self.HNA_HOLD_TIME    = 3 * self.HNA_INTERVAL # @>>3837

	self.removeExpiredInterval = 0.5   # second
	self.maxImmediateHelloOnChange = 1 # per HELLO_INTERVAL

#---------------------------------------------------------------------------

class Interface:
    def __init__(self, ident, address):
	self.identifier = ident
	self.address = address
	self.sequenceNumber = 0

    def allocSequenceNumber(self):
	result = self.sequenceNumber
	self.sequenceNumber += 1
	return result

    def getAddress(self):
	return self.address

    #def sendPacket(self, rawPacket):
    #	 pass

class ExpireClock:
    def __init__(self, node):
	self.lastTime = None
	self.node = node
    def getTime(self): return self.lastTime
    def setTime(self, newTime): self.lastTime = newTime
    def notifyNeighborLinkChange(self, neighborTuple):
	self.node.notifyNeighborLinkChange(neighborTuple)
    def removeTwoHopNeighborTuple(self, twoHopTuple):
	self.node.removeTwoHopNeighborTuple(twoHopTuple)

#---------------------------------------------------------------------------

class OLSRNode(NeighborSensing.NeighborSensing, \
	       TopologyDiscovery.TopologyDiscovery, \
	       TopologyDiscovery.MPRSelection, \
	       IfaceAssociationBase.IfaceAssociationBase, \
	       RoutingTable.RoutingTableCalculation):

    def __init__(self, config, logConfig, logManager):
	self.log = logManager
	self.l = logConfig
	self.config = config #Config()
	self.expireClock = ExpireClock(self)
	self.lastClock = ExpireClock(self)
	clock = self.expireClock
	currentTime = self.getRealTime()
	clock.setTime(currentTime)
	self.lastClock.setTime(currentTime)
	self.duplicateSet = PacketManager.DuplicateSet(clock)
	self.packetManager = PacketManager.PacketManager(self)
	self.linkSet = NeighborSensing.LinkSet(clock)
	self.neighborSet = NeighborSensing.NeighborSet(clock)
	self.twoHopNeighborSet = NeighborSensing.TwoHopNeighborSet(clock)
	self.mprSelectorSet = TopologyDiscovery.MPRSelectorSet(clock)
	self.topologySet = TopologyDiscovery.TopologySet(clock)
	(self.ifaceAssociationSet
	 ) = IfaceAssociationBase.IfaceAssociationSet(clock)

	self.running = False
	self.resetMPRSelection()
	self.resetRoutingTable()
	self.ifaceList = []

	self.routeConfigurator = None

	self.shouldRecomputeMPR = False
	self.shouldRecomputeRoute = False

	self.shouldProcessTwoHopNeighborhoodChange = False
	self.shouldProcessNeighborhoodChange = False

    def updateLastCurrentTime(self):
	self.lastClock.setTime(self.getRealTime())

    def getLastTime(self): return self.lastClock.getTime()

    def reprDuplicateSet(self, withPrefix=False, withTime=False):
	expireInfo = TupleSet.ExpireInfo(self, withTime, self.l._lec)
	result = []
	for t in self.duplicateSet.iter():
	    expireStr = expireInfo.getExpireInfo(t.D_time, t)
	    result.append( "%s:%s %s %s %s" % (
		t.D_addr,t.D_seq_num, expireStr, t.D_retransmitted,
		",".join(["%s" % x for x in t.D_iface_list])))
	result = ";".join(result)
	if withPrefix: result = "DuplicateSet: " + result
	return result

    def processChange(self, withRoutingTable=True):
	mprSetChanged = False
	shouldRecomputeMPR = self.shouldRecomputeMPR
	shouldRecomputeRoute = self.shouldRecomputeRoute

	# XXX!! Do something about this:
	if self.shouldProcessTwoHopNeighborhoodChange:
	    shouldRecomputeMPR = True # @>>2572-2573
	    self.shouldProcessTwoHopNeighborhoodChange = False

	# XXX!! Do something about this:
	if self.shouldProcessNeighborhoodChange:
	    shouldRecomputeMPR = True # @>>2572-2573
	    self.shouldProcessTwoHopNeighborhoodChange = False

	if shouldRecomputeMPR:
	    mprSetChanged = self.computeMPR()
	    if mprSetChanged: # @>>2583-2584
		self.eventMPRChange()

	if withRoutingTable and shouldRecomputeRoute:
	    self.computeRouteTable("%s"%self.getMainAddress() == "A") #XXX!!
	    self.setUpRouteTable()
	    self.shouldRecomputeRoute = False

    def addIface(self, ident, address):
	self.ifaceList.append(Interface(ident, address))

    def getWillingness(self):
	return 3 # XXX

    def getTime(self):
	raise Unimplemented

    def isMPR(self, mainAddress):
	return mainAddress in self.mprList

    def isMPRSelector(self, mainAddress):
	return self.mprSelectorSet.findFirst(
	    lambda x: x.MS_addr == mainAddress) != None

    def getMainAddress(self): return self.getMainIface().getAddress()

    def getAddressList(self): return [x.getAddress() for x in self.ifaceList]

    def getIfaceList(self):   return self.ifaceList[:]

    def getMainIface(self):   return self.ifaceList[0] #XXX put -> SimNode

    def setUpRouteTable(self):
	if self.routeConfigurator == None: return
	routeList = []
	for routeTuple in self.routingTable.iter():
	    t = (routeTuple.R_next_addr, "255.255.255.255", #XXX! netmask
		 routeTuple.R_iface_addr, routeTuple.R_dest_addr,
                 routeTuple.R_dist)
	    routeList.append(t)
	self.routeConfigurator.updateRoute(routeList)

    #--------------------------------------------------

    def notifyTwoHopNeighborhoodChange(self):
	self.shouldRecomputeRoute = True # @>>2839
	self.shouldRecomputeMPR = True
	#self.shouldProcessTwoHopNeighborhoodChange = True

    def notifyNeighborhoodChange(self):
	self.shouldRecomputeRoute = True # @>>2835-2837
	self.shouldRecomputeMPR = True
	#self.shouldProcessNeighborhoodChange = True

    def notifyTopologyChange(self):
	self.shouldRecomputeRoute = True

    def notifyIfaceAssociationBaseChange(self):
	self.shouldRecomputeMPR = True
	self.shouldRecomputeRoute = True

    def eventRemoveExpired(self):
	if not self.running: return
	self.preEvent("expire")
	self.schedule(self.config.removeExpiredInterval,
		      self.eventRemoveExpired)
	self._updateRemoveExpired()
	self.processChange()
	self.postEvent("expire")

    def _makeTwoHopConsistent(self): # unused
	UNUSED
	# XXX! remove
	# Remove orphaned two hop tuples - @>>2565-2566
	for twoHop in self.twoHopNeighborSet.iter():
	    neighborTuple = self.neighborSet.findFirst(
		lambda x: x.N_neighbor_main_addr
		== twoHop.N_neighbor_main_addr)
	    if (neighborTuple == None
		or neighborTuple.N_status == NOT_SYM):
		self.twoHopNeighborSet.remove(twoHop)
		XXX.untested.right.now

    def _makeOneHopConsistent(self): # unused
	UNUSED
	# XXX! remove
	shouldRecomputeMPR = True # @>>2571-2572
	# Remove orphaned MPR selector tuples - @>>2568-2569
	for mprSelectorTuple in self.mprSelectorSet.iter():
	    neighborTuple = self.neighborSet.findFirst(
		lambda x: x.N_neighbor_main_addr
		== mprSelectorTuple.MS_addr)
	    if (neighborTuple == None
		or neighborTuple.N_status == NOT_SYM):
		self.mprSelectorSet.remove(mprSelectorTuple)
	    print "XXX: check it is working"
	self.shouldProcessNeighborhoodChange = False

    def _updateRemoveExpired(self):
	# XXX!! update the links
	self.expireClock.setTime(self.getLastTime())

	if self.linkSet.removeExpired()>0:
	    self.shouldRecomputeRoute = True # @>>2843
	if self.twoHopNeighborSet.removeExpired()>0:
	    self.shouldRecomputeRoute = True # @>>2839
	    self.shouldRecomputeMPR = True
	if self.mprSelectorSet.removeExpired()>0:
	    self.shoudRecomputeMPR = True # XXX!! @>> reference
	if self.topologySet.removeExpired()>0:
	    self.shouldRecomputeRoute = True # @>>2841
	if self.ifaceAssociationSet.removeExpired()>0:
	    self.shouldRecomputeRoute = True # @>>2843
	    #self.shouldRecomputeMPR = True # XXX!!! should?
	self.duplicateSet.removeExpired()
	self.removeNeighborExpired() # Note: the shouldRecomputeX would be
	# set indirectly by the Link changes that triggered removal.

    #--------------------------------------------------

    def display(self): #XXX: back in OLSRNode
	print "-"*50
	print self.reprNeighborLink("Neighbor:")
	print self.reprTwoHopNeighbor("TwoHop:")
	print self.reprMPRSet("MPRSet:")
	print self.reprMPRSelector("MPRSelector:")
	print self.reprTopology("Topology:")
	print self.reprRoutingTable("RoutingTable:")

    def sendPacket(self, iface, rawPacket): #XXX: check if used
	raise Unimplemented

    def schedule(self, relativeTime, func):
	raise Unimplemented

    #--------------------------------------------------
    # Address factory

    def netToAddress(self, rawAddress):
	raise Unimplemented

    #def addressToNet(self, address):
    #	 raise Unimplemented

    def getAddressSize(self):
	raise Unimplemented

    #--------------------------------------------------
    # Generic functions

    def start(self): # XXX allow for double 'start'
	self.running = True
	self.startNeighborSensing()
	self.startTopologyDiscovery()
	self.startIfaceAssociationBase()
	self.startMPRSelection()
	self.resetRoutingTable()
	self.eventRemoveExpired()

    def stop(self): # XXX: overloaded in libolsr.py
	self.running = False

    #--------------------------------------------------

    def doSnapshot(self):
	self._logState(True, True)

    def preEvent(self, eventName):
	if self.l._lsim:
	    self.log.write("%s [event-begin] %s %s\n" % (
		self.getRealTime(), eventName, self.getMainAddress()))
	    self._logState()

    def postEvent(self, eventName):
	if self.l._lsim:
	    self._logState()
	    self.log.write("%s [event-end] %s %s\n" % (
		self.getRealTime(), eventName, self.getMainAddress()))

    def _logState(self, a=False, t=False):
	t = t or self.l._ltime
	f = False
	if not (self.l._lsim or a):
	    return
	l = []
	if a or self.l._lns: l.append(("neighbor", self.reprNeighborLink(f,t)))
	if a or self.l._lds: l.append(("duplicate", self.reprDuplicateSet(f,t)))
	if a or self.l._lts: l.append(("two-hop", self.reprTwoHopNeighbor(f,t)))
	if a or self.l._lt:  l.append(("topology", self.reprTopology(f,t)))
	if a or self.l._lm:  l.append(("mpr", self.reprMPRSet(f,t)))
	if a or self.l._lms: l.append(("mpr-selector",self.reprMPRSelector(f,t)))
	if a or self.l._lr:  l.append(("route", self.reprRoutingTable(f,t)))
	if a or self.l._lmi:  l.append(("mid", self.reprMID(f,t)))
	self.log.write("%s [state-begin] %s\n" % (
		self.getRealTime(), self.getMainAddress()))
	for name, data in l:
	    #print "NAME,DATA", name, data
	    self.log.write("%s [table-%s] %s: %s\n" % (
		self.getRealTime(), name, self.getMainAddress(), data))
	self.log.write("%s [state-end] %s\n" % (
		self.getRealTime(), self.getMainAddress()))

    def logInfo(self, info):
	self.log.write("%s [info] %s %s\n" %
		       (self.getRealTime(), self.getMainAddress(), info))

    def getLastEvent(self):
	if self.log != None: return self.log.currentLine

    def setRouteConfigurator(self, routeConfigurator):
	self.routeConfigurator = routeConfigurator

#---------------------------------------------------------------------------

# XXX!!! there is one 'two-hop' left, and one 'two hop' (versus '2-hop')

#---------------------------------------------------------------------------

# This is a bridge/facade/whatever between RealIface (which deals only
# with real world IP details), and NodeIface (which deals only with OLSR
# iface point of view).
class PyIface(Interface):
    def __init__(self, rawIface):
	self.rawIface = rawIface
	Interface.__init__(self, rawIface.name, rawIface.address)


class PyNode(OLSRNode): # XXX: rename
    """A OLSRNode expected to be used in pure Python code
    both with RealWorld and Simulation, as opposed to libolsr"""
    def __init__(self, scheduler, fullConfig, logManager):
	self.scheduler = scheduler
	self.fullConfig = fullConfig
	OLSRNode.__init__(self, fullConfig.config, fullConfig.logConfig,
			  logManager)

    def setIfaceList(self, rawIfaceList):
	self.ifaceList = []
	for rawIface in rawIfaceList:
	    iface = PyIface(rawIface)
	    rawIface.olsrIface = iface
	    self.ifaceList.append( iface )

    def start(self):
	OLSRNode.start(self)
	self._evDisplay()

    def getAddressSize(self):
	return len(self.getMainAddress().toNet())

    def _evDisplay(self):
	self.display()
	self.schedule(30.0, self._evDisplay)

    def addFdHandler(self, fdHandler):
	self.scheduler.addFdHandler(fdHandler)

    def schedule(self, relativeTime, func):
	self.scheduler.addEvent(relativeTime, func, [])

    def getRealTime(self):
	return self.scheduler.getTime()

    def sendPacket(self, iface, rawPacket):
	if self.l._lp:
	    packetStr = Base.toASCII(rawPacket)
	    self.log.write("%s [send-packet] %s %s %s\n" %(
		self.getRealTime(), self.getMainAddress(),
		iface.getAddress(), packetStr))
	iface.rawIface.sendPacket(rawPacket)

    def receivePacket(self, ipAddress, realIface, rawPacket):
	if not self.running: return
	self.updateLastCurrentTime()
	self.preEvent("receive-packet")
	self._updateRemoveExpired()
	self.processChange(withRoutingTable=False)
	if self.l._lp:
	    packetStr = Base.toASCII(rawPacket)
	    self.log.write("%s [receive-packet] %s %s %s %s\n" %(
		self.getRealTime(), self.getMainAddress(), ipAddress,
		realIface.getAddress(), packetStr))
	self.packetManager.processPacket(ipAddress,
					 realIface.olsrIface.getAddress(),
					 rawPacket)
	self.processChange(withRoutingTable=True)
	self.postEvent("receive-packet")

    def setAddressFactory(self, addressFactory):
	self.addressFactory = addressFactory

    def netToAddress(self, rawAddress):
	result, empty = self.addressFactory.popFrontAddress(rawAddress)
	assert empty == ''
	return result

#---------------------------------------------------------------------------
